  // ---- Data helpers ----
  function escapeHtml(s) { return Shared.escapeHtml(s); }
  function formatDate(iso) {
    const d = new Date(iso + 'T00:00:00');
    return d.toLocaleDateString(undefined, { weekday: 'short', year: 'numeric', month: 'short', day: 'numeric' });
  }
  // entry.id is a Date.now() timestamp captured when the entry was logged —
  // use it to show what time of day it was added.
  function formatEntryTime(id) {
    const ms = Number(id);
    if (!ms || isNaN(ms)) return '';
    const d = new Date(ms);
    if (isNaN(d.getTime())) return '';
    return d.toLocaleTimeString(undefined, { hour: 'numeric', minute: '2-digit' });
  }
  function timestampForFilename() {
    const d = new Date();
    const pad2 = n => String(n).padStart(2, '0');
    return `${d.getFullYear()}-${pad2(d.getMonth() + 1)}-${pad2(d.getDate())}_${pad2(d.getHours())}-${pad2(d.getMinutes())}-${pad2(d.getSeconds())}`;
  }
  // dates on which at least one logged entry set a PR (drives the trophy on the calendar)
  function prDates() {
    const set = new Set();
    categories.forEach(cat => (data[cat] || []).forEach(e => { if (e.isPR) set.add(e.date); }));
    return set;
  }
  function categoriesByDate() {
    const map = {};
    categories.forEach(cat => (data[cat] || []).forEach(e => {
      if (!map[e.date]) map[e.date] = new Set();
      map[e.date].add(cat);
    }));
    return map;
  }


  // ---- Rendering: entries grouped by day ----
  function getWeekStart(dateStr) {
    return Shared.weekStartISO(dateStr, weekStart);
  }
  function formatWeekLabel(weekStartISO) {
    const start = new Date(weekStartISO + 'T00:00:00');
    const end = new Date(start);
    end.setDate(start.getDate() + 6);
    const opts = { month: 'short', day: 'numeric' };
    return `${start.toLocaleDateString(undefined, opts)} – ${end.toLocaleDateString(undefined, opts)}`;
  }

  function buildEntryCard(entry, category) {
    const div = document.createElement('div');
    div.className = 'entry';
    div.style.borderLeftColor = getCategoryColor(category);

    const exObj = (exerciseLists[category] || []).find(e => e.name === entry.exercise) || null;
    const exColor = exObj ? ensureExerciseColor(category, exObj) : getCategoryColor(category);

    const eHeader = document.createElement('div');
    eHeader.className = 'entry-header';
    const ex = document.createElement('span');
    ex.className = 'entry-exercise';
    const loggedTime = formatEntryTime(entry.id);
    ex.innerHTML = `<span class="dot" style="background:${exColor}"></span>${escapeHtml(entry.exercise || '')}` +
      (loggedTime ? `<span class="entry-time">${loggedTime}</span>` : '');
    const btnGroup = document.createElement('div');
    btnGroup.style.display = 'flex';
    btnGroup.style.gap = '2px';
    const editBtn = document.createElement('button');
    editBtn.className = 'del-btn';
    editBtn.setAttribute('aria-label', 'Edit entry');
    editBtn.innerHTML = '<i class="fa-solid fa-pencil" aria-hidden="true"></i>';
    editBtn.onclick = () => editEntry(entry.id);
    const delBtn = document.createElement('button');
    delBtn.className = 'del-btn';
    delBtn.setAttribute('aria-label', 'Delete entry');
    delBtn.innerHTML = '<i class="fa-regular fa-trash-can" aria-hidden="true"></i>';
    delBtn.onclick = () => deleteEntry(entry.id);
    btnGroup.appendChild(editBtn);
    btnGroup.appendChild(delBtn);
    eHeader.appendChild(ex);
    eHeader.appendChild(btnGroup);
    div.appendChild(eHeader);

    const badgeRow = document.createElement('div');
    badgeRow.className = 'entry-badges';
    const catBadge = document.createElement('span');
    catBadge.className = 'badge';
    catBadge.style.background = getCategoryColor(category);
    catBadge.style.color = '#fff';
    catBadge.textContent = category;
    badgeRow.appendChild(catBadge);
    const addBadge = text => { const b = document.createElement('span'); b.className = 'badge'; b.textContent = text; badgeRow.appendChild(b); };
    if (entry.weightKg) addBadge(formatLoadKg(entry.weightKg));
    if (entry.unilateral) addBadge('L/R');
    if (entry.isometric) addBadge('Isometric');
    if (entry.equipment) addBadge(entry.equipment);
    if (entry.attempts && entry.attempts.length) addBadge('Attempts');
    if (entry.isPR) {
      const pr = document.createElement('span');
      pr.className = 'badge badge-pr';
      pr.innerHTML = '<i class="fa-solid fa-trophy" aria-hidden="true"></i> PR';
      if (entry.prTypes && entry.prTypes.length) pr.title = 'New PR: ' + entry.prTypes.join(', ');
      badgeRow.appendChild(pr);
    }
    div.appendChild(badgeRow);

    if (entry.distance !== undefined && entry.distance !== null && entry.distance !== '') {
      const distRow = document.createElement('div');
      distRow.className = 'entry-sets';
      const addPill = text => { const p = document.createElement('span'); p.className = 'set-pill'; p.textContent = text; distRow.appendChild(p); };
      if (entry.variation) addPill(entry.variation);
      addPill(`${round2(kmToDisplay(entry.distance))} ${distanceUnitLabel()}`);
      const pace = paceForEntry(entry);
      if (pace) addPill(`${pace} /${distanceUnitLabel()}`);
      if (entry.ruckKg != null) addPill(`Rucking ${round2(kgToDisplay(entry.ruckKg))}${weightUnitLabel()}`);
      if (entry.elevation != null) addPill(`↑ ${round2(mToDisplay(entry.elevation))}${elevationUnitLabel()}`);
      if (entry.timeMinutes != null) addPill(formatDuration(entry.timeMinutes));
      div.appendChild(distRow);
    } else if (entry.sets && entry.sets.length) {
      const setsRow = document.createElement('div');
      setsRow.className = 'entry-sets';
      const unit = entry.isometric ? 's' : '';
      if (entry.isometric && entry.sets.length > 3 && !entry.sets.some(s => s && s.chain)) {
        // several quick hold attempts — summarize on one line instead of a pill per attempt
        const holds = entry.sets.map(Shared.setReps);
        const best = Math.max(...holds);
        const summary = document.createElement('span');
        summary.className = 'set-pill attempts-summary';
        summary.textContent = `${holds.length} attempts: ${holds.join('s, ')}s · best ${best}s`;
        setsRow.appendChild(summary);
      } else {
        entry.sets.forEach((s, i) => {
          if (s && typeof s === 'object' && s.chain && i > 0) return; // shown inside its chain
          let end = i;
          while (entry.sets[end + 1] && typeof entry.sets[end + 1] === 'object' && entry.sets[end + 1].chain) end++;
          if (end > i) {
            const seg = entry.sets.slice(i, end + 1);
            const cp = document.createElement('span');
            cp.className = 'set-pill';
            const parts = seg.map(x => (setVar(x) || 'standard') + ' ' + (x.left !== undefined ? x.left + '/' + x.right : x.reps) + unit);
            const total = entry.isometric ? ' · total ' + seg.reduce((a, x) => a + Shared.setReps(x), 0) + 's' : '';
            cp.innerHTML = '<i class="fa-solid fa-link" aria-hidden="true"></i> ';
            cp.appendChild(document.createTextNode(`Chain, sets ${i + 1}–${end + 1}: ${parts.join(' → ')}${total}`));
            setsRow.appendChild(cp);
            return;
          }
          const pill = document.createElement('span');
          pill.className = 'set-pill';
          const ecc = (s && typeof s === 'object') ? s.eccentric : null;
          const kg = (s && typeof s === 'object') ? s.kg : null;
          const angle = (s && typeof s === 'object') ? s.angle : null;
          const equip = (s && typeof s === 'object') ? s.equipment : null;
          const variation = setVar(s);
          const flagTxt = (s && typeof s === 'object') ? (s.rpe ? ` · RPE ${s.rpe}` : '') + (s.pain ? ' · pain' : '') + (s.formBroke ? ' · form broke' : '') : '';
          const extras = `${ecc ? ` (ecc ${ecc}s)` : ''}${kg ? ` @ ${formatLoadKg(kg)}` : ''}${angle ? ` [${angle}]` : ''}${variation ? ` · ${variation}` : ''}${equip ? ` · ${equip}` : ''}${flagTxt}`;
          if (s && typeof s === 'object' && s.left !== undefined) {
            pill.textContent = `Set ${i + 1}: L ${s.left}${unit} / R ${s.right}${unit}${s.left !== s.right ? ` (Δ${Math.abs((Number(s.left) || 0) - (Number(s.right) || 0))})` : ''}${extras}`;
          } else {
            const val = (typeof s === 'object') ? s.reps : s;
            const label = entry.isometric ? 's hold' : ' reps';
            pill.textContent = `Set ${i + 1}: ${val}${label}${extras}`;
          }
          setsRow.appendChild(pill);
        });
      }
      div.appendChild(setsRow);
    } else if (entry.attempts && entry.attempts.length) {
      const setsRow = document.createElement('div');
      setsRow.className = 'entry-sets';
      const best = Math.max(...entry.attempts);
      const summary = document.createElement('span');
      summary.className = 'set-pill attempts-summary';
      summary.textContent = `${entry.attempts.length} attempts: ${entry.attempts.join('s, ')}s · best ${best}s`;
      setsRow.appendChild(summary);
      div.appendChild(setsRow);
    }

    if (entry.notes) {
      const notes = document.createElement('div');
      notes.className = 'entry-notes';
      notes.textContent = entry.notes;
      div.appendChild(notes);
    }
    return div;
  }

  function buildSupersetCard(items) {
    const wrap = document.createElement('div');
    wrap.className = 'superset-card';
    const header = document.createElement('div');
    header.className = 'superset-card-header';
    header.innerHTML = `<i class="fa-solid fa-link" aria-hidden="true"></i> Superset · ${items.length} exercises`;
    wrap.appendChild(header);
    items.forEach(item => wrap.appendChild(buildEntryCard(item.entry, item.category)));
    return wrap;
  }

  function renderEntries() {
    const year = calViewDate.getFullYear();
    const month = calViewDate.getMonth();
    const monthKey = `${year}-${month}`;

    if (monthKey !== lastEntriesMonthKey) {
      lastEntriesMonthKey = monthKey;
      expandedWeeks = new Set();
      weeksNeedDefaultExpand = true; // re-expand the newest week once for this month
    }

    // gather every entry, from every category, for the viewed month
    const allEntries = [];
    categories.forEach(cat => {
      (data[cat] || []).forEach(e => {
        const d = new Date(e.date + 'T00:00:00');
        if (d.getFullYear() === year && d.getMonth() === month) {
          allEntries.push({ entry: e, category: cat });
        }
      });
    });

    entriesEl.innerHTML = '';
    if (allEntries.length === 0) {
      entriesEl.innerHTML = '<div class="empty">No entries logged in ' +
        calViewDate.toLocaleDateString(undefined, { month: 'long', year: 'numeric' }) +
        '. Use the calendar arrows to browse other months.</div>';
      return;
    }

    const weekMap = {};
    allEntries.forEach(item => {
      const wk = getWeekStart(item.entry.date);
      (weekMap[wk] = weekMap[wk] || []).push(item);
    });
    const weekKeys = Object.keys(weekMap).sort((a, b) => b.localeCompare(a)); // newest week first
    if (weeksNeedDefaultExpand && weekKeys.length) {
      expandedWeeks.add(weekKeys[0]);
      weeksNeedDefaultExpand = false;
    }

    weekKeys.forEach(wk => {
      const weekItems = weekMap[wk];
      const isExpanded = expandedWeeks.has(wk);

      const weekSection = document.createElement('div');
      weekSection.className = 'week-group';

      const weekHeader = document.createElement('button');
      weekHeader.type = 'button';
      weekHeader.className = 'week-header';
      weekHeader.innerHTML = `<i class="fa-solid fa-angle-${isExpanded ? 'down' : 'right'}" aria-hidden="true"></i> ${formatWeekLabel(wk)} <span class="week-count">${weekItems.length}</span>`;
      weekHeader.onclick = () => {
        if (expandedWeeks.has(wk)) expandedWeeks.delete(wk); else expandedWeeks.add(wk);
        renderEntries();
      };
      weekSection.appendChild(weekHeader);

      if (isExpanded) {
        const weekBody = document.createElement('div');
        weekBody.className = 'week-body';

        const byDate = {};
        weekItems.forEach(item => { (byDate[item.entry.date] = byDate[item.entry.date] || []).push(item); });
        const dates = Object.keys(byDate).sort((a, b) => b.localeCompare(a));

        dates.forEach(date => {
          const dayGroup = document.createElement('div');
          dayGroup.className = 'day-group';
          const header = document.createElement('div');
          header.className = 'day-group-header';
          header.textContent = formatDate(date);
          dayGroup.appendChild(header);
          const dayItems = byDate[date].slice().sort((a, b) => Number(b.entry.id) - Number(a.entry.id)); // last logged first
          const seen = new Set();
          dayItems.forEach(item => {
            if (seen.has(item.entry.id)) return;
            const sid = item.entry.supersetId;
            const groupItems = sid ? dayItems.filter(x => x.entry.supersetId === sid) : [item];
            groupItems.forEach(x => seen.add(x.entry.id));
            if (groupItems.length > 1) {
              groupItems.sort((a, b) => Number(a.entry.id) - Number(b.entry.id)); // original logging order within the group
              dayGroup.appendChild(buildSupersetCard(groupItems));
            } else {
              dayGroup.appendChild(buildEntryCard(item.entry, item.category));
            }
          });
          weekBody.appendChild(dayGroup);
        });
        weekSection.appendChild(weekBody);
      }

      entriesEl.appendChild(weekSection);
    });
    updateSkillsBadge(); // logging, editing or deleting can change which skill steps are met
  }

  function pad(n) { return String(n).padStart(2, '0'); }
  function toISODate(y, m, d) { return `${y}-${pad(m + 1)}-${pad(d)}`; }

  function renderCalendar() {
    const year = calViewDate.getFullYear();
    const month = calViewDate.getMonth();
    calTitle.textContent = calViewDate.toLocaleDateString(undefined, { month: 'long', year: 'numeric' });

    const catMap = categoriesByDate();
    const prSet = prDates();
    const todayISO = toISODate(new Date().getFullYear(), new Date().getMonth(), new Date().getDate());

    calGrid.innerHTML = '';
    (weekStart === 1 ? ['M', 'T', 'W', 'T', 'F', 'S', 'S'] : ['S', 'M', 'T', 'W', 'T', 'F', 'S']).forEach(d => {
      const el = document.createElement('div');
      el.className = 'cal-dow';
      el.textContent = d;
      calGrid.appendChild(el);
    });

    const firstDay = (new Date(year, month, 1).getDay() - weekStart + 7) % 7;
    const daysInMonth = new Date(year, month + 1, 0).getDate();

    for (let i = 0; i < firstDay; i++) {
      const el = document.createElement('div');
      el.className = 'cal-day empty';
      calGrid.appendChild(el);
    }
    for (let d = 1; d <= daysInMonth; d++) {
      const iso = toISODate(year, month, d);
      const el = document.createElement('div');
      el.className = 'cal-day';
      if (iso === todayISO) el.classList.add('today');
      if (iso === selectedCalDate) el.classList.add('selected');

      const num = document.createElement('span');
      num.textContent = d;
      el.appendChild(num);

      if (prSet.has(iso)) {
        const trophy = document.createElement('i');
        trophy.className = 'fa-solid fa-trophy cal-pr';
        trophy.setAttribute('aria-label', 'Personal record');
        trophy.title = 'Personal record';
        el.appendChild(trophy);
      }

      const catsThatDay = catMap[iso];
      if (catsThatDay && catsThatDay.size) {
        const dotsWrap = document.createElement('div');
        dotsWrap.className = 'cal-dots';
        Array.from(catsThatDay).slice(0, 6).forEach(cat => {
          const dot = document.createElement('span');
          dot.className = 'cal-dot';
          dot.style.background = getCategoryColor(cat);
          dotsWrap.appendChild(dot);
        });
        el.appendChild(dotsWrap);
      }

      el.onclick = () => {
        selectedCalDate = (selectedCalDate === iso) ? null : iso;
        dateInput.value = iso;
        updateHeaderDateDisplay();
        renderCalendar();
      };
      calGrid.appendChild(el);
    }
  }

  document.getElementById('calPrev').onclick = () => {
    calViewDate = new Date(calViewDate.getFullYear(), calViewDate.getMonth() - 1, 1);
    renderCalendar();
    renderEntries();
  };
  document.getElementById('calNext').onclick = () => {
    calViewDate = new Date(calViewDate.getFullYear(), calViewDate.getMonth() + 1, 1);
    renderCalendar();
    renderEntries();
  };
  document.getElementById('calToday').onclick = () => {
    calViewDate = new Date();
    renderCalendar();
    renderEntries();
  };

  function render() {
    renderTabs();
    renderEntries();
    renderCalendar();
  }

  // ---- Persistence: entries ----
  function loadData() {
    try {
      const raw = localStorage.getItem(DATA_KEY);
      if (raw) {
        const parsed = JSON.parse(raw);
        categories.forEach(c => { data[c] = parsed[c] || []; });
      }
    } catch (e) { /* ignore */ }
  }
  // Empty fields (null, '') are left out of stored entries and sets: backups are about a third smaller, and every reader treats a missing field as empty.
  function compactEntry(e) {
    if (!e || typeof e !== 'object') return e;
    Object.keys(e).forEach(k => { if (e[k] === null || e[k] === undefined || e[k] === '' || (k === 'isPR' && e[k] === false)) delete e[k]; });
    if (Array.isArray(e.sets)) e.sets.forEach(s => {
      if (s && typeof s === 'object') Object.keys(s).forEach(k => { if (s[k] === null || s[k] === undefined || s[k] === '') delete s[k]; });
    });
    return e;
  }
  function saveData() {
    categories.forEach(c => (data[c] || []).forEach(compactEntry));
    try {
      localStorage.setItem(DATA_KEY, JSON.stringify(data));
    } catch (e) {
      errEl.textContent = 'Could not save to this browser. Storage may be full or disabled.';
      errEl.classList.remove('hidden');
    }
  }
  function findEntryLocation(id) {
    for (const cat of categories) {
      const idx = (data[cat] || []).findIndex(e => e.id === id);
      if (idx !== -1) return { category: cat, index: idx };
    }
    return null;
  }
  // ids of entries deleted on this device, so sync can remove them elsewhere instead of bringing them back
  const DELETED_KEY = 'workout-log-deleted-v1';
  let deletedEntries = {};
  try { const dd = JSON.parse(localStorage.getItem(DELETED_KEY)); if (dd && typeof dd === 'object' && !Array.isArray(dd)) deletedEntries = dd; } catch (e) { /* none yet */ }
  function saveDeleted() { lsSet(DELETED_KEY, JSON.stringify(deletedEntries)); }
  function deleteEntry(id) {
    if (!confirm('Delete this entry?')) return;
    const loc = findEntryLocation(id);
    if (!loc) return;
    const gone = data[loc.category].splice(loc.index, 1)[0];
    deletedEntries[id] = Date.now(); saveDeleted();
    saveData();
    if (gone) recalcPRs(gone.exercise);
    renderEntries();
    renderCalendar();
  }

  let entryEditOverlay = null;
  function ensureEntryEditOverlay() {
    if (entryEditOverlay) return entryEditOverlay;
    const ov = document.createElement('div');
    ov.className = 'modal-overlay hidden';
    ov.innerHTML = '<div class="modal-box edit-box"><div class="section-label" id="eeTitle">Edit entry</div><div id="eeBody"></div><div class="modal-actions"><button type="button" id="eeCancel">Cancel</button><button type="button" id="eeSave">Save</button></div></div>';
    document.body.appendChild(ov);
    ov.addEventListener('click', (e) => { if (e.target === ov) ov.classList.add('hidden'); });
    ov.querySelector('#eeCancel').onclick = () => ov.classList.add('hidden');
    entryEditOverlay = ov;
    return ov;
  }
  function editEntry(id) {
    const loc = findEntryLocation(id);
    if (!loc) return;
    const entry = data[loc.category][loc.index];
    if (!entry) return;
    const ov = ensureEntryEditOverlay();
    const body = ov.querySelector('#eeBody');
    const isDist = entry.distance !== undefined && entry.distance !== null;
    const hasSets = !isDist && Array.isArray(entry.sets) && entry.sets.length > 0;
    const hasAttempts = !isDist && !hasSets && Array.isArray(entry.attempts) && entry.attempts.length > 0;
    const vars = exerciseVariations(entry.exercise);
    const esc = escapeHtml;
    const num = v => (v == null || v === '' ? '' : v);
    const optHtml = (list, cur, blank) => {
      const all = cur && !list.includes(cur) ? list.concat(cur) : list;
      return `<option value="">${blank}</option>` + all.map(v => `<option value="${esc(v)}"${v === cur ? ' selected' : ''}>${esc(v)}</option>`).join('');
    };
    const rpeOpts = cur => '<option value="">RPE</option>' + [5, 6, 7, 8, 9, 10].map(n => `<option value="${n}"${Number(cur) === n ? ' selected' : ''}>${n}</option>`).join('');
    const flagOpts = st => { const v = st.pain && st.formBroke ? 'both' : st.pain ? 'pain' : st.formBroke ? 'broke' : ''; return [['', 'Flag'], ['broke', 'Form broke'], ['pain', 'Pain'], ['both', 'Pain + form broke']].map(o => `<option value="${o[0]}"${o[0] === v ? ' selected' : ''}>${o[1]}</option>`).join(''); };
    const setRow = (s, i) => {
      s = (s && typeof s === 'object') ? s : { reps: s };
      const uni = s.left !== undefined;
      const main = uni
        ? `<input type="number" min="0" data-f="left" value="${num(s.left)}" placeholder="L" aria-label="Left" /><input type="number" min="0" data-f="right" value="${num(s.right)}" placeholder="R" aria-label="Right" />`
        : `<input type="number" min="0" data-f="reps" value="${num(s.reps)}" placeholder="${entry.isometric ? 'sec' : 'reps'}" aria-label="${entry.isometric ? 'Seconds' : 'Reps'}" />`;
      return `<div class="ee-set" data-uni="${uni ? 1 : 0}"><span class="set-num">${i + 1}</span>${main}` +
        `<input type="number" min="0" data-f="ecc" value="${num(s.eccentric)}" placeholder="ecc s" aria-label="Eccentric seconds" />` +
        `<input type="number" step="0.5" data-f="kg" value="${s.kg == null || s.kg === '' ? '' : round2(kgToDisplay(Number(s.kg)))}" placeholder="±${weightUnitLabel()}" aria-label="Weight" />` +
        (vars.length || s.variation ? `<select data-f="var" aria-label="Variation">${optHtml(vars, s.variation || '', 'Variation')}</select>` : '') +
        `<select data-f="equip" aria-label="Equipment">${optHtml(equipmentList, s.equipment || '', 'Equipment')}</select><select data-f="rpe" aria-label="RPE">${rpeOpts(s.rpe)}</select><select data-f="flag" aria-label="Flag">${flagOpts(s)}</select>${i > 0 ? `<button type="button" class="chain-pill ee-chain${s.chain ? ' on' : ''}" aria-pressed="${s.chain ? 'true' : 'false'}" data-act="chain"><i class="fa-solid fa-link" aria-hidden="true"></i> Chained to previous</button>` : ''}<button type="button" class="text-btn ee-uni" data-act="uni" title="Switch between one value and left/right">${uni ? '1 value' : 'L/R'}</button></div>`;
    };
    let h = `<div class="ee-field"><label for="eeDate">Date</label><input type="date" id="eeDate" value="${esc(entry.date)}" /></div>`;
    if (isDist) {
      h += `<div class="ee-field"><label for="eeDist">Distance (${distanceUnitLabel()})</label><input type="number" step="0.01" min="0" id="eeDist" value="${round2(kmToDisplay(entry.distance))}" /></div>` +
        `<div class="ee-field"><label for="eeTime">Time (e.g. 2:50)</label><input type="text" id="eeTime" value="${entry.timeMinutes != null ? esc(timeMinutesToInputString(entry.timeMinutes)) : ''}" /></div>` +
        `<div class="ee-field"><label for="eeRuck">Rucking (${weightUnitLabel()})</label><input type="number" step="0.5" min="0" id="eeRuck" value="${entry.ruckKg != null ? round2(kgToDisplay(entry.ruckKg)) : ''}" /></div>` +
        `<div class="ee-field"><label for="eeElev">Elevation (${elevationUnitLabel()})</label><input type="number" step="1" min="0" id="eeElev" value="${entry.elevation != null ? round2(mToDisplay(entry.elevation)) : ''}" /></div>` + (vars.length || entry.variation ? `<div class="ee-field"><label for="eeDistVar">Variation</label><select id="eeDistVar">${optHtml(vars, entry.variation || '', 'None')}</select></div>` : '');
    } else if (hasSets) {
      h += '<div class="ee-field"><label>Sets</label><div id="eeSets">' + entry.sets.map(setRow).join('') + '</div><div class="ee-btns"><button type="button" class="text-btn" id="eeAddSet">+ Add set</button><button type="button" class="text-btn text-btn-danger" id="eeDelSet">− Remove last</button></div></div>';
    } else if (hasAttempts) {
      h += `<div class="ee-field"><label for="eeAttempts">Attempts (seconds, comma separated)</label><input type="text" id="eeAttempts" value="${esc(entry.attempts.join(', '))}" /></div>`;
    }
    h += `<div class="ee-field"><label for="eeNotes">Notes</label><textarea id="eeNotes" rows="2">${esc(entry.notes || '')}</textarea></div>`;
    body.innerHTML = h;
    ov.querySelector('#eeTitle').textContent = 'Edit · ' + (entry.exercise || '');
    const setsBox = body.querySelector('#eeSets');
    if (setsBox) {
      setsBox.onclick = (e) => {
        const cp = e.target.closest('.ee-chain');
        if (cp) { cp.classList.toggle('on'); cp.setAttribute('aria-pressed', String(cp.classList.contains('on'))); return; }
        const b = e.target.closest('[data-act="uni"]');
        if (!b) return;
        const row = b.closest('.ee-set');
        const f = k => { const el = row.querySelector(`[data-f="${k}"]`); return el ? el.value : ''; };
        let st;
        if (row.dataset.uni === '1') { const l = f('left'), r = f('right'); st = { reps: (l === '' || r === '') ? (l || r) : Math.min(Number(l), Number(r)) }; }
        else { const v = f('reps'); st = { left: v, right: v }; }
        st.eccentric = f('ecc');
        st.kg = f('kg') === '' ? null : kgFromInput(f('kg'));
        st.variation = row.querySelector('[data-f="var"]') ? f('var') : '';
        st.equipment = f('equip');
        st.rpe = f('rpe') ? Number(f('rpe')) : undefined;
        { const cb = row.querySelector('.ee-chain'); if (cb && cb.classList.contains('on')) st.chain = true; }
        const fv2 = f('flag'); st.pain = fv2 === 'pain' || fv2 === 'both'; st.formBroke = fv2 === 'broke' || fv2 === 'both';
        const tmp = document.createElement('div');
        tmp.innerHTML = setRow(st, Array.prototype.indexOf.call(setsBox.children, row));
        setsBox.replaceChild(tmp.firstElementChild, row);
      };
      body.querySelector('#eeAddSet').onclick = () => {
        const last = setsBox.lastElementChild;
        const proto = last && last.dataset.uni === '1' ? { left: '', right: '' } : { reps: '' };
        const tmp = document.createElement('div');
        tmp.innerHTML = setRow(proto, setsBox.children.length);
        setsBox.appendChild(tmp.firstElementChild);
      };
      body.querySelector('#eeDelSet').onclick = () => { if (setsBox.children.length > 1) setsBox.lastElementChild.remove(); };
    }
    ov.querySelector('#eeSave').onclick = () => {
      const date = body.querySelector('#eeDate').value;
      if (!/^\d{4}-\d{2}-\d{2}$/.test(date)) { alert('Pick a valid date.'); return; }
      const val = sel => body.querySelector(sel).value.trim();
      if (isDist) {
        const d = val('#eeDist'); if (d !== '' && !isNaN(Number(d))) entry.distance = displayToKm(Number(d));
        const ru = val('#eeRuck'); entry.ruckKg = ru === '' ? null : displayToKg(Number(ru));
        const el = val('#eeElev'); entry.elevation = el === '' ? null : displayToM(Number(el));
        const t = val('#eeTime'); entry.timeMinutes = t === '' ? null : parseTimeInput(t);
        const dvEl = body.querySelector('#eeDistVar'); if (dvEl) entry.variation = dvEl.value || null;
      } else if (hasSets) {
        const sets = [];
        Array.from(body.querySelectorAll('.ee-set')).forEach((row, i) => {
          const f = k => { const el = row.querySelector(`[data-f="${k}"]`); return el ? el.value.trim() : ''; };
          const old = (entry.sets[i] && typeof entry.sets[i] === 'object') ? entry.sets[i] : {};
          const st = {};
          if (row.dataset.uni === '1') {
            if (f('left') === '' && f('right') === '') return;
            st.left = Number(f('left')) || 0; st.right = Number(f('right')) || 0;
          } else {
            if (f('reps') === '') return;
            st.reps = Number(f('reps'));
          }
          st.eccentric = f('ecc') === '' ? null : Number(f('ecc'));
          st.kg = f('kg') === '' ? null : kgFromInput(f('kg'));
          st.angle = old.angle || null;
          if (f('rpe')) st.rpe = Number(f('rpe'));
          const fv = f('flag'); if (fv === 'pain' || fv === 'both') st.pain = true; if (fv === 'broke' || fv === 'both') st.formBroke = true;
          { const cb = row.querySelector('.ee-chain'); if (i > 0 && cb && cb.classList.contains('on')) st.chain = true; }
          st.equipment = f('equip') || null;
          st.variation = row.querySelector('[data-f="var"]') ? (f('var') || null) : (old.variation || null);
          sets.push(st);
        });
        if (!sets.length) { alert('Keep at least one set with a value.'); return; }
        entry.sets = sets;
      } else if (hasAttempts) {
        const nums = val('#eeAttempts').split(',').map(x => x.trim()).filter(x => x !== '').map(Number).filter(n => !isNaN(n));
        if (nums.length) entry.attempts = nums;
      }
      if (date !== entry.date) { entry.date = date; entry.supersetId = null; } // a superset is a same-day grouping
      entry.notes = val('#eeNotes');
      entry.updatedAt = Date.now();
      saveData();
      recalcPRs(entry.exercise);
      ov.classList.add('hidden');
      renderEntries(); renderCalendar(); renderModifiers();
      showToast('Entry updated');
    };
    ov.classList.remove('hidden');
  }

