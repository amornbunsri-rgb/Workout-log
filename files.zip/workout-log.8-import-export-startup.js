  // ---- Export / Import ----
  // the Excel library is large, so it is only fetched the first time you export (the service worker keeps a copy for offline use)
  let xlsxPromise = null;
  function loadXlsx() {
    if (window.XLSX) return Promise.resolve();
    if (!xlsxPromise) xlsxPromise = new Promise((res, rej) => {
      const sc = document.createElement('script');
      sc.src = 'https://cdnjs.cloudflare.com/ajax/libs/xlsx/0.18.5/xlsx.full.min.js';
      sc.onload = res;
      sc.onerror = () => { xlsxPromise = null; rej(new Error('xlsx')); };
      document.head.appendChild(sc);
    });
    return xlsxPromise;
  }
  document.getElementById('exportXlsxBtn').onclick = () => {
    showToast('Preparing the Excel file…');
    loadXlsx().then(exportXlsx, () => showToast('Could not load the Excel library. Check your connection and try again.'));
  };
  function exportXlsx() {
    const wb = XLSX.utils.book_new();
    // use whichever is larger: the current set count, or the most sets any logged entry actually has
    let maxSetsInData = numSets;
    categories.forEach(cat => (data[cat] || []).forEach(e => {
      if (e.sets && e.sets.length > maxSetsInData) maxSetsInData = e.sets.length;
    }));
    categories.forEach(cat => {
      const rows = (data[cat] || []).slice().sort((a, b) => a.date.localeCompare(b.date));
      const header = ['Date', 'Exercise', 'Type', 'Left/Right', 'Weight (kg)', 'Distance (km)', 'Superset', 'Attempts (s)', 'Equipment', 'Time (min)', 'Elevation (m)', 'Rucking (kg)', 'Run variation'];
      for (let i = 1; i <= maxSetsInData; i++) { header.push(`Set ${i} value`); header.push(`Set ${i} ecc (s)`); header.push(`Set ${i} kg`); header.push(`Set ${i} angle`); header.push(`Set ${i} equipment`); header.push(`Set ${i} variation`); header.push(`Set ${i} RPE`); header.push(`Set ${i} pain / form`); header.push(`Set ${i} chained`); }
      header.push('Notes');
      const sheetData = [header];
      rows.forEach(e => {
        const sets = e.sets || [];
        const row = [e.date, e.exercise || '', e.isometric ? 'Isometric (sec)' : 'Reps', e.unilateral ? 'Yes' : '', e.weightKg || '', e.distance || '', e.supersetId || '', (e.attempts && e.attempts.length) ? e.attempts.join(', ') : '', e.equipment || '', e.timeMinutes != null ? e.timeMinutes : '', e.elevation != null ? e.elevation : '', e.ruckKg != null ? e.ruckKg : '', e.variation || ''];
        for (let i = 0; i < maxSetsInData; i++) {
          const s = sets[i];
          if (s && typeof s === 'object') {
            row.push(s.left !== undefined ? `L${s.left}/R${s.right}` : (s.reps !== undefined ? s.reps : ''));
            row.push(s.eccentric !== undefined && s.eccentric !== null ? s.eccentric : '');
            row.push(s.kg !== undefined && s.kg !== null ? s.kg : '');
            row.push(s.angle || '');
            row.push(s.equipment || '');
            row.push(s.variation || '');
            row.push(s.rpe || '');
            row.push([s.pain ? 'pain' : '', s.formBroke ? 'form broke' : ''].filter(Boolean).join(' + '));
            row.push(s.chain ? 'yes' : '');
          } else {
            row.push(s !== undefined ? s : '');
            for (let k = 0; k < 8; k++) row.push('');
          }
        }
        row.push(e.notes || '');
        sheetData.push(row);
      });
      const ws = XLSX.utils.aoa_to_sheet(sheetData);
      const cols = [{wch:12},{wch:20},{wch:14},{wch:10},{wch:8},{wch:11},{wch:14},{wch:20},{wch:12},{wch:11},{wch:11},{wch:11},{wch:14}];
      for (let i = 0; i < maxSetsInData; i++) { cols.push({wch:6}); cols.push({wch:6}); cols.push({wch:6}); cols.push({wch:10}); cols.push({wch:12}); cols.push({wch:14}); cols.push({wch:6}); cols.push({wch:14}); cols.push({wch:8}); }
      cols.push({wch:30});
      ws['!cols'] = cols;
      XLSX.utils.book_append_sheet(wb, ws, cat.substring(0, 31));
    });
    if (bodyweightLog.length) {
      const bwRows = [['Date', 'Bodyweight (kg)']].concat(bodyweightLog.slice().sort((a, b) => a.date.localeCompare(b.date)).map(e => [e.date, e.kg]));
      const bwSheet = XLSX.utils.aoa_to_sheet(bwRows);
      bwSheet['!cols'] = [{wch:12},{wch:16}];
      const taken = new Set(categories.map(c => c.substring(0, 31).toLowerCase()));
      XLSX.utils.book_append_sheet(wb, bwSheet, taken.has('bodyweight') ? 'Bodyweight log' : 'Bodyweight');
    }
    const stamp = timestampForFilename();
    XLSX.writeFile(wb, `workout-log-${stamp}.xlsx`);
    menuPanel.classList.add('hidden');
  }


  function buildBackupPayload() {
    return {
      weightsInKg: true, deleted: deletedEntries, removedExercises,
      data, lists: { categories, exercises: exerciseLists, colors: categoryColors }, layout, blocks: { names: blocks, refs: blockRefs, plans: planBlocks },
      equipment: { list: equipmentList, colors: equipmentColors },
      bodyweight: bodyweightLog,
      skills: skillLines,
      parts: Object.keys(backupParts).reduce((o, k) => { o[k] = backupParts[k].get(); return o; }, {})
    };
  }
  const backupParts = {};
  const PREFS_TS = 'workout-log-prefs-ts-v1';
  backupParts.prefs = {
    get: () => ({ units: unitSystem, weekStart, at: Number(localStorage.getItem(PREFS_TS)) || 0 }),
    merge: (p) => {
      if (!p || !(p.at > (Number(localStorage.getItem(PREFS_TS)) || 0))) return; // only a more recent change from another device is applied
      if (p.units === 'metric' || p.units === 'imperial') { unitSystem = p.units; saveUnits(unitSystem); renderUnitsToggle(); renderModifiers(); renderBodyweightList(); }
      if (p.weekStart === 0 || p.weekStart === 1) { weekStart = p.weekStart; lsSet(Shared.WEEK_KEY, weekStart); renderWeekToggle(); renderCalendar(); renderEntries(); }
      lsSet(PREFS_TS, p.at);
    }
  };
  backupParts.planProgress = {
    get: () => ({ meta: planMeta, progress: planProgress }),
    merge: (inc) => {
      if (!inc || typeof inc !== 'object') return;
      Object.keys(inc.meta || {}).forEach(k => { if (!planMeta[k]) planMeta[k] = inc.meta[k]; });
      Object.keys(inc.progress || {}).forEach(uid => {
        const src = inc.progress[uid] || {};
        const a = planProgress[uid] || (planProgress[uid] = { started: src.started, sessions: [] });
        const seen = new Set(a.sessions.map(x => x.date + '|' + x.day));
        (src.sessions || []).forEach(x => { if (x && x.date && !seen.has(x.date + '|' + x.day)) { a.sessions.push(x); seen.add(x.date + '|' + x.day); } });
        a.sessions.sort((x, y) => x.date.localeCompare(y.date));
        if (a.sessions.length) a.started = a.sessions[0].date;
      });
      savePlanMeta(); savePlanProgress(); renderPlanStrip();
    }
  }; // extra data owned by the external scripts: { key: { get(), merge(incoming) } }

  // Hooks used by workout-profile.js (avatar, progress photos, Drive sync).
  window.WorkoutApp = {
    buildBackupPayload: () => buildBackupPayload(),
    categoryColor: (c) => getCategoryColor(c),
    recalcPRs: (n) => recalcPRs(n),
    logRoutineEntry: (n, sec, notes) => logRoutineEntry(n, sec, notes),
    fillPatterns: () => fillMissingPatterns(),
    registerPlanBlock: (n, m) => { planMeta[n] = m; savePlanMeta(); renderPlanStrip(); },
    planSessions: (uid) => ((planProgress[uid] || {}).sessions || []).length,
    metricsInfo: () => { const n = currentExerciseName(); return { isometric: !!n && isIsometricExercise(n) && !isDistanceExercise(n), distance: !!n && isDistanceExercise(n) }; },
    refileExercise: (n, f, t) => refileExercise(n, f, t),
    refreshAfterRefile: () => { renderBlockSelect(); updateExercisePicker(); render(); },
    importBackupText: (text, opts) => importBackupText(text, opts),
    showToast: (msg) => showToast(msg),
    registerBackupPart: (key, part) => { backupParts[key] = part; },
    addSkillTemplates: (t) => addSkillTemplates(t),
    ensureExercises: (items) => ensureExercises(items),
    exerciseVariations: (name) => exerciseVariations(name),
    refreshVariations: () => { updateMetricsSection(currentExerciseName()); renderModifiers(); },
    listExercisesForVariations: () => listExercisesForVariations(),
    setCustomVariations: (cat, name, list) => setCustomVariations(cat, name, list),
    planMerge: (c, n, t, v) => planMerge(c, n, t, v),
    applyMerge: (c, n, t, v) => applyMerge(c, n, t, v),
    snapshotForUndo: () => snapshotForUndo(),
    hasMergeUndo: () => hasMergeUndo(),
    undoLastMerge: () => undoLastMerge(),
    startPlanBlock: (name, refs) => startPlanBlock(name, refs),
    deletePlanBlocks: (names) => deletePlanBlocks(names),
    skillLineNames: () => skillLines.map(l => l.name),
    weightUnit: () => weightUnitLabel(),
    // numbers behind the achievements (see workout-library.json)
    stats: () => {
      const dates = new Set(); let entries = 0, prs = 0;
      categories.forEach(cat => (data[cat] || []).forEach(e => { entries++; if (e.date) dates.add(e.date); if (e.isPR) prs++; }));
      const weeks = Array.from(new Set(Array.from(dates).map(getWeekStart))).sort();
      let streakWeeks = 0, run = 0, prev = null;
      weeks.forEach(w => {
        const gap = prev ? Math.round((new Date(w + 'T00:00:00') - new Date(prev + 'T00:00:00')) / 86400000) : 0;
        run = (prev && gap === 7) ? run + 1 : 1;
        if (run > streakWeeks) streakWeeks = run;
        prev = w;
      });
      const skillSteps = skillLines.reduce((n, l) => n + l.steps.filter(s => s.doneDate).length, 0);
      return { entries, workoutDays: dates.size, prs, streakWeeks, skillSteps, bodyweightLogs: bodyweightLog.length };
    },
    renderBodyweight: () => renderBodyweightList(),
    // latest weigh-in on or before a date, formatted in the user's unit ('' if none yet)
    bodyweightOn: (iso) => {
      const past = bodyweightLog.filter(e => e.date <= iso).sort((a, b) => b.date.localeCompare(a.date))[0];
      return past ? `${round2(kgToDisplay(past.kg))} ${weightUnitLabel()}` : '';
    }
  };

  document.getElementById('exportJsonBtn').onclick = () => {
    const payload = buildBackupPayload();
    const blob = new Blob([JSON.stringify(payload, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    const stamp = timestampForFilename();
    a.href = url;
    a.download = `workout-log-backup-${stamp}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    menuPanel.classList.add('hidden');
  };

  // Auto-carries the current data to the graph page over postMessage instead of
  // requiring a manual export + "Load backup" import there. Two paths, both harmless
  // to run together: (1) a fresh graph window announces itself as ready once its own
  // message listener is live, and we reply with the data then; (2) if the graph
  // window was already open (window.open just refocuses it, no reload/no fresh
  // "ready" signal), a short delayed push after opening covers that case too.
  let graphWindowRef = null;
  function sendDataToGraphWindow(win) {
    if (!win) return;
    try { win.postMessage({ type: 'workout-data', backup: buildBackupPayload() }, '*'); } catch (e) { /* ignore */ }
  }
  window.addEventListener('message', (ev) => {
    if (ev.data && ev.data.type === 'graph-ready' && graphWindowRef && ev.source === graphWindowRef) {
      sendDataToGraphWindow(graphWindowRef);
    }
  });
  const graphLink = document.getElementById('graphLink');
  // Hosted on a web address (https / localhost) both pages share the same saved data, so the graph simply opens
  // in this window like any other link. Only a copy opened straight from disk needs the separate-window hand-off.
  graphLink.addEventListener('click', () => {
    if (location.protocol !== 'file:') return;
    // opened from disk: leave the current data where the graph page looks for it, then navigate normally (same window)
    try { localStorage.setItem('workout-graph-cache-v1', JSON.stringify({ backup: buildBackupPayload(), savedAt: Date.now() })); } catch (err) { /* ignore */ }
  });

  const importFileInput = document.getElementById('importFile');
  document.getElementById('importJsonBtn').onclick = () => {
    importFileInput.click();
    menuPanel.classList.add('hidden');
  };
  importFileInput.onchange = (e) => {
    const file = e.target.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (evt) => {
      importBackupText(evt.target.result);
      importFileInput.value = '';
    };
    reader.readAsText(file);
  };
  // Merges a backup (JSON text) into the app. Returns true on success. Also used by Google Drive sync.
  function importBackupText(text, opts) {
      try {
        const parsed = JSON.parse(text);
        const incomingData = parsed.data || parsed;
        // exercises removed on the other device: remember them, so they are not added back below
        if (parsed.removedExercises && typeof parsed.removedExercises === 'object') {
          Object.keys(parsed.removedExercises).forEach(k => { const t = Number(parsed.removedExercises[k]) || 0; if (t > (removedExercises[k] || 0)) removedExercises[k] = t; });
          saveRemovedEx();
        }
        // an older backup has set weights as typed: treat them as the unit currently selected
        if (!parsed.weightsInKg && unitSystem === 'imperial') {
          Object.keys(incomingData).forEach(c => (Array.isArray(incomingData[c]) ? incomingData[c] : []).forEach(en => (en && en.sets || []).forEach(st => {
            if (st && typeof st === 'object' && st.kg != null && st.kg !== '' && !isNaN(Number(st.kg))) st.kg = Math.round(Number(st.kg) / KG_TO_LB * 1000) / 1000;
          })));
        }
        if (parsed.lists && parsed.lists.categories && parsed.lists.exercises) {
          parsed.lists.categories.forEach(c => {
            if (c === LEGACY_MAIN_CATEGORY) return;
            if (!categories.includes(c)) categories.push(c);
            if (!exerciseLists[c]) exerciseLists[c] = [];
            if (!data[c]) data[c] = [];
          });
          Object.keys(parsed.lists.exercises).forEach(c => {
            if (c === LEGACY_MAIN_CATEGORY || !categories.includes(c)) return;
            const incomingEx = migrateList(parsed.lists.exercises[c] || []);
            const merged = (exerciseLists[c] || []).slice();
            incomingEx.forEach(ex => {
              const hit = merged.find(e => e.name.toLowerCase() === ex.name.toLowerCase());
              if (hit) { if (Array.isArray(ex.variations) && ex.variations.length) hit.variations = Array.from(new Set((hit.variations || []).concat(ex.variations))); } // variation lists add up
              else if (!exRemovedAfter(ex)) merged.push(ex);
            });
            exerciseLists[c] = merged;
          });
          if (parsed.lists.colors) categoryColors = Object.assign({}, parsed.lists.colors, categoryColors);
          saveLists();
        }
        if (parsed.layout && Array.isArray(parsed.layout)) {
          layout = parsed.layout.filter(p => MODULE_LABELS[p.id]);
          saveLayout();
        }
        if (parsed.blocks && Array.isArray(parsed.blocks.names) && parsed.blocks.refs) {
          parsed.blocks.names.forEach(name => {
            if (!blocks.includes(name)) blocks.push(name);
            if (!blockRefs[name]) blockRefs[name] = [];
          });
          Object.keys(parsed.blocks.refs).forEach(name => {
            const incomingRefs = parsed.blocks.refs[name] || [];
            const existingNames = new Set((blockRefs[name] || []).map(r => r.name));
            const merged = (blockRefs[name] || []).slice();
            incomingRefs.forEach(r => { if (r && r.name && !existingNames.has(r.name)) merged.push(r); });
            blockRefs[name] = merged;
          });
          (Array.isArray(parsed.blocks.plans) ? parsed.blocks.plans : []).forEach(n => { if (blocks.includes(n) && !planBlocks.includes(n)) planBlocks.push(n); });
          saveBlocks();
          renderBlockSelect();
        }
        if (parsed.equipment && Array.isArray(parsed.equipment.list)) {
          parsed.equipment.list.forEach(name => {
            if (typeof name === 'string' && name.trim() && !equipmentList.includes(name)) {
              equipmentList.push(name);
              const c = parsed.equipment.colors && parsed.equipment.colors[name];
              if (c && !equipmentColors[name]) equipmentColors[name] = c;
            }
          });
          saveEquipment();
          renderEquipmentSelect();
        }
        if (Array.isArray(parsed.bodyweight)) {
          const haveDates = new Set(bodyweightLog.map(e => e.date));
          parsed.bodyweight.forEach(e => {
            if (e && /^\d{4}-\d{2}-\d{2}$/.test(e.date) && Number(e.kg) > 0 && !haveDates.has(e.date)) {
              bodyweightLog.push({ id: e.id || (Date.now().toString() + Math.random().toString(36).slice(2, 6)), date: e.date, kg: Number(e.kg) });
              haveDates.add(e.date);
            }
          });
          saveBodyweight();
        }
        if (Array.isArray(parsed.skills)) {
          parsed.skills.map(cleanSkillLine).filter(Boolean).forEach(l => {
            if (!skillLines.some(x => x.name.toLowerCase() === l.name.toLowerCase())) skillLines.push(l);
          });
          saveSkills();
        }
        // deletions travel with the backup: an entry deleted on another device is removed here too
        if (parsed.deleted && typeof parsed.deleted === 'object') Object.keys(parsed.deleted).forEach(id => { if (!deletedEntries[id]) deletedEntries[id] = parsed.deleted[id]; });
        const where = {};
        categories.forEach(c => (data[c] || []).forEach(en => { where[en.id] = c; }));
        // an entry moved to another category on the other device (merge, tidy categories) moves here too, if that copy is newer
        categories.forEach(c => {
          if (!Array.isArray(incomingData[c])) return;
          incomingData[c].forEach(en => {
            if (!en || deletedEntries[en.id]) return;
            const from = where[en.id];
            if (from === undefined || from === c) return;
            const cur = (data[from] || []).find(x => x.id === en.id);
            if ((en.updatedAt || 0) > ((cur || {}).updatedAt || 0)) {
              data[from] = data[from].filter(x => x.id !== en.id);
              (data[c] = data[c] || []).push(en);
              where[en.id] = c;
            }
          });
        });
        categories.forEach(c => {
          const merged = (data[c] || []).filter(en => !deletedEntries[en.id]);
          if (Array.isArray(incomingData[c])) {
            incomingData[c].forEach(en => {
              if (!en || deletedEntries[en.id]) return;
              if (where[en.id] === undefined) { merged.push(en); where[en.id] = c; }
              else if (where[en.id] === c && (en.updatedAt || 0) > ((merged.find(x => x.id === en.id) || {}).updatedAt || 0)) {
                const i = merged.findIndex(x => x.id === en.id);
                if (i >= 0) merged[i] = en; // the copy edited more recently wins
              }
            });
          }
          data[c] = merged;
        });
        // exercises removed elsewhere that no longer have any entries here disappear too
        categories.forEach(c => { exerciseLists[c] = (exerciseLists[c] || []).filter(ex => !exRemovedAfter(ex) || categories.some(cc => (data[cc] || []).some(en => en.exercise === ex.name))); });
        saveLists();
        saveDeleted();
        saveData();
        updateExercisePicker();
        applyLayout();
        render();
        renderCatEditList();
        if (parsed.parts && typeof parsed.parts === 'object') {
          Object.keys(parsed.parts).forEach(k => { if (backupParts[k]) { try { backupParts[k].merge(parsed.parts[k]); } catch (e) { /* skip a bad part */ } } });
        }
        if (!(opts && opts.quiet)) showToast('Backup imported');
        return true;
      } catch (err) {
        errEl.textContent = 'That file could not be read as a valid backup.';
        errEl.classList.remove('hidden');
        return false;
      }
  }

  function renderThemeSwatches() {
    const wrap = document.getElementById('themeSwatches');
    wrap.innerHTML = '';
    THEMES.forEach((t, idx) => {
      const b = document.createElement('button');
      b.className = 'theme-swatch' + (idx === themeIndex ? ' active' : '');
      b.style.background = t.accent;
      b.title = t.name;
      b.setAttribute('aria-label', 'Theme: ' + t.name);
      b.onclick = () => {
        themeIndex = idx;
        applyTheme(themeIndex);
        saveTheme(themeIndex);
        renderThemeSwatches();
      };
      wrap.appendChild(b);
    });
  }

  // Leaving this page (for example to look at the graphs) and coming back reloads it, so the work in progress that isn't
  // logged yet is parked in sessionStorage (this tab only, cleared when the tab or app is closed) and put back on return.
  const SESSION_KEY = 'workout-log-session-v1';
  function hasTypedValues() {
    return Array.from(document.querySelectorAll('#setsGrid input, #attemptsGrid input[type="number"]')).some(i => i.value !== '') || notesInput.value.trim() !== '';
  }
  function saveSession() {
    if (location.hash === '#recalc') return; // the hidden copy opened by the graph page must not touch the saved session
    try {
      if (selectedExercise && hasTypedValues()) snapshotDraft(selectedExercise);
      sessionStorage.setItem(SESSION_KEY, JSON.stringify({
        at: Date.now(), date: dateInput.value, category: active, block: activeBlock, exercise: selectedExercise,
        drafts: exerciseDrafts, superset: activeSuperset, members: Array.from(supersetMembers)
      }));
    } catch (e) { /* storage unavailable: nothing is lost that was saved before */ }
  }
  window.addEventListener('pagehide', saveSession);
  document.addEventListener('visibilitychange', () => { if (document.visibilityState === 'hidden') saveSession(); });
  function restoreSession() {
    if (location.hash === '#recalc') return;
    let s = null;
    try { s = JSON.parse(sessionStorage.getItem(SESSION_KEY)); } catch (e) { return; }
    if (!s || !(Date.now() - s.at < 12 * 3600 * 1000)) return;
    try {
      if (s.date && /^\d{4}-\d{2}-\d{2}$/.test(s.date)) { dateInput.value = s.date; updateHeaderDateDisplay(); }
      if (s.category && categories.includes(s.category)) active = s.category;
      activeBlock = (s.block && blocks.includes(s.block)) ? s.block : null;
      exerciseDrafts = (s.drafts && typeof s.drafts === 'object') ? s.drafts : {};
      if (s.superset && s.superset.id) { activeSuperset = s.superset; supersetMembers = new Set(s.members || []); }
      renderBlockSelect();
      updateExercisePicker();
      if (s.exercise && sortedExerciseList().some(p => p.exObj.name === s.exercise)) {
        selectedExercise = s.exercise;
        updateExercisePicker();
        restoreDraft(s.exercise);
        renderModifiers();
      }
      updateSupersetUI();
    } catch (e) { /* a stale or odd session is simply ignored */ }
  }

  applyMode(themeMode);
  renderModeToggle();
  applyTheme(themeIndex);
  buildSetsGrid();
  buildAttemptsGrid();
  loadData();
  saveData(); // also compacts data saved by an older version
  // one-time: set weights used to be stored as typed; from now on they are stored in kg
  (function migrateWeightsToKg() {
    const FLAG = 'workout-log-weights-kg-v1';
    try { if (localStorage.getItem(FLAG)) return; } catch (e) { return; }
    if (unitSystem === 'imperial') {
      categories.forEach(c => (data[c] || []).forEach(en => (en.sets || []).forEach(st => {
        if (st && typeof st === 'object' && st.kg != null && st.kg !== '' && !isNaN(Number(st.kg))) st.kg = Math.round(Number(st.kg) / KG_TO_LB * 1000) / 1000;
      })));
      saveData();
    }
    lsSet(FLAG, '1');
  })();
  loadLayout();
  renderBlockSelect();
  renderEquipmentSelect();
  fillMissingPatterns();
  updateSkillsBadge();
  updateExercisePicker();
  applyLayout();
  renderThemeSwatches();
  navigateTo(({ '#history': 'history', '#config': 'config', '#skills': 'skills' })[location.hash] || 'home');
  restoreSession();
  render();
  // the graph page's "Recalculate PRs" opens this page hidden with #recalc and waits for the answer
  if (location.hash === '#recalc' && window.parent !== window) {
    const n = recalcPRs();
    try { window.parent.postMessage({ type: 'recalc-done', n }, location.origin); } catch (e) { /* ignore */ }
  }
})();
