  // ---- Blocks: named groupings of exercises pulled from any category ----
  let assigningBlock = null; // name of the block currently showing its assignment checklist, or null

  function renderBlockSelect() {
    const sel = document.getElementById('blockSelect');
    if (!sel) return;
    if (activeBlock && (!blocks.includes(activeBlock) || hiddenBlocks.includes(activeBlock))) activeBlock = null;
    sel.innerHTML = '';
    const noneOpt = document.createElement('option');
    noneOpt.value = '';
    noneOpt.textContent = 'No block';
    sel.appendChild(noneOpt);
    const visible = blocks.filter(name => !hiddenBlocks.includes(name));
    const addGroup = (label, names) => {
      if (!names.length) return;
      const parent = planBlocks.length ? Object.assign(document.createElement('optgroup'), { label }) : sel;
      names.forEach(name => {
        const opt = document.createElement('option');
        opt.value = name;
        opt.textContent = name;
        parent.appendChild(opt);
      });
      if (parent !== sel) sel.appendChild(parent);
    };
    addGroup('Blocks', visible.filter(n => !planBlocks.includes(n)));
    addGroup('Plans', visible.filter(n => planBlocks.includes(n)));
    sel.value = activeBlock || '';
    sel.onchange = () => { activeBlock = sel.value || null; updateExercisePicker(); render(); };
  }

  let blockListSort = 'added';
  function updateBlockSortBtn() {
    const btn = document.getElementById('blocksSortBtn');
    if (!btn) return;
    const alpha = blockListSort === 'alphabetical';
    btn.innerHTML = `<i class="fa-solid ${alpha ? 'fa-arrow-down-a-z' : 'fa-arrow-down-wide-short'}" aria-hidden="true"></i>`;
    btn.title = `Sort: ${alpha ? 'A–Z' : 'order added'} — tap to change`;
    btn.setAttribute('aria-label', `Sort: ${alpha ? 'A–Z' : 'order added'} (tap to change)`);
  }
  function renderBlockEditList() {
    updateBlockSortBtn();
    const listEl = document.getElementById('blockEditList');
    listEl.innerHTML = '';
    if (!blocks.length) {
      listEl.innerHTML = '<div class="empty" style="padding:4px 0;">No blocks yet — add one below.</div>';
    }
    const blocksInOrder = blockListSort === 'alphabetical' ? blocks.slice().sort((a, b) => a.localeCompare(b)) : blocks;
    blocksInOrder.forEach(name => {
      const row = document.createElement('div');
      row.className = 'edit-row';
      const nameSpan = document.createElement('span');
      nameSpan.className = 'name';
      nameSpan.textContent = `${name} (${(blockRefs[name] || []).length})`;

      const actions = document.createElement('div');
      actions.className = 'actions';

      const assignBtn = document.createElement('button');
      assignBtn.innerHTML = '<i class="fa-solid fa-list-check" aria-hidden="true"></i>';
      assignBtn.title = 'Assign exercises';
      assignBtn.setAttribute('aria-label', 'Assign exercises to ' + name);
      if (assigningBlock === name) assignBtn.classList.add('on');
      assignBtn.onclick = () => {
        assigningBlock = (assigningBlock === name) ? null : name;
        blockAssignSearchQuery = '';
        const searchInput = document.getElementById('blockAssignSearchInput');
        if (searchInput) searchInput.value = '';
        renderBlockEditList();
      };

      const isHidden = hiddenBlocks.includes(name);
      const eyeBtn = document.createElement('button');
      eyeBtn.className = isHidden ? '' : 'eye-on';
      eyeBtn.title = isHidden ? 'Hidden from home page — tap to show' : 'Visible on home page — tap to hide';
      eyeBtn.setAttribute('aria-label', (isHidden ? 'Show' : 'Hide') + ' ' + name + ' on home page');
      eyeBtn.innerHTML = `<i class="fa-solid fa-${isHidden ? 'eye-slash' : 'eye'}" aria-hidden="true"></i>`;
      eyeBtn.onclick = () => {
        hiddenBlocks = isHidden ? hiddenBlocks.filter(n => n !== name) : hiddenBlocks.concat(name);
        saveBlocks();
        renderBlockSelect();
        renderBlockEditList();
      };

      const renameBtn = document.createElement('button');
      renameBtn.innerHTML = '<i class="fa-solid fa-pencil" aria-hidden="true"></i>';
      renameBtn.onclick = () => renameBlock(name);

      const delBtn = document.createElement('button');
      delBtn.className = 'danger';
      delBtn.innerHTML = '<i class="fa-regular fa-trash-can" aria-hidden="true"></i>';
      delBtn.onclick = () => deleteBlock(name);

      actions.appendChild(assignBtn);
      actions.appendChild(eyeBtn);
      actions.appendChild(renameBtn);
      actions.appendChild(delBtn);
      row.appendChild(nameSpan);
      row.appendChild(actions);
      listEl.appendChild(row);
    });
    decorateBulk(listEl, 'blocks', blocksInOrder);
    renderBlockAssignSection();
  }

  // Clicking a category name here only filters this checklist — it never navigates anywhere.
  let blockAssignSearchQuery = "";
  function renderBlockAssignSection() {
    const section = document.getElementById('blockAssignSection');
    if (!assigningBlock || !blocks.includes(assigningBlock)) {
      section.classList.add('hidden');
      return;
    }
    section.classList.remove('hidden');
    document.getElementById('blockAssignName').textContent = assigningBlock;
    const listEl = document.getElementById('blockAssignChecklist');
    listEl.innerHTML = '';
    const included = new Set((blockRefs[assigningBlock] || []).map(r => r.name));
    const q = blockAssignSearchQuery.toLowerCase();
    let any = false;
    categories.forEach(cat => {
      const list = (exerciseLists[cat] || []).filter(e => !q || e.name.toLowerCase().includes(q));
      if (!list.length) return;
      any = true;
      const group = document.createElement('div');
      group.className = 'existing-ex-group';
      const groupLabel = document.createElement('div');
      groupLabel.className = 'existing-ex-group-label';
      groupLabel.textContent = cat;
      group.appendChild(groupLabel);
      list.forEach(e => {
        const row = document.createElement('label');
        row.className = 'existing-ex-row';
        const cb = document.createElement('input');
        cb.type = 'checkbox';
        cb.checked = included.has(e.name);
        cb.onchange = () => toggleBlockExercise(assigningBlock, e.name, cat, cb.checked);
        row.appendChild(cb);
        row.appendChild(document.createTextNode(e.name));
        const editBtn = document.createElement('button');
        editBtn.type = 'button';
        editBtn.innerHTML = '<i class="fa-solid fa-pencil" aria-hidden="true"></i>';
        editBtn.onclick = (ev) => {
          ev.preventDefault(); ev.stopPropagation();
          openExerciseModal({ exObj: e, category: cat, onSaved: () => { renderBlockEditList(); renderAllExercisesList(); renderCatEditList(); } });
        };
        row.appendChild(editBtn);
        group.appendChild(row);
      });
      listEl.appendChild(group);
    });
    if (!any) listEl.innerHTML = `<div class="empty" style="padding:4px 0;">${q ? 'No matching exercises.' : 'Add some exercises to a category first.'}</div>`;
    let addRow = document.getElementById('blockAssignAddBtn');
    if (!addRow) {
      addRow = document.createElement('button');
      addRow.type = 'button';
      addRow.id = 'blockAssignAddBtn';
      addRow.className = 'text-btn';
      addRow.style.marginTop = '8px';
      addRow.innerHTML = '<i class="fa-solid fa-plus" aria-hidden="true"></i> Add new exercise';
      document.getElementById('blockAssignSection').appendChild(addRow);
    }
    addRow.onclick = () => openExerciseModal({
      defaultCategory: categories[0],
      onSaved: (result) => {
        if (result) toggleBlockExercise(assigningBlock, result.name, result.category, true);
        renderBlockEditList();
      }
    });
  }
  document.getElementById('blockAssignSearchInput').addEventListener('input', (e) => {
    blockAssignSearchQuery = e.target.value.trim();
    renderBlockAssignSection();
  });

  function toggleBlockExercise(blockName, name, cat, isChecked) {
    if (!blockRefs[blockName]) blockRefs[blockName] = [];
    if (isChecked) {
      if (!blockRefs[blockName].some(r => r.name === name)) blockRefs[blockName].push({ name, refCategory: cat });
    } else {
      blockRefs[blockName] = blockRefs[blockName].filter(r => r.name !== name);
    }
    saveBlocks();
    renderBlockEditList();
    if (activeBlock === blockName) updateExercisePicker();
  }

  function renameBlock(oldName) {
    const newName = prompt('Rename block', oldName);
    if (!newName || !newName.trim() || newName.trim() === oldName) return;
    const trimmed = newName.trim();
    if (blocks.includes(trimmed)) { alert('A block with that name already exists.'); return; }
    blocks = blocks.map(b => b === oldName ? trimmed : b);
    planBlocks = planBlocks.map(b => b === oldName ? trimmed : b);
    blockRefs[trimmed] = blockRefs[oldName];
    delete blockRefs[oldName];
    if (planMeta[oldName]) { planMeta[trimmed] = planMeta[oldName]; delete planMeta[oldName]; savePlanMeta(); }
    if (hiddenBlocks.includes(oldName)) hiddenBlocks = hiddenBlocks.filter(n => n !== oldName).concat(trimmed);
    if (activeBlock === oldName) activeBlock = trimmed;
    if (assigningBlock === oldName) assigningBlock = trimmed;
    saveBlocks();
    renderBlockSelect();
    renderBlockEditList();
    updateExercisePicker();
  }

  function deleteBlock(name) {
    if (!bulkQuiet && !confirm(`Delete block "${name}"? This only removes the block, not the exercises in it.`)) return;
    blocks = blocks.filter(b => b !== name);
    planBlocks = planBlocks.filter(b => b !== name);
    delete blockRefs[name];
    delete planMeta[name]; savePlanMeta();
    hiddenBlocks = hiddenBlocks.filter(n => n !== name);
    if (activeBlock === name) activeBlock = null;
    if (assigningBlock === name) assigningBlock = null;
    saveBlocks();
    renderBlockSelect();
    renderBlockEditList();
    updateExercisePicker();
  }

  // ---- Plans: starting a plan day builds a block from its exercises, so the picker shows only those ----
  const sameExName = (a, b) => String(a || '').trim().toLowerCase() === String(b || '').trim().toLowerCase();
  const exKey = n => Shared.exKey(n);
  // items: [{ name, category, isometric, unilateral }]. Reuses an exercise you already have (matched by name),
  // otherwise adds it to the matching category. Returns the block refs and how many were new.
  function ensureExercises(items) {
    const refs = [], seen = new Set();
    let added = 0;
    const real = categories.slice();
    (items || []).forEach(it => {
      const key = exKey(it.name);
      if (!key || !real.length) return;
      if (seen.has(key)) {
        const dup = refs.find(r => exKey(r.name) === key);
        if (dup && it.part === 'plan' && dup.part !== 'plan') { dup.sets = it.sets; dup.target = it.target; dup.part = it.part; if (it.variation) dup.variation = it.variation; }
        return;
      }
      seen.add(key);
      let found = null;
      for (const cat of real) {
        const ex = (exerciseLists[cat] || []).find(e => exKey(e.name) === key);
        if (ex) { found = { name: ex.name, refCategory: cat }; break; }
      }
      if (!found) {
        const want = String(it.category || '').toLowerCase();
        const cat = categoryFor(want, real);
        if (!exerciseLists[cat]) exerciseLists[cat] = [];
        exerciseLists[cat].push({
          name: it.name, color: EX_COLOR_PALETTE[exerciseLists[cat].filter(e => e.color).length % EX_COLOR_PALETTE.length],
          isometric: !!it.isometric, unilateral: !!it.unilateral, pattern: it.pattern || undefined, createdAt: Date.now()
        });
        found = { name: it.name, refCategory: cat };
        added++;
      }
      if (it.variation) found.variation = it.variation;
      if (it.target) { found.target = it.target; found.sets = it.sets; found.part = it.part; }
      refs.push(found);
    });
    if (added) { saveLists(); updateExercisePicker(); }
    return { refs, added };
  }
  // Creates (or refreshes) the plan block and switches to it. Returns the block's final name.
  function startPlanBlock(name, refs) {
    let n = name;
    if (blocks.includes(n) && !planBlocks.includes(n)) n = n + ' (plan)'; // never overwrite one of your own blocks
    if (!blocks.includes(n)) blocks.push(n);
    blockRefs[n] = refs;
    if (!planBlocks.includes(n)) planBlocks.push(n);
    hiddenBlocks = hiddenBlocks.filter(h => h !== n);
    saveBlocks();
    const prev = selectedExercise;
    activeBlock = n;
    selectedExercise = '';
    if (prev) switchExerciseInputs(prev, '');
    if (activeSuperset) supersetMembers.clear();
    renderBlockSelect();
    updateExercisePicker();
    renderModifiers();
    render();
    navigateTo('home');
    showToast(`Started "${n}" — only its exercises are shown. Choose "No block" to leave.`);
    return n;
  }

  // ---- Variations: edit lists, and merge look-alike exercises (Wide, Archer, Pull up...) into one exercise + a variation ----
  function addCategoryIfMissing(name) {
    if (categories.includes(name)) return;
    categories.push(name); exerciseLists[name] = []; data[name] = [];
    getCategoryColor(name); saveLists(); saveData(); renderTabs();
  }
  // the library files core work under Core and stretches under Mobility; those categories are created when first needed
  function categoryFor(want, real) {
    const hit = real.find(c => c.toLowerCase() === want);
    if (hit) return hit;
    if (want === 'core' || want === 'mobility' || want === 'run') { const nm = want === 'core' ? 'Core' : want === 'run' ? 'Run' : 'Mobility'; addCategoryIfMissing(nm); return nm; }
    return real.find(c => c === 'Skill') || real[0];
  }
  // Moves an exercise and all its logged entries to another category.
  function refileExercise(name, from, to) {
    const obj = (exerciseLists[from] || []).find(e => e.name === name);
    if (!obj || from === to) return false;
    addCategoryIfMissing(to);
    if ((exerciseLists[to] || []).some(e => e.name.toLowerCase() === name.toLowerCase())) return false;
    exerciseLists[from] = exerciseLists[from].filter(e => e !== obj);
    exerciseLists[to].push(obj);
    const moving = (data[from] || []).filter(e => sameExName(e.exercise, name));
    moving.forEach(e => { e.updatedAt = Date.now(); }); // so other devices pick up the move
    data[from] = (data[from] || []).filter(e => !sameExName(e.exercise, name));
    data[to] = (data[to] || []).concat(moving);
    blocks.forEach(b => (blockRefs[b] || []).forEach(r => { if (r.name === name && r.refCategory === from) r.refCategory = to; }));
    if (selectedExercise === name) selectedExercise = '';
    saveLists(); saveData(); saveBlocks();
    return true;
  }
  // movement pattern of an exercise: your own choice, else the library's, else a guess from the name
  function libPattern(name) {
    const lib = window.WorkoutLibrary && window.WorkoutLibrary.get();
    if (!lib || !Array.isArray(lib.exercises)) return '';
    const k = exKey(name);
    const hit = lib.exercises.find(c => exKey(c.name) === k || (c.aliases || []).some(a => exKey(a) === k));
    return hit && hit.pattern ? hit.pattern : '';
  }
  function fillMissingPatterns() {
    let n = 0;
    categories.forEach(cat => (exerciseLists[cat] || []).forEach(e => {
      if (e.pattern) return;
      const p = libPattern(e.name) || Shared.guessPattern(e.name);
      if (p) { e.pattern = p; n++; }
    }));
    if (n) saveLists();
    return n;
  }
  function logRoutineEntry(name, seconds, notes) {
    const res = ensureExercises([{ name, category: 'Mobility', isometric: true, unilateral: false, pattern: 'mobility' }]);
    const ref = res.refs[0];
    if (!ref) return false;
    const cat = ref.refCategory;
    if (!data[cat]) data[cat] = [];
    data[cat].push({
      id: Date.now().toString(), updatedAt: Date.now(), date: dateInput.value || skillToday(), exercise: ref.name,
      isometric: true, unilateral: false, notes: notes || '', supersetId: null,
      sets: [{ reps: Math.max(1, Math.round(seconds)), eccentric: null, kg: null, angle: null, equipment: null, variation: null }],
      attempts: [], distance: null, isPR: false
    });
    saveData();
    renderEntries(); renderCalendar(); updateExercisePicker();
    showToast('Routine logged as one entry');
    return true;
  }
  const MERGE_UNDO_KEY = 'workout-log-premerge-v1';
  // Entries can carry a name that has no exercise in your lists (deleted or renamed exercise). The merge tool treats those as exercises too.
  function orphanSource(cat, name) {
    const es = (data[cat] || []).filter(e => sameExName(e.exercise, name));
    if (!es.length) return null;
    return { name, color: null, isometric: !!es[0].isometric, unilateral: !!es[0].unilateral, orphan: true };
  }
  function listExercisesForVariations() {
    const out = [];
    categories.forEach(cat => (exerciseLists[cat] || []).forEach(e => {
      out.push({
        category: cat, name: e.name, color: e.color || getCategoryColor(cat), isometric: !!e.isometric, unilateral: !!e.unilateral,
        custom: Array.isArray(e.variations) && e.variations.length ? e.variations.slice() : null,
        effective: exerciseVariations(e.name),
        entries: (data[cat] || []).filter(x => sameExName(x.exercise, e.name)).length
      });
    }));
    const known = new Set();
    categories.forEach(c => (exerciseLists[c] || []).forEach(e => known.add(String(e.name).trim().toLowerCase())));
    categories.forEach(cat => {
      const seen = new Set();
      (data[cat] || []).forEach(e => {
        const k = String(e.exercise || '').trim().toLowerCase();
        if (!k || known.has(k) || seen.has(k)) return;
        seen.add(k);
        const o = orphanSource(cat, e.exercise);
        out.push({ category: cat, name: e.exercise, color: getCategoryColor(cat), isometric: o.isometric, unilateral: o.unilateral, custom: null, effective: [], orphan: true, entries: (data[cat] || []).filter(x => sameExName(x.exercise, e.exercise)).length });
      });
    });
    return out;
  }
  function setCustomVariations(cat, name, list) {
    const ex = (exerciseLists[cat] || []).find(e => e.name === name);
    if (!ex) return false;
    const clean = Array.from(new Set((list || []).map(v => String(v).trim()).filter(Boolean)));
    if (clean.length) ex.variations = clean; else delete ex.variations;
    saveLists();
    updateMetricsSection(currentExerciseName());
    return true;
  }
  function snapshotForUndo() {
    const snap = { at: Date.now(), keys: {} };
    [DATA_KEY, LISTS_KEY, BLOCKS_KEY, SKILLS_KEY].forEach(k => { snap.keys[k] = localStorage.getItem(k); });
    try { localStorage.setItem(MERGE_UNDO_KEY, JSON.stringify(snap)); } catch (e) { return false; }
    return true;
  }
  function hasMergeUndo() { try { return !!JSON.parse(localStorage.getItem(MERGE_UNDO_KEY)); } catch (e) { return false; } }
  function undoLastMerge() {
    let snap = null;
    try { snap = JSON.parse(localStorage.getItem(MERGE_UNDO_KEY)); } catch (e) { return false; }
    if (!snap || !snap.keys) return false;
    Object.keys(snap.keys).forEach(k => { if (snap.keys[k] === null) localStorage.removeItem(k); else localStorage.setItem(k, snap.keys[k]); });
    localStorage.removeItem(MERGE_UNDO_KEY);
    try { sessionStorage.removeItem(SESSION_KEY); } catch (e) { /* ignore */ }
    window.removeEventListener('pagehide', saveSession); // don't re-save the pre-undo state on the way out
    location.reload();
    return true;
  }
  // tgt: { name, category (preferred / for a new one), isometric, unilateral (only used when it has to be created) }
  function planMerge(srcCat, srcName, tgt, variation) {
    const src = (exerciseLists[srcCat] || []).find(e => e.name === srcName) || orphanSource(srcCat, srcName);
    if (!src) return { ok: false, reason: 'That exercise no longer exists.' };
    const real = categories.slice();
    let tgtCat = null, tgtObj = null;
    for (const c of [tgt.category].concat(real)) {
      if (!c || !real.includes(c)) continue;
      const f = (exerciseLists[c] || []).find(e => e !== src && exKey(e.name) === exKey(tgt.name));
      if (f) { tgtCat = c; tgtObj = f; break; }
    }
    const creating = !tgtObj;
    if (creating && exKey(tgt.name) === exKey(srcName) && !variation) return { ok: false, reason: 'That is the same exercise.' };
    if (creating) tgtCat = real.includes(tgt.category) ? tgt.category : srcCat;
    const tgtIso = creating ? (tgt.isometric !== undefined ? !!tgt.isometric : !!src.isometric) : !!tgtObj.isometric;
    const tgtUni = creating ? (tgt.unilateral !== undefined ? !!tgt.unilateral : !!src.unilateral) : !!tgtObj.unilateral;
    const tgtName = creating ? tgt.name : tgtObj.name;
    if (!!src.isometric !== tgtIso && !(isDistanceExercise(srcName) && isDistanceExercise(tgtName))) {
      return { ok: false, reason: `${srcName} counts ${src.isometric ? 'seconds' : 'reps'} but ${tgtName} counts ${tgtIso ? 'seconds' : 'reps'}, so they can't share one exercise.` };
    }
    const entries = (data[srcCat] || []).filter(e => sameExName(e.exercise, srcName));
    const setCount = entries.reduce((n, e) => n + (e.sets || []).length, 0);
    return {
      ok: true, creating, srcCat, srcName, tgtCat, tgtName, tgtIso, tgtUni, variation: variation || null,
      entries: entries.length, sets: setCount,
      sides: (!!src.unilateral !== tgtUni && !(variation && isOneSidedVariation(tgtName, variation))) ? (src.unilateral ? 'weaker side' : 'both sides') : null
    };
  }
  function applyMerge(srcCat, srcName, tgt, variation) {
    const p = planMerge(srcCat, srcName, tgt, variation);
    if (!p.ok) return p;
    const src = (exerciseLists[srcCat] || []).find(e => e.name === srcName) || orphanSource(srcCat, srcName);
    let tgtObj = (exerciseLists[p.tgtCat] || []).find(e => e.name === p.tgtName);
    if (!tgtObj) {
      tgtObj = { name: p.tgtName, color: src.color || null, isometric: p.tgtIso, unilateral: p.tgtUni, createdAt: Date.now() };
      (exerciseLists[p.tgtCat] = exerciseLists[p.tgtCat] || []).push(tgtObj);
    }
    const moved = (data[srcCat] || []).filter(e => sameExName(e.exercise, srcName));
    data[srcCat] = (data[srcCat] || []).filter(e => !sameExName(e.exercise, srcName));
    if (!data[p.tgtCat]) data[p.tgtCat] = [];
    moved.forEach(e => {
      e.exercise = tgtObj.name; e.isometric = !!tgtObj.isometric; e.unilateral = !!tgtObj.unilateral;
      e.updatedAt = Date.now(); // so other devices pick up the merge
      if (variation && e.distance != null && !(e.sets && e.sets.length) && !e.variation) e.variation = variation; // runs have no sets, so the variation sits on the entry
      (e.sets || []).forEach(s => {
        if (!s || typeof s !== 'object') return;
        if (variation && !s.variation) s.variation = variation;
        if (p.sides === 'weaker side' && s.left !== undefined) { s.reps = Math.min(Number(s.left) || 0, Number(s.right) || 0); delete s.left; delete s.right; }
        else if (p.sides === 'both sides' && s.reps !== undefined) { s.left = s.reps; s.right = s.reps; delete s.reps; }
      });
      data[p.tgtCat].push(e);
    });
    // blocks, plan blocks and skill steps that pointed at the old exercise now point at the new one
    Object.keys(blockRefs).forEach(b => {
      const seen = new Set();
      blockRefs[b] = (blockRefs[b] || []).map(r => (r && r.name === srcName && r.refCategory === srcCat)
        ? Object.assign({}, r, { name: tgtObj.name, refCategory: p.tgtCat }, (variation && !r.variation) ? { variation } : {}) : r)
        .filter(r => { const k = r.refCategory + '|' + r.name; if (seen.has(k)) return false; seen.add(k); return true; });
    });
    skillLines.forEach(l => (l.steps || []).forEach(st => { if (st.exercise === srcName) st.exercise = tgtObj.name; }));
    exerciseLists[srcCat] = (exerciseLists[srcCat] || []).filter(e => e !== src);
    if (srcName.toLowerCase() !== tgtObj.name.toLowerCase()) markExerciseRemoved(srcName);
    delete exerciseDrafts[srcName];
    if (selectedExercise === srcName) { selectedExercise = ''; switchExerciseInputs('', ''); }
    if (variation && !exerciseVariations(tgtObj.name).includes(variation)) tgtObj.variations = exerciseVariations(tgtObj.name).concat(variation);
    recalcPRs(tgtObj.name);
    saveData(); saveLists(); saveBlocks(); saveSkills();
    renderBlockSelect(); updateExercisePicker(); renderModifiers(); render();
    return Object.assign({}, p, { moved: moved.length });
  }
  function deletePlanBlocks(names) {
    const gone = (names || []).filter(n => planBlocks.includes(n));
    if (!gone.length) return;
    blocks = blocks.filter(b => !gone.includes(b));
    planBlocks = planBlocks.filter(b => !gone.includes(b));
    gone.forEach(n => { delete blockRefs[n]; delete planMeta[n]; });
    savePlanMeta();
    hiddenBlocks = hiddenBlocks.filter(h => !gone.includes(h));
    if (gone.includes(activeBlock)) activeBlock = null;
    saveBlocks();
    renderBlockSelect();
    updateExercisePicker();
  }

  const newBlockInput = document.getElementById('newBlockInput');
  document.getElementById('addBlockBtn').onclick = () => {
    const name = newBlockInput.value.trim();
    if (!name) return;
    if (blocks.includes(name)) { alert('That block already exists.'); return; }
    blocks.push(name);
    blockRefs[name] = [];
    newBlockInput.value = '';
    saveBlocks();
    renderBlockSelect();
    renderBlockEditList();
  };
  newBlockInput.addEventListener('keydown', (e) => { if (e.key === 'Enter') document.getElementById('addBlockBtn').click(); });
  document.getElementById('blocksSortBtn').onclick = () => {
    blockListSort = (blockListSort === 'added') ? 'alphabetical' : 'added';
    renderBlockEditList();
  };

