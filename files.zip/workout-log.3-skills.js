  // ---- Skill progressions: criteria checking, "train next" suggestions, and the Skills page ----
  // Built-in skill progressions (Planche, Front lever, ...) live in workout-library.json; see workout-library.js.
  let collapsedSkillLines = new Set(); // in-memory only: which lines are folded up on the Skills page
  let skillStepEditing = null;         // { lineId, stepId|null } while the step editor is open

  function allExerciseNames() {
    const seen = new Set();
    categories.forEach(c => (exerciseLists[c] || []).forEach(e => seen.add(e.name)));
    return Array.from(seen);
  }
  // Pre-link example steps to an exercise of the same name if you already have one.
  function guessExerciseForStep(lineName, stepName) {
    const names = allExerciseNames();
    const cands = [stepName, stepName + ' ' + lineName, lineName + ' ' + stepName].map(x => x.toLowerCase());
    for (const c of cands) { const hit = names.find(n => n.toLowerCase() === c); if (hit) return hit; }
    return null;
  }
  function goalText(step) { return step.metric === 'hold' ? `${step.target}s × ${step.sets}` : `${step.target} reps × ${step.sets}`; }
  // Checks a step against the log: any single day with enough sets at/above the target meets it.
  function evaluateStep(step) {
    if (!step.exercise) return { linked: false, hasData: false, met: false, metDate: null, bestCount: 0, bestValue: 0 };
    const byDate = {};
    categories.forEach(cat => (data[cat] || []).forEach(e => {
      if (e.exercise !== step.exercise) return;
      const vals = (e.sets || []).filter(x => !step.variation || (step.variation === '__none__' ? !setVar(x) : setVar(x) === step.variation)).map(Shared.cleanReps);
      if (step.metric === 'hold' && !step.variation) (e.attempts || []).forEach(a => vals.push(Number(a) || 0));
      if (!vals.length) return;
      (byDate[e.date] = byDate[e.date] || []).push(...vals);
    }));
    const dates = Object.keys(byDate).sort();
    let bestCount = 0, bestValue = 0, metDate = null;
    dates.forEach(d => {
      const vals = byDate[d];
      const count = vals.filter(v => v >= step.target).length;
      if (count > bestCount) bestCount = count;
      vals.forEach(v => { if (v > bestValue) bestValue = v; });
      if (!metDate && count >= step.sets) metDate = d;
    });
    return { linked: true, hasData: dates.length > 0, met: !!metDate, metDate, bestCount: Math.min(bestCount, step.sets), bestValue };
  }
  function skillCurrentIdx(line) { return line.steps.findIndex(st => !st.doneDate); }
  function metStepIds() {
    const ids = new Set();
    skillLines.forEach(l => l.steps.forEach(st => { if (!st.doneDate && evaluateStep(st).met) ids.add(st.id); }));
    return ids;
  }
  function stepStatus(step, ev) {
    if (!step.exercise) return { text: 'Not linked to an exercise — tick it off yourself, or edit the step to link one.', met: false };
    if (ev.met) return { text: `✓ Criteria met (first on ${ev.metDate})`, met: true };
    if (!ev.hasData) return { text: 'Not logged yet', met: false };
    const u = step.metric === 'hold' ? 's' : '';
    return { text: `Best ${ev.bestValue}${u} · ${ev.bestCount}/${step.sets} sets at ${step.target}${u}+ in a day`, met: false };
  }
  function skillToday() { return Shared.todayISO(); }

  // Small hint shown while logging an exercise that is part of a skill line.
  function skillHintFor(name) {
    if (!name) return null;
    let found = null;
    skillLines.forEach(line => {
      const cur = skillCurrentIdx(line);
      line.steps.forEach((st, i) => {
        if (st.doneDate || st.exercise !== name) return;
        const isCurrent = i === cur;
        if (!found || (isCurrent && !found.isCurrent)) found = { line, step: st, isCurrent };
      });
    });
    if (!found) return null;
    const ev = evaluateStep(found.step);
    return `${found.step.name} goal: ${goalText(found.step)}` + (ev.met ? ' — met, mark it done in Skills' : '');
  }
  function updateSkillsBadge() {
    const btn = document.getElementById('skillsBtn');
    if (!btn) return;
    const n = metStepIds().size;
    btn.innerHTML = '<i class="fa-solid fa-medal" aria-hidden="true"></i>' + (n ? `<span class="ready-dot">${n}</span>` : '');
    const label = n ? `Skill progressions — ${n} ready to move up` : 'Skill progressions';
    btn.title = label;
    btn.setAttribute('aria-label', label);
  }
  // Called right after an entry is logged: tells you if that session just met a step's criteria.
  function announceNewlyMetSkills(before, prToastShown) {
    const names = [];
    skillLines.forEach(l => l.steps.forEach(st => { if (!st.doneDate && !before.has(st.id) && evaluateStep(st).met) names.push(st.name); }));
    updateSkillsBadge();
    if (!names.length) return;
    const msg = `🎯 Criteria met: ${names.join(', ')} — mark it done in Skills`;
    if (prToastShown) setTimeout(() => showToast(msg), lastToastMs + 200); else showToast(msg);
  }

  function setStepDone(line, step, done) {
    step.doneDate = done ? skillToday() : null;
    saveSkills();
    renderSkillsPage();
    if (done) {
      const next = line.steps.find(st => !st.doneDate);
      showToast(next ? `✓ ${step.name} done — next up: ${next.name}` : `🏆 ${line.name} complete!`);
    }
  }
  function moveSkillStep(line, i, dir) {
    const j = i + dir;
    if (j < 0 || j >= line.steps.length) return;
    const tmp = line.steps[i]; line.steps[i] = line.steps[j]; line.steps[j] = tmp;
    saveSkills();
    renderSkillsPage();
  }
  // Jump to the home page with this exercise selected, ready to log.
  function goLogExercise(name, variation) {
    if (!categories.some(c => (exerciseLists[c] || []).some(e => e.name === name))) { showToast("That exercise isn't in your library any more"); return; }
    active = exerciseCategoryFor(name);
    activeBlock = null;
    const prev = selectedExercise;
    selectedExercise = name;
    if (selectedExercise !== prev) switchExerciseInputs(prev, selectedExercise);
    renderTabs();
    renderBlockSelect();
    updateExercisePicker();
    if (variation) { for (let i = 1; i <= numSets; i++) { const sel = document.getElementById('var' + i); if (sel && Array.from(sel.options).some(o => o.value === variation)) sel.value = variation; } }
    renderModifiers();
    navigateTo('home');
  }

  function skillMiniBtn(iconHtml, title, onClick, extraClass, disabled) {
    const b = document.createElement('button');
    b.type = 'button';
    b.className = 'skill-mini-btn' + (extraClass ? ' ' + extraClass : '');
    b.innerHTML = iconHtml;
    b.title = title;
    b.setAttribute('aria-label', title);
    b.disabled = !!disabled;
    b.onclick = onClick;
    return b;
  }
  function skillTextBtn(label, onClick, primary) {
    const b = document.createElement('button');
    b.type = 'button';
    b.className = 'text-btn' + (primary ? ' text-btn-primary' : '');
    b.textContent = label;
    b.onclick = onClick;
    return b;
  }

  function renderSkillsNext() {
    const el = document.getElementById('skillsNextList');
    el.innerHTML = '';
    if (!skillLines.length) {
      el.innerHTML = '<div class="empty" style="padding:4px 0;">No skill lines yet — add one below and this becomes your "what to train next" list.</div>';
      return;
    }
    const rows = [];
    skillLines.forEach(line => { const idx = skillCurrentIdx(line); if (idx !== -1) rows.push({ line, step: line.steps[idx], idx }); });
    if (!rows.length) {
      el.innerHTML = '<div class="empty" style="padding:4px 0;">Every line is complete 🏆 — add a harder step or a new line to keep progressing.</div>';
      return;
    }
    rows.forEach(({ line, step, idx }) => {
      const ev = evaluateStep(step);
      const st = stepStatus(step, ev);
      const row = document.createElement('div');
      row.className = 'skill-next-row' + (ev.met ? ' ready' : '');
      const main = document.createElement('div');
      main.className = 'skill-next-main';
      const lineEl = document.createElement('div');
      lineEl.className = 'skill-next-line';
      lineEl.textContent = `${line.name} · step ${idx + 1} of ${line.steps.length}`;
      const titleEl = document.createElement('div');
      titleEl.className = 'skill-step-name';
      titleEl.textContent = step.name;
      const goalEl = document.createElement('div');
      goalEl.className = 'skill-step-goal';
      goalEl.textContent = `Goal: ${goalText(step)}` + (step.exercise ? ` · ${step.exercise}${step.variation ? ' · ' + (step.variation === '__none__' ? 'Standard' : step.variation) : ''}` : '');
      const statusEl = document.createElement('div');
      statusEl.className = 'skill-step-status' + (st.met ? ' met' : '');
      statusEl.textContent = st.text;
      main.appendChild(lineEl); main.appendChild(titleEl); main.appendChild(goalEl); main.appendChild(statusEl);
      const actions = document.createElement('div');
      actions.className = 'skill-step-actions';
      if (ev.met) actions.appendChild(skillTextBtn('Mark done & move up', () => setStepDone(line, step, true), true));
      if (step.exercise) actions.appendChild(skillTextBtn('Log it', () => goLogExercise(step.exercise, step.variation), !ev.met));
      if (!ev.met) actions.appendChild(skillTextBtn('Mark done', () => setStepDone(line, step, true)));
      main.appendChild(actions);
      row.appendChild(main);
      el.appendChild(row);
    });
  }

  function buildSkillStepRow(line, step, i, curIdx) {
    const ev = step.doneDate ? null : evaluateStep(step);
    const row = document.createElement('div');
    row.className = 'skill-step' + (step.doneDate ? ' done' : (ev.met ? ' ready' : (i === curIdx ? ' current' : '')));
    const dot = document.createElement('div');
    dot.className = 'skill-dot';
    dot.textContent = step.doneDate ? '✓' : (ev.met ? '!' : String(i + 1));
    const body = document.createElement('div');
    body.className = 'skill-step-body';
    const nameEl = document.createElement('div');
    nameEl.className = 'skill-step-name';
    nameEl.textContent = step.name;
    const goalEl = document.createElement('div');
    goalEl.className = 'skill-step-goal';
    goalEl.textContent = `Goal: ${goalText(step)}` + (step.exercise ? ` · ${step.exercise}${step.variation ? ' · ' + (step.variation === '__none__' ? 'Standard' : step.variation) : ''}` : '');
    const statusEl = document.createElement('div');
    if (step.doneDate) {
      statusEl.className = 'skill-step-status';
      statusEl.textContent = `Done ${step.doneDate}`;
    } else {
      const st = stepStatus(step, ev);
      statusEl.className = 'skill-step-status' + (st.met ? ' met' : '');
      statusEl.textContent = st.text;
    }
    const actions = document.createElement('div');
    actions.className = 'skill-step-actions';
    if (step.doneDate) actions.appendChild(skillTextBtn('Undo', () => setStepDone(line, step, false)));
    else actions.appendChild(skillTextBtn(ev.met ? 'Mark done & move up' : 'Mark done', () => setStepDone(line, step, true), ev.met));
    if (step.exercise && !step.doneDate) actions.appendChild(skillTextBtn('Log it', () => goLogExercise(step.exercise, step.variation)));
    actions.appendChild(skillMiniBtn('<i class="fa-solid fa-pencil" aria-hidden="true"></i>', 'Edit step', () => openSkillStepModal(line.id, step.id)));
    actions.appendChild(skillMiniBtn('<i class="fa-solid fa-arrow-up" aria-hidden="true"></i>', 'Move up', () => moveSkillStep(line, i, -1), '', i === 0));
    actions.appendChild(skillMiniBtn('<i class="fa-solid fa-arrow-down" aria-hidden="true"></i>', 'Move down', () => moveSkillStep(line, i, 1), '', i === line.steps.length - 1));
    actions.appendChild(skillMiniBtn('<i class="fa-regular fa-trash-can" aria-hidden="true"></i>', 'Delete step', () => {
      if (!confirm(`Delete the step "${step.name}"?`)) return;
      line.steps = line.steps.filter(x => x.id !== step.id);
      saveSkills();
      renderSkillsPage();
    }, 'danger'));
    body.appendChild(nameEl); body.appendChild(goalEl); body.appendChild(statusEl); body.appendChild(actions);
    row.appendChild(dot);
    row.appendChild(body);
    return row;
  }

  function renderSkillLines() {
    const listEl = document.getElementById('skillLinesList');
    listEl.innerHTML = '';
    skillLines.forEach(line => {
      const total = line.steps.length;
      const doneCount = line.steps.filter(st => st.doneDate).length;
      const curIdx = skillCurrentIdx(line);
      const collapsed = collapsedSkillLines.has(line.id);
      const card = document.createElement('div');
      card.className = 'skill-line';
      const head = document.createElement('div');
      head.className = 'skill-line-header';
      const titleBtn = document.createElement('button');
      titleBtn.type = 'button';
      titleBtn.className = 'skill-line-title';
      titleBtn.innerHTML = `<i class="fa-solid ${collapsed ? 'fa-chevron-right' : 'fa-chevron-down'}" aria-hidden="true"></i>`;
      const nameSpan = document.createElement('span');
      nameSpan.textContent = line.name;
      const prog = document.createElement('span');
      prog.className = 'skill-progress';
      prog.textContent = `${doneCount}/${total}`;
      titleBtn.appendChild(nameSpan);
      titleBtn.appendChild(prog);
      titleBtn.onclick = () => {
        if (collapsedSkillLines.has(line.id)) collapsedSkillLines.delete(line.id); else collapsedSkillLines.add(line.id);
        renderSkillLines();
      };
      const lineActions = document.createElement('div');
      lineActions.className = 'skill-line-actions';
      lineActions.appendChild(skillMiniBtn('<i class="fa-solid fa-plus" aria-hidden="true"></i>', 'Add a step', () => openSkillStepModal(line.id, null)));
      lineActions.appendChild(skillMiniBtn('<i class="fa-solid fa-pencil" aria-hidden="true"></i>', 'Rename line', () => {
        const nn = prompt('Rename skill line', line.name);
        if (!nn || !nn.trim() || nn.trim() === line.name) return;
        if (skillLines.some(l => l.id !== line.id && l.name.toLowerCase() === nn.trim().toLowerCase())) { alert('A skill line with that name already exists.'); return; }
        line.name = nn.trim();
        saveSkills();
        renderSkillsPage();
      }));
      lineActions.appendChild(skillMiniBtn('<i class="fa-regular fa-trash-can" aria-hidden="true"></i>', 'Delete line', () => {
        if (!confirm(`Delete "${line.name}"${total ? ` and its ${total} step${total === 1 ? '' : 's'}` : ''}?`)) return;
        skillLines = skillLines.filter(l => l.id !== line.id);
        collapsedSkillLines.delete(line.id);
        saveSkills();
        renderSkillsPage();
      }, 'danger'));
      head.appendChild(titleBtn);
      head.appendChild(lineActions);
      card.appendChild(head);
      if (total) {
        const bar = document.createElement('div');
        bar.className = 'skill-progress-bar';
        const fill = document.createElement('div');
        fill.style.width = Math.round(doneCount / total * 100) + '%';
        bar.appendChild(fill);
        card.appendChild(bar);
      }
      if (!collapsed) {
        if (!total) {
          const empty = document.createElement('div');
          empty.className = 'empty';
          empty.style.padding = '4px 0';
          empty.textContent = 'No steps yet — add the first one with +.';
          card.appendChild(empty);
        }
        line.steps.forEach((step, i) => card.appendChild(buildSkillStepRow(line, step, i, curIdx)));
      }
      listEl.appendChild(card);
    });
  }
  function renderSkillsPage() {
    renderSkillsNext();
    renderSkillLines();
    updateSkillsBadge();
    if (window.WorkoutApp && window.WorkoutApp.onSkillsRender) window.WorkoutApp.onSkillsRender();
  }

  // ---- step editor ----
  function fillSkillExerciseSelect(sel, current) {
    sel.innerHTML = '';
    const none = document.createElement('option');
    none.value = '';
    none.textContent = 'Not linked (I\'ll tick it off myself)';
    sel.appendChild(none);
    const seen = new Set();
    categories.forEach(cat => {
      const list = (exerciseLists[cat] || []).filter(e => !seen.has(e.name));
      if (!list.length) return;
      const og = document.createElement('optgroup');
      og.label = cat;
      list.forEach(e => {
        seen.add(e.name);
        const o = document.createElement('option');
        o.value = e.name;
        o.textContent = e.name;
        og.appendChild(o);
      });
      sel.appendChild(og);
    });
    if (current && !seen.has(current)) {
      const o = document.createElement('option');
      o.value = current;
      o.textContent = current + ' (not in library)';
      sel.insertBefore(o, sel.children[1] || null);
    }
    sel.value = current || '';
  }
  function fillSkillVariationSelect(exName, current) {
    const sel = document.getElementById('skillStepVariation');
    const list = exName ? exerciseVariations(exName) : [];
    const all = current && current !== '__none__' && !list.includes(current) ? list.concat(current) : list;
    sel.innerHTML = '';
    const any = document.createElement('option');
    any.value = ''; any.textContent = all.length ? 'Any variation' : 'No variations for this exercise';
    sel.appendChild(any);
    if (list.length) { const std = document.createElement('option'); std.value = '__none__'; std.textContent = 'Standard (no variation)'; sel.appendChild(std); }
    all.forEach(v => { const o = document.createElement('option'); o.value = v; o.textContent = v; sel.appendChild(o); });
    sel.value = current || '';
    sel.disabled = !all.length;
  }
  document.getElementById('skillStepExercise').onchange = () => fillSkillVariationSelect(document.getElementById('skillStepExercise').value || null, null);
  function updateSkillStepMetricUI() {
    document.getElementById('skillStepTargetLabel').textContent = document.getElementById('skillStepMetric').value === 'hold' ? 'Seconds per set' : 'Reps per set';
  }
  function openSkillStepModal(lineId, stepId) {
    const line = skillLines.find(l => l.id === lineId);
    if (!line) return;
    const step = stepId ? line.steps.find(st => st.id === stepId) : null;
    skillStepEditing = { lineId, stepId: step ? step.id : null };
    document.getElementById('skillStepModalTitle').textContent = (step ? 'Edit step' : 'Add step') + ' — ' + line.name;
    document.getElementById('skillStepName').value = step ? step.name : '';
    fillSkillExerciseSelect(document.getElementById('skillStepExercise'), step ? step.exercise : null);
    fillSkillVariationSelect(step ? step.exercise : null, step ? step.variation : null);
    document.getElementById('skillStepMetric').value = step ? step.metric : 'hold';
    document.getElementById('skillStepTarget').value = step ? step.target : 20;
    document.getElementById('skillStepSets').value = step ? step.sets : 3;
    updateSkillStepMetricUI();
    document.getElementById('skillStepModalOverlay').classList.remove('hidden');
    document.getElementById('skillStepName').focus();
  }
  function closeSkillStepModal() {
    document.getElementById('skillStepModalOverlay').classList.add('hidden');
    skillStepEditing = null;
  }
  document.getElementById('skillStepModalOverlay').addEventListener('click', (e) => { if (e.target.id === 'skillStepModalOverlay') closeSkillStepModal(); });
  document.getElementById('skillStepCancelBtn').onclick = closeSkillStepModal;
  document.getElementById('skillStepMetric').onchange = () => {
    updateSkillStepMetricUI();
    // nudge the default target when the criterion type flips on a fresh step
    const t = document.getElementById('skillStepTarget');
    if (skillStepEditing && !skillStepEditing.stepId) t.value = document.getElementById('skillStepMetric').value === 'hold' ? 20 : 5;
  };
  document.getElementById('skillStepSaveBtn').onclick = () => {
    if (!skillStepEditing) return;
    const name = document.getElementById('skillStepName').value.trim();
    const target = Number(document.getElementById('skillStepTarget').value);
    const sets = Math.round(Number(document.getElementById('skillStepSets').value));
    if (!name) { alert('Give the step a name.'); return; }
    if (!(target > 0)) { alert('Enter a target greater than 0.'); return; }
    if (!(sets >= 1 && sets <= 20)) { alert('Sets must be between 1 and 20.'); return; }
    const line = skillLines.find(l => l.id === skillStepEditing.lineId);
    if (!line) { closeSkillStepModal(); return; }
    const fields = {
      name,
      exercise: document.getElementById('skillStepExercise').value || null,
      variation: document.getElementById('skillStepVariation').value || null,
      metric: document.getElementById('skillStepMetric').value === 'reps' ? 'reps' : 'hold',
      target, sets
    };
    if (skillStepEditing.stepId) {
      const step = line.steps.find(st => st.id === skillStepEditing.stepId);
      if (step) Object.assign(step, fields);
    } else {
      line.steps.push(Object.assign({ id: newSkillId(), doneDate: null }, fields));
    }
    saveSkills();
    closeSkillStepModal();
    renderSkillsPage();
  };
  ['skillStepName', 'skillStepTarget', 'skillStepSets'].forEach(id => {
    document.getElementById(id).addEventListener('keydown', (e) => { if (e.key === 'Enter') document.getElementById('skillStepSaveBtn').click(); });
  });

  // ---- add lines ----
  document.getElementById('addSkillLineBtn').onclick = () => {
    const input = document.getElementById('newSkillLineInput');
    const name = input.value.trim();
    if (!name) return;
    if (skillLines.some(l => l.name.toLowerCase() === name.toLowerCase())) { alert('A skill line with that name already exists.'); return; }
    skillLines.push({ id: newSkillId(), name, steps: [] });
    saveSkills();
    input.value = '';
    renderSkillsPage();
  };
  document.getElementById('newSkillLineInput').addEventListener('keydown', (e) => { if (e.key === 'Enter') document.getElementById('addSkillLineBtn').click(); });
  // A library step can name its exercise (and variation): make sure you have that exercise, and use your copy of it.
  function templateExercise(st) {
    if (!st.exercise) return null;
    const lib = window.WorkoutLibrary && window.WorkoutLibrary.get();
    const c = lib && (lib.exercises || []).find(x => exKey(x.name) === exKey(st.exercise));
    const res = ensureExercises([c ? { name: c.name, category: c.category, isometric: c.isometric, unilateral: c.unilateral } : { name: st.exercise, category: 'Skill', isometric: st.metric === 'hold' }]);
    return res.refs.length ? res.refs[0].name : null;
  }
  // Adds skill lines from library templates: { name, steps: [{ name, metric, target, sets }] }
  function addSkillTemplates(templates) {
    let added = 0;
    (templates || []).forEach(ex => {
      if (!ex || !ex.name || skillLines.some(l => l.name.toLowerCase() === String(ex.name).toLowerCase())) return;
      const line = cleanSkillLine({
        name: ex.name,
        steps: (ex.steps || []).map(st => ({ name: st.name, metric: st.metric, target: st.target, sets: st.sets, exercise: templateExercise(st) || guessExerciseForStep(ex.name, st.name), variation: st.variation || null }))
      });
      if (line) { skillLines.push(line); added++; }
    });
    if (!added) return;
    saveSkills();
    renderSkillsPage();
    showToast('Progression added — edit a step to link it to one of your exercises');
  }

