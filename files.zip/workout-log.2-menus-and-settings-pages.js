  // ---- Header menus ----
  const menuBtn = document.getElementById('menuBtn');
  const menuPanel = document.getElementById('menuPanel');
  const rearrangeToggleBtn = document.getElementById('rearrangeToggleBtn');
  const settingsListWrap = document.getElementById('settingsListWrap');
  menuBtn.onclick = (e) => {
    e.stopPropagation();
    menuPanel.classList.toggle('hidden');
  };
  rearrangeToggleBtn.onclick = (e) => {
    e.stopPropagation();
    const opening = settingsListWrap.classList.contains('hidden');
    settingsListWrap.classList.toggle('hidden', !opening);
    rearrangeToggleBtn.classList.toggle('open', opening);
    if (opening) renderSettingsList();
  };

  // ---- Reset (settings menu) ----
  const resetToggleBtn = document.getElementById('resetToggleBtn');
  const resetWrap = document.getElementById('resetWrap');
  resetToggleBtn.onclick = (e) => {
    e.stopPropagation();
    const opening = resetWrap.classList.contains('hidden');
    resetWrap.classList.toggle('hidden', !opening);
    resetToggleBtn.classList.toggle('open', opening);
  };
  const RESET_KEYS = {
    data: [DATA_KEY, "workout-log-deleted-v1"],
    lists: [LISTS_KEY, ...LEGACY_LISTS_KEYS, EQUIPMENT_KEY, REMOVEDEX_KEY, 'workout-log-premerge-v1'],
    blocks: [BLOCKS_KEY],
    layout: [LAYOUT_KEY],
    appearance: [NUMSETS_KEY, THEME_KEY, MODE_KEY],
    profile: [BODYWEIGHT_KEY, 'workout-log-measurements-v1', 'workout-log-goals-v1'],
    plans: [SKILLS_KEY, 'workout-log-myprogram-v1', PLANMETA_KEY, PLANPROG_KEY, 'workout-log-plan-options-v1']
  };
  const RESET_LABELS = {
    data: 'logged entries (your workout history)',
    lists: 'categories, exercises & equipment',
    blocks: 'blocks',
    layout: 'section layout',
    appearance: 'appearance settings (theme)',
    profile: 'bodyweight, measurements & goals',
    plans: 'skill lines, My program & plan progress'
  };
  function clearResetGroup(key) {
    RESET_KEYS[key].forEach(k => localStorage.removeItem(k));
    if (key === 'lists') {
      // Just removing the key falls back to the app's built-in starter
      // categories/exercises on next load — that's not actually "empty".
      // Write a genuinely bare list instead: one category, zero exercises.
      lsSet(LISTS_KEY, JSON.stringify({ categories: ["General"], exercises: { General: [] }, colors: {} }));
    }
  }
  document.getElementById('resetSelectedBtn').onclick = () => {
    const checks = {
      data: document.getElementById('resetOptData').checked,
      lists: document.getElementById('resetOptLists').checked,
      blocks: document.getElementById('resetOptBlocks').checked,
      layout: document.getElementById('resetOptLayout').checked,
      profile: document.getElementById('resetOptProfile').checked,
      plans: document.getElementById('resetOptPlans').checked,
      appearance: document.getElementById('resetOptAppearance').checked
    };
    const chosen = Object.keys(checks).filter(k => checks[k]);
    if (!chosen.length) { alert('Choose at least one thing to reset first.'); return; }
    const list = chosen.map(k => RESET_LABELS[k]).join(', ');
    if (!confirm(`This will permanently erase: ${list}.\n\nThis can't be undone. Continue?`)) return;
    chosen.forEach(clearResetGroup);
    location.reload();
  };
  document.getElementById('resetAllBtn').onclick = () => {
    if (!confirm("This permanently erases EVERYTHING — all logged workouts, categories, exercises, blocks, equipment, skills, bodyweight, measurements, goals, plans and settings — and can't be undone. Photos, your profile picture and the Drive and backup settings are kept.\n\nReset the app completely?")) return;
    if (!confirm("Really sure? There's no way to get this data back once it's gone.")) return;
    Object.keys(RESET_KEYS).forEach(clearResetGroup);
    location.reload();
  };
  document.addEventListener('click', (e) => {
    if (!menuPanel.contains(e.target) && e.target !== menuBtn && !menuBtn.contains(e.target)) menuPanel.classList.add('hidden');
  });

  // ---- Layout (move / show / hide sections) ----
  // Calendar and entries live on the history page; everything else stays on home.
  const PAGE_OF_MODULE = { calendar: 'history', entries: 'history' };
  // Cached once, before any module is ever detached — getElementById can't find a
  // detached node again, so applyLayout must work from these stable references,
  // not re-query the DOM each time (that was why toggling a section back on
  // silently failed until a page reload rebuilt the DOM).
  const MODULE_ELEMENTS = {};
  DEFAULT_LAYOUT.forEach(d => {
    const el = document.getElementById('module-' + d.id);
    if (el) MODULE_ELEMENTS[d.id] = el;
  });
  function applyLayout() {
    layout.forEach(item => {
      const el = MODULE_ELEMENTS[item.id];
      if (!el) return;
      const pageEl = document.getElementById('page-' + (PAGE_OF_MODULE[item.id] || 'home'));
      if (item.visible) pageEl.appendChild(el);
      else if (el.parentNode) el.parentNode.removeChild(el);
    });
  }

  // ---- Page navigation (home <-> calendar/history) ----
  const pageHomeEl = document.getElementById('page-home');
  const pageHistoryEl = document.getElementById('page-history');
  const pageConfigEl = document.getElementById('page-config');
  const pageNavBtn = document.getElementById('pageNavBtn');
  const configBtn = document.getElementById('configBtn');
  const pageSkillsEl = document.getElementById('page-skills');
  const skillsBtn = document.getElementById('skillsBtn');
  let currentPage = 'home';
  function navigateTo(page) {
    currentPage = page;
    pageHomeEl.classList.toggle('hidden', page !== 'home');
    pageHistoryEl.classList.toggle('hidden', page !== 'history');
    pageConfigEl.classList.toggle('hidden', page !== 'config');
    pageSkillsEl.classList.toggle('hidden', page !== 'skills');
    pageNavBtn.classList.toggle('on', page === 'history');
    configBtn.classList.toggle('on', page === 'config');
    skillsBtn.classList.toggle('on', page === 'skills');
    if (page === 'home') {
      pageNavBtn.innerHTML = '<i class="fa-solid fa-calendar-days" aria-hidden="true"></i>';
      pageNavBtn.title = 'Calendar & history';
      pageNavBtn.setAttribute('aria-label', 'View calendar & history');
    } else {
      pageNavBtn.innerHTML = '<i class="fa-solid fa-house" aria-hidden="true"></i>';
      pageNavBtn.title = 'Home';
      pageNavBtn.setAttribute('aria-label', 'Back to home');
    }
    if (page === 'config') { renderCatEditList(); renderBlockEditList(); renderEquipmentEditList(); renderBodyweightList(); renderAllExercisesList(); }
    else { assigningBlock = null; assigningCategory = null; }
    if (page === 'skills') renderSkillsPage();
  }
  pageNavBtn.onclick = () => navigateTo(currentPage === 'home' ? 'history' : 'home');
  configBtn.onclick = () => navigateTo(currentPage === 'config' ? 'home' : 'config');
  skillsBtn.onclick = () => navigateTo(currentPage === 'skills' ? 'home' : 'skills');
  function saveLayout() { lsSet(LAYOUT_KEY, JSON.stringify(layout)); }
  function loadLayout() {
    try {
      const raw = localStorage.getItem(LAYOUT_KEY);
      if (raw) {
        const parsed = JSON.parse(raw);
        const ids = parsed.map(p => p.id);
        DEFAULT_LAYOUT.forEach(d => { if (!ids.includes(d.id)) parsed.push(d); });
        layout = parsed.filter(p => MODULE_LABELS[p.id]);
      }
    } catch (e) { /* fall back to default */ }
    // Category, Calendar, and Entries list are fixed in place — not user-hideable.
    layout.forEach(item => { if (LOCKED_MODULES.includes(item.id)) item.visible = true; });
  }
  const LOCKED_MODULES = ['calendar', 'entries'];
  function renderSettingsList() {
    const listEl = document.getElementById('settingsList');
    listEl.innerHTML = '';
    const entries = layout.map((item, idx) => ({ item, idx })).filter(({ item }) => !LOCKED_MODULES.includes(item.id));
    entries.forEach(({ item, idx }, i) => {
      const row = document.createElement('div');
      row.className = 'settings-row' + (item.visible ? '' : ' hidden-module');
      const name = document.createElement('span');
      name.className = 'name';
      name.textContent = MODULE_LABELS[item.id];
      const actions = document.createElement('div');
      actions.className = 'actions';

      const upBtn = document.createElement('button');
      upBtn.innerHTML = '<i class="fa-solid fa-angle-up" aria-hidden="true"></i>';
      upBtn.disabled = i === 0;
      upBtn.onclick = () => { const prevIdx = entries[i - 1].idx; [layout[prevIdx], layout[idx]] = [layout[idx], layout[prevIdx]]; commitLayout(); };

      const downBtn = document.createElement('button');
      downBtn.innerHTML = '<i class="fa-solid fa-angle-down" aria-hidden="true"></i>';
      downBtn.disabled = i === entries.length - 1;
      downBtn.onclick = () => { const nextIdx = entries[i + 1].idx; [layout[nextIdx], layout[idx]] = [layout[idx], layout[nextIdx]]; commitLayout(); };

      const eyeBtn = document.createElement('button');
      eyeBtn.className = item.visible ? 'eye-on' : '';
      eyeBtn.innerHTML = `<i class="fa-solid fa-${item.visible ? 'eye' : 'eye-slash'}" aria-hidden="true"></i>`;
      eyeBtn.onclick = () => { item.visible = !item.visible; commitLayout(); };

      actions.appendChild(upBtn);
      actions.appendChild(downBtn);
      actions.appendChild(eyeBtn);
      row.appendChild(name);
      row.appendChild(actions);
      listEl.appendChild(row);
    });
  }
  function commitLayout() {
    saveLayout();
    applyLayout();
    renderSettingsList();
    renderCalendar();
  }

  // ---- Category tabs + edit (add / rename / delete) ----
  function renderTabs() {
    // category pill next to the block pill; it shows "Category" while a block is selected
    const sel = document.getElementById('categorySelect');
    if (!sel) return;
    sel.innerHTML = '';
    const ph = document.createElement('option');
    ph.value = ''; ph.textContent = 'Category'; ph.disabled = true;
    sel.appendChild(ph);
    categories.forEach(cat => { const o = document.createElement('option'); o.value = cat; o.textContent = cat; sel.appendChild(o); });
    sel.value = activeBlock ? '' : active;
    sel.onchange = () => {
      if (!sel.value) return;
      active = sel.value; activeBlock = null;
      renderBlockSelect(); updateExercisePicker(); render();
    };
  }

  // ---- Add/Edit exercise modal — shared by Blocks, Categories, and the Exercises list ----
  let exModalEditing = null; // { name, category } of the exercise being edited, or null when adding
  let exModalOnSaved = null; // callback(result) where result = { name, category } of the saved exercise, or null on delete

  function openExerciseModal(opts) {
    opts = opts || {};
    const exObj = opts.exObj || null;
    const category = opts.category || opts.defaultCategory || categories[0];
    exModalEditing = exObj ? { name: exObj.name, category: opts.category } : null;
    exModalOnSaved = opts.onSaved || null;
    document.getElementById('exModalTitle').textContent = exObj ? 'Edit exercise' : 'Add exercise';
    document.getElementById('exModalName').value = exObj ? exObj.name : '';
    const catSel = document.getElementById('exModalCategory');
    catSel.innerHTML = '';
    categories.forEach(c => {
      const opt = document.createElement('option');
      opt.value = c; opt.textContent = c;
      catSel.appendChild(opt);
    });
    catSel.value = category;
    document.getElementById('exModalColor').value = (exObj && exObj.color) || EX_COLOR_PALETTE[0];
    document.getElementById('exModalPattern').value = (exObj && exObj.pattern) || '';
    document.getElementById('exModalStraight').value = (exObj && exObj.straightArm !== undefined) ? (exObj.straightArm ? 'yes' : 'no') : '';
    const isoBtn = document.getElementById('exModalIsoBtn');
    const uniBtn = document.getElementById('exModalUniBtn');
    const levBtn = document.getElementById('exModalLevBtn');
    const iso = !!(exObj && exObj.isometric);
    const uni = !!(exObj && exObj.unilateral);
    const lev = !!(exObj && exObj.hasLeverage);
    isoBtn.classList.toggle('on', iso);
    isoBtn.textContent = iso ? 'ISO' : 'REPS';
    uniBtn.classList.toggle('on', uni);
    uniBtn.textContent = uni ? 'UNI' : 'BI';
    levBtn.classList.toggle('on', lev);
    levBtn.textContent = lev ? 'LEV ON' : 'LEV OFF';
    document.getElementById('exModalDeleteBtn').classList.toggle('hidden', !exObj);
    document.getElementById('exModalOverlay').classList.remove('hidden');
    document.getElementById('exModalName').focus();
  }
  function closeExerciseModal() {
    document.getElementById('exModalOverlay').classList.add('hidden');
    exModalEditing = null;
    exModalOnSaved = null;
  }
  document.getElementById('exModalOverlay').addEventListener('click', (e) => {
    if (e.target.id === 'exModalOverlay') closeExerciseModal();
  });
  document.getElementById('exModalIsoBtn').onclick = () => {
    const b = document.getElementById('exModalIsoBtn');
    const on = !b.classList.contains('on');
    b.classList.toggle('on', on);
    b.textContent = on ? 'ISO' : 'REPS';
  };
  document.getElementById('exModalUniBtn').onclick = () => {
    const b = document.getElementById('exModalUniBtn');
    const on = !b.classList.contains('on');
    b.classList.toggle('on', on);
    b.textContent = on ? 'UNI' : 'BI';
  };
  document.getElementById('exModalLevBtn').onclick = () => {
    const b = document.getElementById('exModalLevBtn');
    const on = !b.classList.contains('on');
    b.classList.toggle('on', on);
    b.textContent = on ? 'LEV ON' : 'LEV OFF';
  };
  document.getElementById('exModalCancelBtn').onclick = closeExerciseModal;
  document.getElementById('exModalDeleteBtn').onclick = () => {
    if (!exModalEditing) return;
    if (!confirm(`Delete "${exModalEditing.name}"?`)) return;
    exerciseLists[exModalEditing.category] = (exerciseLists[exModalEditing.category] || []).filter(e => e.name !== exModalEditing.name);
    markExerciseRemoved(exModalEditing.name);
    if (selectedExercise === exModalEditing.name) selectedExercise = "";
    saveLists();
    updateExercisePicker();
    const cb = exModalOnSaved;
    closeExerciseModal();
    if (cb) cb(null);
  };
  document.getElementById('exModalSaveBtn').onclick = () => {
    const name = document.getElementById('exModalName').value.trim();
    if (!name) return;
    const newCat = document.getElementById('exModalCategory').value;
    const color = document.getElementById('exModalColor').value;
    const isometric = document.getElementById('exModalIsoBtn').classList.contains('on');
    const unilateral = document.getElementById('exModalUniBtn').classList.contains('on');
    const hasLeverage = document.getElementById('exModalLevBtn').classList.contains('on');
    const pattern = document.getElementById('exModalPattern').value;
    const sa = document.getElementById('exModalStraight').value;

    if (exModalEditing) {
      const oldCat = exModalEditing.category;
      const oldName = exModalEditing.name;
      const idx = (exerciseLists[oldCat] || []).findIndex(e => e.name === oldName);
      if (idx === -1) { closeExerciseModal(); return; }
      const nameChanged = oldCat !== newCat || oldName.toLowerCase() !== name.toLowerCase();
      if (nameChanged && (exerciseLists[newCat] || []).some(e => e.name.toLowerCase() === name.toLowerCase())) {
        alert('An exercise with that name already exists in that category.');
        return;
      }
      const exObj = exerciseLists[oldCat][idx];
      exObj.name = name; exObj.color = color; exObj.isometric = isometric; exObj.unilateral = unilateral; exObj.hasLeverage = hasLeverage;
      if (pattern) exObj.pattern = pattern; else delete exObj.pattern;
      if (sa) exObj.straightArm = sa === 'yes'; else delete exObj.straightArm;
      fillMissingPatterns();
      if (oldCat !== newCat) {
        exerciseLists[oldCat].splice(idx, 1);
        if (!exerciseLists[newCat]) exerciseLists[newCat] = [];
        exerciseLists[newCat].push(exObj);
      }
      // keep any block references pointing at this exercise in sync
      blocks.forEach(b => {
        (blockRefs[b] || []).forEach(r => {
          if (r.name === oldName && r.refCategory === oldCat) { r.name = name; r.refCategory = newCat; }
        });
      });
      if (selectedExercise === oldName) selectedExercise = name;
      // keep skill steps that track this exercise pointing at it
      let skillsTouched = false;
      skillLines.forEach(l => l.steps.forEach(st => { if (st.exercise === oldName) { st.exercise = name; skillsTouched = true; } }));
      if (skillsTouched) saveSkills();
      saveLists();
      saveBlocks();
      updateExercisePicker();
      const cb = exModalOnSaved;
      closeExerciseModal();
      if (cb) cb({ name, category: newCat });
    } else {
      if (!exerciseLists[newCat]) exerciseLists[newCat] = [];
      if (exerciseLists[newCat].some(e => e.name.toLowerCase() === name.toLowerCase())) {
        alert('That exercise is already in the list.');
        return;
      }
      exerciseLists[newCat].push({ name, color, isometric, unilateral, hasLeverage, pattern: pattern || undefined, straightArm: sa ? sa === 'yes' : undefined, createdAt: Date.now() });
      fillMissingPatterns();
      saveLists();
      updateExercisePicker();
      const cb = exModalOnSaved;
      closeExerciseModal();
      if (cb) cb({ name, category: newCat });
    }
  };

  // ---- select several to delete (blocks, categories, equipment, exercises) ----
  const bulk = { blocks: { on: false, sel: new Set(), ids: [] }, cats: { on: false, sel: new Set(), ids: [] }, equip: { on: false, sel: new Set(), ids: [] }, ex: { on: false, sel: new Set(), ids: [] } };
  const BULK_UI = {
    blocks: { list: 'blockEditList', btn: 'blocksSelectBtn', noun: 'block', render: () => renderBlockEditList() },
    cats: { list: 'catEditList', btn: 'categoriesSelectBtn', noun: 'category', render: () => renderCatEditList() },
    equip: { list: 'equipmentEditList', btn: 'equipmentSelectBtn', noun: 'equipment item', render: () => renderEquipmentEditList() },
    ex: { list: 'allExercisesList', btn: 'exSelectBtn', noun: 'exercise', render: () => renderAllExercisesList() }
  };
  function bulkBar(key) {
    let bar = document.getElementById('bulkBar-' + key);
    if (!bar) {
      const listEl = document.getElementById(BULK_UI[key].list);
      bar = document.createElement('div');
      bar.id = 'bulkBar-' + key; bar.className = 'bulk-bar hidden';
      bar.innerHTML = '<span class="bulk-count"></span><button type="button" class="text-btn" data-bulk="all">Select all</button><button type="button" class="text-btn text-btn-danger" data-bulk="delete">Delete</button><button type="button" class="text-btn" data-bulk="done">Done</button>';
      listEl.parentNode.insertBefore(bar, listEl);
      bar.onclick = (e) => { const b = e.target.closest('[data-bulk]'); if (b) bulkAction(key, b.dataset.bulk); };
    }
    return bar;
  }
  function refreshBulkBar(key) {
    const b = bulk[key], bar = bulkBar(key);
    bar.classList.toggle('hidden', !b.on);
    bar.querySelector('.bulk-count').textContent = b.sel.size + ' selected';
    bar.querySelector('[data-bulk="delete"]').disabled = !b.sel.size;
    bar.querySelector('[data-bulk="all"]').textContent = b.sel.size && b.sel.size === b.ids.length ? 'Select none' : 'Select all';
    const btn = document.getElementById(BULK_UI[key].btn);
    if (btn) btn.classList.toggle('on', b.on);
  }
  // called at the end of each list renderer: ids are the items in the order the rows were drawn
  function decorateBulk(listEl, key, ids) {
    const b = bulk[key];
    b.ids = ids;
    Array.from(b.sel).forEach(id => { if (!ids.includes(id)) b.sel.delete(id); });
    refreshBulkBar(key);
    if (!b.on) return;
    Array.from(listEl.children).filter(r => r.classList.contains('edit-row')).forEach((row, i) => {
      const id = ids[i];
      if (id === undefined) return;
      row.classList.add('selecting');
      const cb = document.createElement('input');
      cb.type = 'checkbox'; cb.className = 'bulk-cb'; cb.checked = b.sel.has(id); cb.setAttribute('aria-label', 'Select');
      const toggle = () => { if (cb.checked) b.sel.add(id); else b.sel.delete(id); refreshBulkBar(key); };
      cb.onchange = toggle;
      row.onclick = (e) => { if (e.target === cb || e.target.closest('input[type="color"]')) return; cb.checked = !cb.checked; toggle(); };
      row.insertBefore(cb, row.firstChild);
    });
  }
  function toggleBulk(key) { const b = bulk[key]; b.on = !b.on; b.sel.clear(); BULK_UI[key].render(); }
  function bulkAction(key, act) {
    const b = bulk[key];
    if (act === 'done') { b.on = false; b.sel.clear(); BULK_UI[key].render(); return; }
    if (act === 'all') { if (b.sel.size === b.ids.length) b.sel.clear(); else b.ids.forEach(id => b.sel.add(id)); BULK_UI[key].render(); return; }
    if (act !== 'delete' || !b.sel.size) return;
    const names = Array.from(b.sel), noun = BULK_UI[key].noun;
    let msg = `Delete ${names.length} ${noun}${names.length === 1 ? '' : 's'}?`;
    if (key === 'cats') {
      if (categories.length - names.length < 1) { alert('You need at least one category.'); return; }
      msg += ` Their exercises and logged entries move to "${UNCATEGORIZED_NAME}", nothing is deleted.`;
    } else if (key === 'blocks') msg += ' This only removes the blocks, not the exercises in them.';
    else if (key === 'equip') msg += ' Logged entries keep showing them, but they will not be selectable anymore.';
    else msg += ' Logged entries stay in your history.';
    if (!confirm(msg)) return;
    bulkQuiet = true;
    try {
      if (key === 'blocks') names.forEach(n => deleteBlock(n));
      else if (key === 'cats') names.filter(n => n !== UNCATEGORIZED_NAME).forEach(n => deleteCategory(n));
      else if (key === 'equip') names.forEach(n => deleteEquipment(n));
      else names.forEach(id => { const i = id.indexOf('||'); deleteExercise(id.slice(i + 2), id.slice(0, i)); });
    } finally { bulkQuiet = false; }
    b.on = false; b.sel.clear();
    renderCatEditList(); renderBlockEditList(); renderEquipmentEditList(); renderAllExercisesList(); renderBlockSelect();
    showToast('Deleted ' + names.length + ' ' + noun + (names.length === 1 ? '' : 's'));
  }
  Object.keys(BULK_UI).forEach(k => { const btn = document.getElementById(BULK_UI[k].btn); if (btn) btn.onclick = () => toggleBulk(k); });

  let assigningCategory = null; // name of the category currently showing its "move exercises in" checklist, or null
  let catListSort = 'added';
  function updateCatSortBtn() {
    const btn = document.getElementById('categoriesSortBtn');
    if (!btn) return;
    const alpha = catListSort === 'alphabetical';
    btn.innerHTML = `<i class="fa-solid ${alpha ? 'fa-arrow-down-a-z' : 'fa-arrow-down-wide-short'}" aria-hidden="true"></i>`;
    btn.title = `Sort: ${alpha ? 'A–Z' : 'order added'} — tap to change`;
    btn.setAttribute('aria-label', `Sort: ${alpha ? 'A–Z' : 'order added'} (tap to change)`);
  }
  function renderCatEditList() {
    updateCatSortBtn();
    catEditList.innerHTML = '';
    const catsInOrder = catListSort === 'alphabetical' ? categories.slice().sort((a, b) => a.localeCompare(b)) : categories;
    catsInOrder.forEach(cat => {
      const row = document.createElement('div');
      row.className = 'edit-row';
      const nameSpan = document.createElement('span');
      nameSpan.className = 'name';
      const colorInput = document.createElement('input');
      colorInput.type = 'color';
      colorInput.className = 'cat-color-input';
      colorInput.value = getCategoryColor(cat);
      colorInput.title = 'Edit colour';
      colorInput.setAttribute('aria-label', 'Edit colour for ' + cat);
      colorInput.onclick = (ev) => ev.stopPropagation();
      colorInput.onchange = () => {
        categoryColors[cat] = colorInput.value;
        saveLists();
        renderCatEditList();
        renderAllExercisesList();
        renderBlockEditList();
        render();
      };
      nameSpan.appendChild(colorInput);
      nameSpan.appendChild(document.createTextNode(`${cat} (${(exerciseLists[cat] || []).length})`));
      const actions = document.createElement('div');
      actions.className = 'actions';

      const assignBtn = document.createElement('button');
      assignBtn.innerHTML = '<i class="fa-solid fa-list-check" aria-hidden="true"></i>';
      assignBtn.title = 'Move exercises in';
      assignBtn.setAttribute('aria-label', 'Move exercises into ' + cat);
      if (assigningCategory === cat) assignBtn.classList.add('on');
      assignBtn.onclick = () => {
        assigningCategory = (assigningCategory === cat) ? null : cat;
        catAssignSearchQuery = '';
        const searchInput = document.getElementById('catAssignSearchInput');
        if (searchInput) searchInput.value = '';
        renderCatEditList();
      };

      const renameBtn = document.createElement('button');
      renameBtn.innerHTML = '<i class="fa-solid fa-pencil" aria-hidden="true"></i>';
      renameBtn.onclick = () => renameCategory(cat);
      const delBtn = document.createElement('button');
      delBtn.className = 'danger';
      delBtn.innerHTML = '<i class="fa-regular fa-trash-can" aria-hidden="true"></i>';
      delBtn.onclick = () => deleteCategory(cat);
      actions.appendChild(assignBtn);
      actions.appendChild(renameBtn);
      actions.appendChild(delBtn);
      row.appendChild(nameSpan);
      row.appendChild(actions);
      catEditList.appendChild(row);
    });
    decorateBulk(catEditList, 'cats', catsInOrder);
    renderCatAssignSection();
  }

  // Exercises belong to exactly one category, so "assigning" here moves an
  // exercise in from wherever it currently lives — it disappears from other
  // categories' groups the moment it lands in this one.
  let catAssignSearchQuery = "";
  function renderCatAssignSection() {
    const section = document.getElementById('catAssignSection');
    if (!assigningCategory || !categories.includes(assigningCategory)) {
      section.classList.add('hidden');
      return;
    }
    section.classList.remove('hidden');
    document.getElementById('catAssignName').textContent = assigningCategory;
    const listEl = document.getElementById('catAssignChecklist');
    listEl.innerHTML = '';
    const q = catAssignSearchQuery.toLowerCase();
    let any = false;
    categories.forEach(cat => {
      if (cat === assigningCategory) return;
      const list = (exerciseLists[cat] || []).filter(e => !q || e.name.toLowerCase().includes(q));
      if (!list.length) return;
      any = true;
      const group = document.createElement('div');
      group.className = 'existing-ex-group';
      const groupLabel = document.createElement('div');
      groupLabel.className = 'existing-ex-group-label';
      groupLabel.textContent = cat;
      group.appendChild(groupLabel);
      list.forEach(e => {
        const row = document.createElement('label');
        row.className = 'existing-ex-row';
        const cb = document.createElement('input');
        cb.type = 'checkbox';
        cb.checked = false;
        cb.onchange = () => { if (cb.checked) moveExerciseToCategory(e.name, cat, assigningCategory); };
        row.appendChild(cb);
        row.appendChild(document.createTextNode(e.name));
        const editBtn = document.createElement('button');
        editBtn.type = 'button';
        editBtn.innerHTML = '<i class="fa-solid fa-pencil" aria-hidden="true"></i>';
        editBtn.onclick = (ev) => {
          ev.preventDefault(); ev.stopPropagation();
          openExerciseModal({ exObj: e, category: cat, onSaved: () => { renderCatEditList(); renderAllExercisesList(); } });
        };
        row.appendChild(editBtn);
        group.appendChild(row);
      });
      listEl.appendChild(group);
    });
    if (!any) listEl.innerHTML = `<div class="empty" style="padding:4px 0;">${q ? 'No matching exercises.' : 'All exercises already live here, or there are none yet.'}</div>`;
    let addRow = document.getElementById('catAssignAddBtn');
    if (!addRow) {
      addRow = document.createElement('button');
      addRow.type = 'button';
      addRow.id = 'catAssignAddBtn';
      addRow.className = 'text-btn';
      addRow.style.marginTop = '8px';
      addRow.innerHTML = '<i class="fa-solid fa-plus" aria-hidden="true"></i> Add new exercise';
      document.getElementById('catAssignSection').appendChild(addRow);
    }
    addRow.onclick = () => openExerciseModal({
      defaultCategory: assigningCategory,
      onSaved: () => { renderCatEditList(); renderAllExercisesList(); }
    });
  }
  document.getElementById('catAssignSearchInput').addEventListener('input', (e) => {
    catAssignSearchQuery = e.target.value.trim();
    renderCatAssignSection();
  });

  function moveExerciseToCategory(name, fromCat, toCat) {
    const exObj = (exerciseLists[fromCat] || []).find(e => e.name === name);
    if (!exObj) return;
    exerciseLists[fromCat] = exerciseLists[fromCat].filter(e => e.name !== name);
    if (!exerciseLists[toCat]) exerciseLists[toCat] = [];
    exerciseLists[toCat].push(exObj);
    // keep block references pointing at this exercise valid
    blocks.forEach(b => {
      (blockRefs[b] || []).forEach(r => { if (r.name === name && r.refCategory === fromCat) r.refCategory = toCat; });
    });
    if (active === fromCat && selectedExercise === name) selectedExercise = "";
    saveLists();
    saveBlocks();
    renderCatEditList();
    renderAllExercisesList();
    updateExercisePicker();
    showToast(`Moved "${name}" to ${toCat}`);
  }

  // ---- All-exercises list (config page): every exercise, any category, sortable ----
  const EX_SORT_MODES = ['alphabetical', 'category', 'newest'];
  const EX_SORT_META = {
    alphabetical: { icon: 'fa-arrow-down-a-z', label: 'A–Z' },
    category: { icon: 'fa-tags', label: 'Category' },
    newest: { icon: 'fa-clock-rotate-left', label: 'Newest' }
  };
  let exListSort = 'alphabetical';
  function updateExSortBtn() {
    const btn = document.getElementById('exSortToggleBtn');
    if (!btn) return;
    const meta = EX_SORT_META[exListSort];
    btn.innerHTML = `<i class="fa-solid ${meta.icon}" aria-hidden="true"></i>`;
    btn.title = `Sort: ${meta.label} — tap to change`;
    btn.setAttribute('aria-label', `Sort: ${meta.label} (tap to change)`);
  }
  function renderAllExercisesList() {
    const listEl = document.getElementById('allExercisesList');
    if (!listEl) return;
    updateExSortBtn();
    let all = [];
    categories.forEach(cat => {
      (exerciseLists[cat] || []).forEach(exObj => all.push({ exObj, cat }));
    });
    const countEl = document.getElementById('exercisesCount');
    if (countEl) countEl.textContent = ` (${all.length})`;
    if (allExSearchQuery) {
      const q = allExSearchQuery.toLowerCase();
      all = all.filter(p => p.exObj.name.toLowerCase().includes(q));
    }
    if (exListSort === 'newest') all.sort((a, b) => (b.exObj.createdAt || 0) - (a.exObj.createdAt || 0));
    else if (exListSort === 'category') {
      all.sort((a, b) => {
        const catDiff = categories.indexOf(a.cat) - categories.indexOf(b.cat);
        return catDiff !== 0 ? catDiff : a.exObj.name.localeCompare(b.exObj.name);
      });
    } else all.sort((a, b) => a.exObj.name.localeCompare(b.exObj.name));
    listEl.innerHTML = '';
    if (!all.length) {
      listEl.innerHTML = allExSearchQuery
        ? '<div class="empty" style="padding:4px 0;">No exercises match that search.</div>'
        : '<div class="empty" style="padding:4px 0;">No exercises yet.</div>';
      return;
    }
    all.forEach(({ exObj, cat }) => {
      const row = document.createElement('div');
      row.className = 'edit-row';
      const nameSpan = document.createElement('span');
      nameSpan.className = 'name';
      const dot = document.createElement('span');
      dot.className = 'dot';
      dot.style.background = exObj.color || getCategoryColor(cat);
      nameSpan.appendChild(dot);
      nameSpan.appendChild(document.createTextNode(exObj.name));
      const catTag = document.createElement('span');
      catTag.className = 'iso-tag origin-tag';
      catTag.style.marginLeft = '6px';
      catTag.textContent = cat;
      nameSpan.appendChild(catTag);
      const actions = document.createElement('div');
      actions.className = 'actions';
      const editBtn = document.createElement('button');
      editBtn.innerHTML = '<i class="fa-solid fa-pencil" aria-hidden="true"></i>';
      editBtn.onclick = () => openExerciseModal({ exObj, category: cat, onSaved: renderAllExercisesList });
      const delBtn = document.createElement('button');
      delBtn.className = 'danger';
      delBtn.innerHTML = '<i class="fa-regular fa-trash-can" aria-hidden="true"></i>';
      delBtn.onclick = () => { deleteExercise(exObj.name, cat); renderAllExercisesList(); };
      actions.appendChild(editBtn);
      actions.appendChild(delBtn);
      row.appendChild(nameSpan);
      row.appendChild(actions);
      listEl.appendChild(row);
    });
    decorateBulk(listEl, 'ex', all.map(p => p.cat + '||' + p.exObj.name));
  }
  const exSortToggleBtn = document.getElementById('exSortToggleBtn');
  if (exSortToggleBtn) exSortToggleBtn.onclick = () => {
    const idx = EX_SORT_MODES.indexOf(exListSort);
    exListSort = EX_SORT_MODES[(idx + 1) % EX_SORT_MODES.length];
    renderAllExercisesList();
  };
  const addExerciseModalBtn = document.getElementById('addExerciseModalBtn');
  if (addExerciseModalBtn) addExerciseModalBtn.onclick = () => openExerciseModal({ defaultCategory: categories[0], onSaved: renderAllExercisesList });

  function renameCategory(oldName) {
    const newName = prompt('Rename category', oldName);
    if (!newName || !newName.trim() || newName.trim() === oldName) return;
    const trimmed = newName.trim();
    if (categories.includes(trimmed)) { alert('A category with that name already exists.'); return; }
    categories = categories.map(c => c === oldName ? trimmed : c);
    exerciseLists[trimmed] = exerciseLists[oldName];
    delete exerciseLists[oldName];
    data[trimmed] = data[oldName];
    delete data[oldName];
    categoryColors[trimmed] = categoryColors[oldName];
    delete categoryColors[oldName];
    if (active === oldName) active = trimmed;
    if (assigningCategory === oldName) assigningCategory = trimmed;
    saveLists();
    saveData();
    updateExercisePicker();
    render();
    renderCatEditList();
    renderAllExercisesList();
  }

  function deleteCategory(name) {
    if (categories.length <= 1) { alert('You need at least one category.'); return; }
    const exCount = (exerciseLists[name] || []).length;
    const entryCount = (data[name] || []).length;
    const moveParts = [];
    if (exCount > 0) moveParts.push(`${exCount} exercise${exCount === 1 ? '' : 's'}`);
    if (entryCount > 0) moveParts.push(`${entryCount} logged entr${entryCount === 1 ? 'y' : 'ies'}`);
    let msg = `Delete "${name}"?`;
    if (moveParts.length) msg += ` Its ${moveParts.join(' and ')} will move to "${UNCATEGORIZED_NAME}" — nothing gets deleted.`;
    if (!bulkQuiet && !confirm(msg)) return;

    // Exercises (and their logged history) outlive the category they were filed
    // under — deleting a category only removes the category, never the exercises.
    if (exCount > 0 || entryCount > 0) {
      if (!categories.includes(UNCATEGORIZED_NAME)) {
        categories.push(UNCATEGORIZED_NAME);
        getCategoryColor(UNCATEGORIZED_NAME);
      }
      if (!exerciseLists[UNCATEGORIZED_NAME]) exerciseLists[UNCATEGORIZED_NAME] = [];
      if (!data[UNCATEGORIZED_NAME]) data[UNCATEGORIZED_NAME] = [];
      exerciseLists[UNCATEGORIZED_NAME] = exerciseLists[UNCATEGORIZED_NAME].concat(exerciseLists[name] || []);
      data[UNCATEGORIZED_NAME] = data[UNCATEGORIZED_NAME].concat(data[name] || []);
      // keep block references pointing at the moved exercises valid
      blocks.forEach(b => {
        (blockRefs[b] || []).forEach(r => { if (r.refCategory === name) r.refCategory = UNCATEGORIZED_NAME; });
      });
    }

    categories = categories.filter(c => c !== name);
    delete exerciseLists[name];
    delete data[name];
    delete categoryColors[name];
    if (active === name) active = categories[0];
    if (assigningCategory === name) assigningCategory = null;
    saveLists();
    saveData();
    saveBlocks();
    updateExercisePicker();
    render();
    renderCatEditList();
    renderAllExercisesList();
    renderBlockSelect();
  }

  document.getElementById('addCatBtn').onclick = () => {
    const name = newCatInput.value.trim();
    if (!name) return;
    if (categories.includes(name)) { alert('That category already exists.'); return; }
    categories.push(name);
    exerciseLists[name] = [];
    data[name] = [];
    getCategoryColor(name);
    newCatInput.value = '';
    saveLists();
    saveData();
    render();
    renderCatEditList();
  };
  newCatInput.addEventListener('keydown', (e) => { if (e.key === 'Enter') document.getElementById('addCatBtn').click(); });
  document.getElementById('categoriesSortBtn').onclick = () => {
    catListSort = (catListSort === 'added') ? 'alphabetical' : 'added';
    renderCatEditList();
  };

  // ---- Equipment management (list editor + the picker used while logging) ----
  let equipmentListSort = 'added';
  function updateEquipmentSortBtn() {
    const btn = document.getElementById('equipmentSortBtn');
    if (!btn) return;
    const alpha = equipmentListSort === 'alphabetical';
    btn.innerHTML = `<i class="fa-solid ${alpha ? 'fa-arrow-down-a-z' : 'fa-arrow-down-wide-short'}" aria-hidden="true"></i>`;
    btn.title = `Sort: ${alpha ? 'A–Z' : 'order added'} — tap to change`;
    btn.setAttribute('aria-label', `Sort: ${alpha ? 'A–Z' : 'order added'} (tap to change)`);
  }
  function renderEquipmentEditList() {
    updateEquipmentSortBtn();
    const listEl = document.getElementById('equipmentEditList');
    listEl.innerHTML = '';
    if (!equipmentList.length) {
      listEl.innerHTML = '<div class="empty" style="padding:4px 0;">No equipment yet — add one below.</div>';
    }
    const inOrder = equipmentListSort === 'alphabetical' ? equipmentList.slice().sort((a, b) => a.localeCompare(b)) : equipmentList;
    inOrder.forEach(name => {
      const row = document.createElement('div');
      row.className = 'edit-row';
      const nameSpan = document.createElement('span');
      nameSpan.className = 'name';
      const colorInput = document.createElement('input');
      colorInput.type = 'color';
      colorInput.className = 'cat-color-input';
      colorInput.value = getEquipmentColor(name);
      colorInput.title = 'Edit colour';
      colorInput.setAttribute('aria-label', 'Edit colour for ' + name);
      colorInput.onclick = (ev) => ev.stopPropagation();
      colorInput.onchange = () => {
        equipmentColors[name] = colorInput.value;
        saveEquipment();
      };
      nameSpan.appendChild(colorInput);
      nameSpan.appendChild(document.createTextNode(name));
      const actions = document.createElement('div');
      actions.className = 'actions';
      const renameBtn = document.createElement('button');
      renameBtn.innerHTML = '<i class="fa-solid fa-pencil" aria-hidden="true"></i>';
      renameBtn.onclick = () => renameEquipment(name);
      const delBtn = document.createElement('button');
      delBtn.className = 'danger';
      delBtn.innerHTML = '<i class="fa-regular fa-trash-can" aria-hidden="true"></i>';
      delBtn.onclick = () => deleteEquipment(name);
      actions.appendChild(renameBtn);
      actions.appendChild(delBtn);
      row.appendChild(nameSpan);
      row.appendChild(actions);
      listEl.appendChild(row);
    });
    decorateBulk(listEl, 'equip', inOrder);
  }
  // Per-set equipment dropdowns: fill one, or refresh all after the equipment list changes.
  function fillEquipSelect(sel, current) {
    if (!sel) return;
    const keep = current !== undefined ? current : sel.value;
    sel.innerHTML = '';
    const noneOpt = document.createElement('option');
    noneOpt.value = '';
    noneOpt.textContent = 'Equipment';
    sel.appendChild(noneOpt);
    equipmentList.forEach(name => {
      const opt = document.createElement('option');
      opt.value = name;
      opt.textContent = name;
      sel.appendChild(opt);
    });
    sel.value = equipmentList.includes(keep) ? keep : '';
  }
  function renderEquipmentSelect() {
    document.querySelectorAll('#setsGrid select[id^="equip"]').forEach(sel => fillEquipSelect(sel)); // only the equipment selects (RPE, flag, variation and chain share the class)
  }
  function renameEquipment(oldName) {
    const newName = prompt('Rename equipment', oldName);
    if (!newName || !newName.trim() || newName.trim() === oldName) return;
    const trimmed = newName.trim();
    if (equipmentList.includes(trimmed)) { alert('That equipment already exists.'); return; }
    equipmentList = equipmentList.map(n => n === oldName ? trimmed : n);
    if (equipmentColors[oldName]) { equipmentColors[trimmed] = equipmentColors[oldName]; delete equipmentColors[oldName]; }
    // keep already-logged entries pointing at the renamed tag
    categories.forEach(cat => { (data[cat] || []).forEach(e => {
      if (e.equipment === oldName) e.equipment = trimmed;
      (e.sets || []).forEach(s => { if (s && typeof s === 'object' && s.equipment === oldName) s.equipment = trimmed; });
    }); });
    saveEquipment();
    saveData();
    renderEquipmentEditList();
    renderEquipmentSelect();
  }
  function deleteEquipment(name) {
    const usedCount = categories.reduce((n, cat) => n + (data[cat] || []).filter(e => e.equipment === name || (e.sets || []).some(s => s && typeof s === 'object' && s.equipment === name)).length, 0);
    let msg = `Delete "${name}"?`;
    if (usedCount > 0) msg += ` ${usedCount} already-logged entr${usedCount === 1 ? 'y' : 'ies'} will keep showing it, but it won't be selectable anymore.`;
    if (!bulkQuiet && !confirm(msg)) return;
    equipmentList = equipmentList.filter(n => n !== name);
    delete equipmentColors[name];
    saveEquipment();
    renderEquipmentEditList();
    renderEquipmentSelect();
  }
  document.getElementById('addEquipmentBtn').onclick = () => {
    const input = document.getElementById('newEquipmentInput');
    const name = input.value.trim();
    if (!name) return;
    if (equipmentList.includes(name)) { alert('That equipment already exists.'); return; }
    equipmentList.push(name);
    getEquipmentColor(name);
    saveEquipment();
    input.value = '';
    renderEquipmentEditList();
    renderEquipmentSelect();
  };
  document.getElementById('newEquipmentInput').addEventListener('keydown', (e) => { if (e.key === 'Enter') document.getElementById('addEquipmentBtn').click(); });
  document.getElementById('equipmentSortBtn').onclick = () => {
    equipmentListSort = (equipmentListSort === 'added') ? 'alphabetical' : 'added';
    renderEquipmentEditList();
  };

  // ---- Bodyweight management (weigh-in list; one entry per date) ----
  function renderBodyweightList() {
    const listEl = document.getElementById('bodyweightList');
    const summaryEl = document.getElementById('bodyweightSummary');
    document.getElementById('bwValueInput').placeholder = weightUnitLabel();
    listEl.innerHTML = '';
    const sorted = bodyweightLog.slice().sort((a, b) => b.date.localeCompare(a.date)); // newest first
    listEl.classList.toggle('hidden', !sorted.length);
    summaryEl.classList.toggle('hidden', !sorted.length);
    if (!sorted.length) return;
    const latest = sorted[0];
    const first = sorted[sorted.length - 1];
    let summary = `Latest: <b>${round2(kgToDisplay(latest.kg))} ${weightUnitLabel()}</b> (${latest.date})`;
    if (sorted.length > 1) {
      const diff = round2(kgToDisplay(latest.kg) - kgToDisplay(first.kg));
      summary += ` · ${diff > 0 ? '+' : ''}${diff} ${weightUnitLabel()} since ${first.date}`;
    }
    summaryEl.innerHTML = summary;
    sorted.forEach(e => {
      const row = document.createElement('div');
      row.className = 'edit-row';
      const nameSpan = document.createElement('span');
      nameSpan.className = 'name';
      nameSpan.textContent = `${e.date} — ${round2(kgToDisplay(e.kg))} ${weightUnitLabel()}`;
      const actions = document.createElement('div');
      actions.className = 'actions';
      const editBtn = document.createElement('button');
      editBtn.innerHTML = '<i class="fa-solid fa-pencil" aria-hidden="true"></i>';
      editBtn.title = 'Edit';
      editBtn.onclick = () => editBodyweight(e.id);
      const delBtn = document.createElement('button');
      delBtn.className = 'danger';
      delBtn.innerHTML = '<i class="fa-regular fa-trash-can" aria-hidden="true"></i>';
      delBtn.title = 'Delete';
      delBtn.onclick = () => deleteBodyweight(e.id);
      actions.appendChild(editBtn);
      actions.appendChild(delBtn);
      row.appendChild(nameSpan);
      row.appendChild(actions);
      listEl.appendChild(row);
    });
  }
  function editBodyweight(id) {
    const entry = bodyweightLog.find(e => e.id === id);
    if (!entry) return;
    const newDate = prompt('Date (YYYY-MM-DD):', entry.date);
    if (newDate === null) return;
    const trimmedDate = newDate.trim();
    if (!/^\d{4}-\d{2}-\d{2}$/.test(trimmedDate)) { alert('Please use the format YYYY-MM-DD.'); return; }
    if (trimmedDate !== entry.date && bodyweightLog.some(e => e.date === trimmedDate)) { alert('There is already a weigh-in on that date.'); return; }
    const newWeight = prompt(`Bodyweight (${weightUnitLabel()}):`, String(round2(kgToDisplay(entry.kg))));
    if (newWeight === null) return;
    const v = Number(newWeight.trim());
    if (!(v > 0)) { alert('Enter a weight greater than 0.'); return; }
    entry.date = trimmedDate;
    entry.kg = Math.round(displayToKg(v) * 100) / 100;
    saveBodyweight();
    renderBodyweightList();
  }
  function deleteBodyweight(id) {
    const entry = bodyweightLog.find(e => e.id === id);
    if (!entry) return;
    if (!confirm(`Delete the ${entry.date} weigh-in?`)) return;
    bodyweightLog = bodyweightLog.filter(e => e.id !== id);
    saveBodyweight();
    renderBodyweightList();
  }
  document.getElementById('bwDateInput').valueAsDate = new Date();
  document.getElementById('addBodyweightBtn').onclick = () => {
    const date = document.getElementById('bwDateInput').value;
    const valStr = document.getElementById('bwValueInput').value;
    const v = Number(valStr);
    if (!date || valStr === '' || !(v > 0)) { alert('Enter a date and a weight greater than 0.'); return; }
    const kg = Math.round(displayToKg(v) * 100) / 100;
    const existing = bodyweightLog.find(e => e.date === date);
    if (existing) { existing.kg = kg; showToast('Updated the ' + date + ' weigh-in'); }
    else bodyweightLog.push({ id: Date.now().toString(), date, kg });
    saveBodyweight();
    document.getElementById('bwValueInput').value = '';
    renderBodyweightList();
  };
  document.getElementById('bwValueInput').addEventListener('keydown', (e) => { if (e.key === 'Enter') document.getElementById('addBodyweightBtn').click(); });

