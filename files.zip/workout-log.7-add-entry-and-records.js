  // ---- Add entry ----
  // Where an entry for this exercise is filed (Main workout / blocks own nothing themselves).
  function categoryForExercise(exercise) {
    return activeBlock
      ? ((findExerciseOwner(exercise) || {}).category || active)
      : active;
  }
  function entryHasData(e) {
    return !!((e.sets && e.sets.length) || (e.attempts && e.attempts.length) || e.distance != null || e.timeMinutes != null || e.elevation != null);
  }
  // Personal records are judged per variation: a 5 s straddle is compared with earlier straddles, not with a 20 s tuck.
  function isoPRHits(sets, attempts, priorBests) {
    const prHits = [];
    const holdCandidates = sets.map(Shared.cleanReps).concat(attempts.map(Number)).filter(v => v > 0);
    if (holdCandidates.length) {
      const sessionBest = Math.max(...holdCandidates);
      if (priorBests.bestHold === null || sessionBest > priorBests.bestHold) {
        prHits.push(`hold ${sessionBest}s` + (priorBests.bestHold !== null ? ` (prev ${priorBests.bestHold}s)` : ''));
      }
    }
    const kgCandidates = sets.map(s => (s && typeof s === 'object' && s.kg != null && s.kg !== '') ? Number(s.kg) : null).filter(v => v !== null && !isNaN(v) && v > 0);
    if (kgCandidates.length) {
      const sessionBestKg = Math.max(...kgCandidates);
      if (priorBests.bestWeight === null || sessionBestKg > priorBests.bestWeight) {
        prHits.push(`weight ${formatLoadKg(sessionBestKg)}` + (priorBests.bestWeight !== null ? ` (prev ${formatLoadKg(priorBests.bestWeight)})` : ''));
      }
    }
    return prHits;
  }
  function repPRHits(sets, priorBests, date) {
    const prHits = [];
    const repsCandidates = sets.map(Shared.cleanReps).filter(v => v > 0);
    if (repsCandidates.length) {
      const sessionBestReps = Math.max(...repsCandidates);
      if (priorBests.bestReps === null || sessionBestReps > priorBests.bestReps) {
        prHits.push(`reps ${sessionBestReps}` + (priorBests.bestReps !== null ? ` (prev ${priorBests.bestReps})` : ''));
      }
    }
    const kgCandidates = sets.map(s => (s && typeof s === 'object' && s.kg != null && s.kg !== '') ? Number(s.kg) : null).filter(v => v !== null && !isNaN(v) && v > 0);
    if (kgCandidates.length) {
      const sessionBestKg = Math.max(...kgCandidates);
      if (priorBests.bestWeight === null || sessionBestKg > priorBests.bestWeight) {
        prHits.push(`weight ${formatLoadKg(sessionBestKg)}` + (priorBests.bestWeight !== null ? ` (prev ${formatLoadKg(priorBests.bestWeight)})` : ''));
      }
    }
    // Beating the best set by estimated 1RM or by weight x reps counts too (e.g. more reps at a lighter load).
    // Only compared against an earlier best, so a first weighted set isn't announced three times.
    const bwSortedNow = sortedBodyweightLog();
    const loads = sets.map(s => setLoadMetrics(s, bodyweightKgOnDate(bwSortedNow, date))).filter(Boolean);
    const fmtLoad = v => `${round2(kgToDisplay(v))}${weightUnitLabel()}`;
    const sessionE1RM = Math.max(0, ...loads.map(l => l.e1rm || 0));
    if (priorBests.bestE1RM !== null && sessionE1RM > priorBests.bestE1RM + 1e-9) {
      prHits.push(`est. 1RM ${fmtLoad(sessionE1RM)} (prev ${fmtLoad(priorBests.bestE1RM)})`);
    }
    const sessionVolume = Math.max(0, ...loads.map(l => l.volume));
    if (priorBests.bestSetVolume !== null && sessionVolume > priorBests.bestSetVolume + 1e-9) {
      prHits.push(`set volume ${fmtLoad(sessionVolume)} (prev ${fmtLoad(priorBests.bestSetVolume)})`);
    }
    return prHits;
  }
  function distancePRHits(entry, priorBests) {
    const prHits = [];
    if (entry.distance != null && entry.distance > 0 && (priorBests.bestDistance === null || entry.distance > priorBests.bestDistance)) {
      prHits.push(`distance ${round2(kmToDisplay(entry.distance))}${distanceUnitLabel()}` + (priorBests.bestDistance !== null ? ` (prev ${round2(kmToDisplay(priorBests.bestDistance))}${distanceUnitLabel()})` : ''));
    }
    if (entry.timeMinutes != null && entry.timeMinutes > 0 && (priorBests.bestTime === null || entry.timeMinutes > priorBests.bestTime)) {
      prHits.push(`time ${formatDuration(entry.timeMinutes)}` + (priorBests.bestTime !== null ? ` (prev ${formatDuration(priorBests.bestTime)})` : ''));
    }
    if (entry.elevation != null && entry.elevation > 0 && (priorBests.bestElevation === null || entry.elevation > priorBests.bestElevation)) {
      prHits.push(`elevation ${round2(mToDisplay(entry.elevation))}${elevationUnitLabel()}` + (priorBests.bestElevation !== null ? ` (prev ${round2(mToDisplay(priorBests.bestElevation))}${elevationUnitLabel()})` : ''));
    }
    if (entry.distance != null && entry.distance > 0 && entry.timeMinutes != null && entry.timeMinutes > 0) {
      const pace = entry.timeMinutes / entry.distance;
      if (priorBests.bestPaceMinPerKm === null || pace < priorBests.bestPaceMinPerKm) {
        prHits.push(`pace ${formatPace(pace)}/km` + (priorBests.bestPaceMinPerKm !== null ? ` (prev ${formatPace(priorBests.bestPaceMinPerKm)}/km)` : ''));
      }
    }
    return prHits;
  }
  // Re-judges the PR badge of every entry (or of one exercise) against only what was logged before it.
  function recalcPRs(onlyName) {
    let changed = 0;
    categories.forEach(cat => (data[cat] || []).forEach(e => {
      if (onlyName && e.exercise !== onlyName) return;
      const key = entryKey(e);
      let hits = [];
      if (e.distance != null && e.distance !== '') hits = distancePRHits(e, computeExerciseBests(e.exercise, exerciseVariations(e.exercise).length ? (e.variation || '') : undefined, key));
      else if ((e.sets && e.sets.length) || (e.attempts && e.attempts.length)) {
        e.sets = e.sets || []; e.attempts = e.attempts || [];
        hits = prHitsByVariation(e.exercise, e, !!e.isometric, key);
      }
      const was = !!e.isPR;
      e.isPR = hits.length > 0;
      if (e.isPR) e.prTypes = hits; else delete e.prTypes;
      if (was !== e.isPR) changed++;
    }));
    saveData();
    return changed;
  }
  function prHitsByVariation(exercise, entry, isometric, cutoffKey) {
    const keys = Array.from(new Set(entry.sets.map(setVar)));
    if (isometric && entry.attempts.length && !keys.includes('')) keys.push('');
    const out = [];
    keys.forEach(k => {
      const sets = entry.sets.filter(s => setVar(s) === k);
      const prior = computeExerciseBests(exercise, k, cutoffKey);
      const hits = isometric ? isoPRHits(sets, k === '' ? entry.attempts : [], prior) : repPRHits(sets, prior, entry.date);
      hits.forEach(t => out.push(k ? `${k}: ${t}` : t));
    });
    return out;
  }
  // Builds (does not store) an entry from whatever is currently typed into the log inputs for `exercise`.
  function buildEntryFromInputs(date, exercise) {
    const exObj = findActiveExerciseObj(exercise);
    const entry = {
      id: Date.now().toString(),
      updatedAt: Date.now(),
      date, exercise,
      isometric: exObj ? !!exObj.isometric : false,
      unilateral: isUnilateralExercise(exercise),
      notes: notesInput.value.trim(),
      supersetId: activeSuperset ? activeSuperset.id : null
    };

    if (isDistanceExercise(exercise)) {
      const ruckKgInput = document.getElementById('ruckKgInput');
      const elevationInput = document.getElementById('elevationInput');
      const timeInput = document.getElementById('timeInput');
      entry.distance = distanceInput.value !== '' ? displayToKm(Number(distanceInput.value)) : null;
      entry.ruckKg = ruckKgInput.value !== '' ? displayToKg(Number(ruckKgInput.value)) : null;
      entry.elevation = elevationInput.value !== '' ? displayToM(Number(elevationInput.value)) : null;
      entry.timeMinutes = timeInput.value !== '' ? parseTimeInput(timeInput.value) : null;
      entry.variation = (document.getElementById('distVarSelect') || {}).value || null;
      entry.sets = [];
      entry.attempts = [];
    } else if (entry.isometric && holdMode === 'attempts') {
      entry.attempts = readAttempts();
      entry.sets = [];
      entry.distance = null;
    } else {
      entry.sets = readSets(exercise);
      entry.attempts = [];
      entry.distance = null;
    }

    if (entry.isometric && (entry.sets.length || entry.attempts.length)) {
      const prHits = prHitsByVariation(exercise, entry, true);
      entry.isPR = prHits.length > 0;
      if (entry.isPR) {
        entry.prTypes = prHits;
        showToast(`🎉 New PR: ${prHits.join(', ')}`);
      }
    } else if (isDistanceExercise(exercise)) {
      const priorBests = computeExerciseBests(exercise, exerciseVariations(exercise).length ? (entry.variation || '') : undefined);
      const prHits = distancePRHits(entry, priorBests);
      entry.isPR = prHits.length > 0;
      if (entry.isPR) {
        entry.prTypes = prHits;
        showToast(`🎉 New PR: ${prHits.join(', ')}`);
      }
    } else if (entry.sets.length) {
      const prHits = prHitsByVariation(exercise, entry, false);
      entry.isPR = prHits.length > 0;
      if (entry.isPR) {
        entry.prTypes = prHits;
        showToast(`🎉 New PR: ${prHits.join(', ')}`);
      }
    }

    return entry;
  }

  document.getElementById('addBtn').onclick = () => {
    errEl.classList.add('hidden');
    const date = dateInput.value;
    const hasList = activeHasExerciseList();
    const exercise = currentExerciseName();
    const fail = (msg) => { errEl.textContent = msg; errEl.classList.remove('hidden'); };

    if (!date) { fail('Pick a date first.'); return; }

    const skillsMetBefore = metStepIds();
    const added = []; // { name, entry, cat }
    const members = hasList ? supersetMemberNames() : [];
    if (members.length > 1) {
      // Superset with several exercises picked: log every one that has values typed in.
      const before = selectedExercise;
      snapshotDraft(before);
      members.forEach(name => {
        selectedExercise = name;
        restoreDraft(name);
        const entry = buildEntryFromInputs(date, name);
        if (entryHasData(entry)) added.push({ name, entry, cat: categoryForExercise(name) });
      });
      if (!added.length) {
        selectedExercise = before;
        restoreDraft(before);
        fail('Enter values for at least one of the selected exercises.');
        return;
      }
      added.forEach((a, i) => { if (i > 0) a.entry.id = a.entry.id + '_' + i; }); // unique ids within the same millisecond
    } else {
      if (!exercise) { fail(hasList ? 'Select an exercise.' : 'Enter an exercise name.'); return; }
      added.push({ name: exercise, entry: buildEntryFromInputs(date, exercise), cat: categoryForExercise(exercise) });
    }

    added.forEach(a => {
      if (!data[a.cat]) data[a.cat] = [];
      data[a.cat].push(a.entry);
    });
    saveData();
    { const pm = activeBlock ? planMeta[activeBlock] : null; if (pm && pm.uid) recordPlanSession(pm, date); }
    if (activeSuperset) { activeSuperset.count += added.length; }
    const anyPR = added.some(a => a.entry.isPR);
    if (added.length > 1 && !anyPR) showToast(`Logged ${added.length} exercises`);
    announceNewlyMetSkills(skillsMetBefore, anyPR);

    // jump the calendar to the month of the entry you just added, so it's visible immediately
    const addedDate = new Date(date + 'T00:00:00');
    calViewDate = new Date(addedDate.getFullYear(), addedDate.getMonth(), 1);
    expandedWeeks.add(getWeekStart(date)); // open the week group the new entry is in

    if (hasList) {
      selectedExercise = "";
      updateExercisePicker();
    } else {
      exerciseText.value = '';
    }
    added.forEach(a => { delete exerciseDrafts[a.name]; }); // just submitted — no longer in-progress drafts
    resetLogInputs({ clearEquipment: true });
    renderModifiers();
    if (activeSuperset) updateSupersetUI();

    renderEntries();
    renderCalendar();
  };

