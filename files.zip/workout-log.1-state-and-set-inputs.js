/* Workout log: main app script.
   Loaded by workout-log-standalone.html right after the page markup, so every element it uses already exists.
   Extra features live in workout-tools.js, workout-library.js and workout-profile.js (loaded afterwards). */
(function () {
  // ---------- Everything below is self-contained: no other files required ----------
  const LEGACY_MAIN_CATEGORY = "Main workout"; // retired category: ignored when loading or importing old data
  const UNCATEGORIZED_NAME = "Uncategorized";
  const DEFAULT_EXERCISE_LISTS = {
    "Push": [
      { name: "Assisted HS push/hold", color: "#c7a6e0", isometric: true },
      { name: "Pseudo planche", color: "#e0cd9e", isometric: true },
      { name: "Push-ups", color: null, isometric: false },
      { name: "Pike raised", color: null, isometric: false },
      { name: "Pike Def", color: null, isometric: false },
      { name: "Dips", color: null, isometric: false },
      { name: "Tricep dips", color: null, isometric: false },
      { name: "OAP", color: null, isometric: false },
      { name: "HSPU", color: null, isometric: false }
    ],
    "Pull": [
      { name: "Pull-ups", color: null, isometric: false }
    ],
    "Legs": [
      { name: "Running", color: null, isometric: false },
      { name: "Reverse Nordic", color: null, isometric: false },
      { name: "Nordic 15kg", color: null, isometric: false },
      { name: "Pistol squat", color: null, isometric: false },
      { name: "Pistol R", color: null, isometric: false },
      { name: "Pistol L", color: null, isometric: false }
    ],
    "Skill": [
      { name: "Tucked lever", color: "#8ec9ac", isometric: true, unilateral: true },
      { name: "Tucked planche", color: "#9db8e8", isometric: true },
      { name: "Full extend", color: null, isometric: false }
    ]
  };
  const Shared = window.WorkoutShared; // helpers shared with the graph page (workout-shared.js)
  const COLOR_PALETTE = Shared.COLOR_PALETTE;
  const EX_COLOR_PALETTE = ["#4B0F45", "#FFEEE4", "#E1D571", "#E4599C", "#FE9214", "#6FE3CC", "#185D7A", "#C8DB2A", "#EF4687", "#F8CF9B"];
  const PER_LEG_EXERCISES = ["tucked lever"];
  const MIN_SETS = 1;
  const MAX_SETS = 20;
  const DEFAULT_NUM_SETS = 1; // every exercise starts with one set; Add set / Remove set only change the current screen

  const DATA_KEY = "workout-log-data-v1";
  const LISTS_KEY = "workout-log-lists-v3";
  const LAYOUT_KEY = "workout-log-layout-v1";
  const NUMSETS_KEY = "workout-log-numsets-v1"; // no longer used; kept so Reset still clears an old saved value
  const THEME_KEY = "workout-log-theme-v1";
  // older keys this page can recover data from, so nothing gets lost switching versions
  const LEGACY_LISTS_KEYS = ["workout-log-lists-v2", "workout-log-lists-v1"];

  const THEMES = Shared.THEMES; // the colour themes live in workout-shared.js so the graph page matches

  // Generic localStorage helpers - shared by numSets/theme/layout/lists, all of
  // which just need "read an int/JSON value, falling back safely if absent or bad".
  function lsSet(key, value) { try { localStorage.setItem(key, String(value)); } catch (e) { /* ignore */ } }
  function lsInt(key, isValid, fallback) {
    try {
      const n = parseInt(localStorage.getItem(key), 10);
      if (!isNaN(n) && isValid(n)) return n;
    } catch (e) { /* ignore */ }
    return fallback;
  }
  function loadNumSets() { return DEFAULT_NUM_SETS; }
  function loadTheme() { return lsInt(THEME_KEY, idx => !!THEMES[idx], 0); }
  function applyTheme(idx) { Shared.applyTheme(idx, themeMode); }
  function saveTheme(idx) { lsSet(THEME_KEY, idx); }

  // ---- Light / dark appearance mode (independent of the accent colour theme above) ----
  const MODE_KEY = "workout-log-mode-v1";
  const UNITS_KEY = Shared.UNITS_KEY;
  function loadUnits() { return Shared.loadUnits(); }
  function saveUnits(units) { lsSet(UNITS_KEY, units); }
  let unitSystem = loadUnits();
  let weekStart = Shared.loadWeekStart();
  const { KM_TO_MI, KG_TO_LB, M_TO_FT } = Shared;
  // These convert the distance-mode fields (km/rucking kg/elevation) and the per-set "Weighted" label —
  // the underlying stored kg value itself is not converted, only the displayed unit text.
  function distanceUnitLabel() { return Shared.distanceUnitLabel(unitSystem); }
  function weightUnitLabel() { return Shared.weightUnitLabel(unitSystem); }
  function elevationUnitLabel() { return Shared.elevationUnitLabel(unitSystem); }
  function kmToDisplay(km) { return Shared.kmToDisplay(unitSystem, km); }
  function displayToKm(v) { return unitSystem === 'imperial' ? v / KM_TO_MI : v; }
  function kgToDisplay(kg) { return Shared.kgToDisplay(unitSystem, kg); }
  function displayToKg(v) { return unitSystem === 'imperial' ? v / KG_TO_LB : v; }
  function round2(n) { return Shared.round2(n); }
  // set weights are stored in kg; the weight field is typed in the unit chosen in settings
  function kgFromInput(v) { return Math.round(displayToKg(Number(v)) * 1000) / 1000; }
  function mToDisplay(m) { return Shared.mToDisplay(unitSystem, m); }
  function displayToM(v) { return unitSystem === 'imperial' ? v / M_TO_FT : v; }
  // Accepts "2:50", "2.50" (hours + literal minutes, not a decimal fraction) or a plain
  // number of minutes ("45"), and returns the total in minutes.
  function parseTimeInput(str) {
    if (str == null) return null;
    const s = String(str).trim();
    if (s === '') return null;
    const m = s.match(/^(\d+)[:.](\d{1,2})$/);
    if (m) return parseInt(m[1], 10) * 60 + parseInt(m[2], 10);
    const n = Number(s);
    return isNaN(n) ? null : Math.round(n);
  }
  function formatDuration(totalMinutes) { return Shared.formatDuration(totalMinutes); }
  // Same total, formatted back into the "H:MM" shape the time input accepts, for prefilling edit prompts.
  function timeMinutesToInputString(totalMinutes) {
    if (totalMinutes == null || isNaN(totalMinutes)) return '';
    const h = Math.floor(totalMinutes / 60);
    const m = totalMinutes % 60;
    return h > 0 ? `${h}:${String(m).padStart(2, '0')}` : String(m);
  }
  // Pace as minutes-per-distance-unit -> "M:SS" (e.g. a 5:30/km pace).
  function formatPace(minutesPerUnit) { return Shared.formatPace(minutesPerUnit); }
  // Distance entries only: minutes per km/mi, derived from the logged time and distance.
  function paceForEntry(entry) { return Shared.paceForEntry(unitSystem, entry); }
  function systemPrefersDark() {
    return !!(window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches);
  }
  function loadMode() {
    try {
      const saved = localStorage.getItem(MODE_KEY);
      if (saved === 'light' || saved === 'dark') return saved;
    } catch (e) { /* ignore */ }
    return systemPrefersDark() ? 'dark' : 'light';
  }
  function applyMode(mode) { document.documentElement.setAttribute('data-theme', mode); }
  function saveMode(mode) { lsSet(MODE_KEY, mode); }
  function renderModeToggle() {
    document.querySelectorAll('#modeToggle .mode-btn').forEach(btn => {
      btn.classList.toggle('active', btn.dataset.mode === themeMode);
    });
  }
  document.querySelectorAll('#modeToggle .mode-btn').forEach(btn => {
    btn.onclick = () => {
      themeMode = btn.dataset.mode;
      applyMode(themeMode);
      saveMode(themeMode);
      renderModeToggle();
      applyTheme(themeIndex);
    };
  });
  function renderUnitsToggle() {
    document.querySelectorAll('#unitsToggle .mode-btn').forEach(btn => {
      btn.classList.toggle('active', btn.dataset.units === unitSystem);
    });
  }
  document.querySelectorAll('#unitsToggle .mode-btn').forEach(btn => {
    btn.onclick = () => {
      unitSystem = btn.dataset.units;
      saveUnits(unitSystem);
      lsSet('workout-log-prefs-ts-v1', Date.now());
      renderUnitsToggle();
      renderModifiers();
      renderBodyweightList(); // weigh-in list + its input placeholder show the unit
    };
  });
  renderUnitsToggle();
  function renderWeekToggle() { document.querySelectorAll('#weekToggle .mode-btn').forEach(btn => btn.classList.toggle('active', +btn.dataset.week === weekStart)); }
  document.querySelectorAll('#weekToggle .mode-btn').forEach(btn => {
    btn.onclick = () => {
      weekStart = +btn.dataset.week;
      lsSet(Shared.WEEK_KEY, weekStart);
      lsSet('workout-log-prefs-ts-v1', Date.now());
      renderWeekToggle();
      expandedWeeks = new Set(); weeksNeedDefaultExpand = true;
      renderCalendar(); renderEntries();
    };
  });
  renderWeekToggle();
  (function setupFlagsToggle() {
    const KEY = 'workout-log-setflags-v1', box = document.getElementById('setFlagsToggle');
    let on = false;
    try { on = localStorage.getItem(KEY) === '1'; } catch (e) { /* off */ }
    document.documentElement.classList.toggle('flags-on', on);
    if (!box) return;
    box.checked = on;
    box.onchange = () => { document.documentElement.classList.toggle('flags-on', box.checked); lsSet(KEY, box.checked ? '1' : '0'); };
  })();
  let showLast = true;
  try { showLast = localStorage.getItem('workout-log-showlast-v1') !== '0'; } catch (e) { /* on */ }
  function resetEccPlaceholders() { document.querySelectorAll('#setsGrid input.ecc-input').forEach(i => { i.placeholder = 'sec'; }); }
  (function () {
    const box = document.getElementById('showLastToggle');
    if (!box) return;
    box.checked = showLast;
    box.onchange = () => { showLast = box.checked; lsSet('workout-log-showlast-v1', showLast ? '1' : '0'); resetEccPlaceholders(); renderModifiers(); };
  })();
  let themeMode = loadMode();
  let numSets = loadNumSets();
  let themeIndex = loadTheme();

  const DEFAULT_LAYOUT = [
    { id: "exercise", visible: true },
    { id: "metrics", visible: true },
    { id: "notes", visible: true },
    { id: "addButton", visible: true },
    { id: "calendar", visible: true },
    { id: "entries", visible: true }
  ];
  const MODULE_LABELS = {
    exercise: "Exercise", metrics: "Sets & reps",
    notes: "Notes", addButton: "Add entry button", calendar: "Calendar",
    entries: "Entries list"
  };

  function normalizeExercise(e) {
    if (typeof e === "string") return { name: e, color: null, isometric: false, unilateral: false };
    return Object.assign({}, e, {
      name: e.name || "", color: e.color || null,
      isometric: !!e.isometric,
      unilateral: e.unilateral !== undefined ? !!e.unilateral : PER_LEG_EXERCISES.includes((e.name || '').trim().toLowerCase())
    });
  }
  function migrateList(arr) { return (arr || []).map(normalizeExercise); }

  function loadLists() {
    // try current format first, then fall back through older formats so
    // nothing you already saved gets lost.
    const keysToTry = [LISTS_KEY, ...LEGACY_LISTS_KEYS];
    for (const key of keysToTry) {
      try {
        const raw = localStorage.getItem(key);
        if (!raw) continue;
        const parsed = JSON.parse(raw);
        if (parsed && parsed.categories && parsed.exercises) {
          const categories = parsed.categories.filter(c => c !== LEGACY_MAIN_CATEGORY);
          const exerciseLists = {};
          categories.forEach(c => {
            exerciseLists[c] = migrateList(parsed.exercises[c]);
          });
          const categoryColors = parsed.colors || {};
          return { categories, exerciseLists, categoryColors };
        }
      } catch (e) { /* try next key */ }
    }
    const categories = Object.keys(DEFAULT_EXERCISE_LISTS);
    const exerciseLists = {};
    categories.forEach(c => { exerciseLists[c] = migrateList(DEFAULT_EXERCISE_LISTS[c]); });
    return { categories, exerciseLists, categoryColors: {} };
  }

  function saveLists() {
    lsSet(LISTS_KEY, JSON.stringify({ categories, exercises: exerciseLists, colors: categoryColors }));
  }

  let { categories, exerciseLists, categoryColors } = loadLists();
  let active = categories[0];

  // ---- Blocks: named groupings (e.g. "Day A") that can pull exercises from
  // any category. Unlike Main workout (a single fixed aggregator), you can
  // have any number of blocks. A block owns no exercises itself, only
  // { name, refCategory } pointers, resolved the same way Main workout's are.
  const BLOCKS_KEY = "workout-log-blocks-v1";
  function loadBlocks() {
    try {
      const raw = localStorage.getItem(BLOCKS_KEY);
      if (raw) {
        const parsed = JSON.parse(raw);
        if (parsed && Array.isArray(parsed.blocks) && parsed.blockRefs) {
          return { blocks: parsed.blocks, blockRefs: parsed.blockRefs, hiddenBlocks: Array.isArray(parsed.hiddenBlocks) ? parsed.hiddenBlocks : [], planBlocks: Array.isArray(parsed.planBlocks) ? parsed.planBlocks : [] };
        }
      }
    } catch (e) { /* ignore */ }
    return { blocks: [], blockRefs: {}, hiddenBlocks: [], planBlocks: [] };
  }
  function saveBlocks() { lsSet(BLOCKS_KEY, JSON.stringify({ blocks, blockRefs, hiddenBlocks, planBlocks })); }
  // planBlocks: the blocks created by starting a plan from My program (shown under "Plans" in the block picker)
  let { blocks, blockRefs, hiddenBlocks, planBlocks } = loadBlocks();
  // plan progress: which plan day each plan block is, and the sessions logged per plan (for "Week 2 of 6, Day B")
  const PLANMETA_KEY = 'workout-log-planmeta-v1', PLANPROG_KEY = 'workout-log-planprogress-v1';
  function loadObj(key) { try { const o = JSON.parse(localStorage.getItem(key)); if (o && typeof o === 'object' && !Array.isArray(o)) return o; } catch (e) { /* none yet */ } return {}; }
  let planMeta = loadObj(PLANMETA_KEY), planProgress = loadObj(PLANPROG_KEY);
  function savePlanMeta() { lsSet(PLANMETA_KEY, JSON.stringify(planMeta)); }
  function savePlanProgress() { lsSet(PLANPROG_KEY, JSON.stringify(planProgress)); }
  // exercises removed on this device (merged away or deleted), so sync does not bring them back; keyed by lower-case name
  const REMOVEDEX_KEY = 'workout-log-removedex-v1';
  let removedExercises = loadObj(REMOVEDEX_KEY);
  function saveRemovedEx() { lsSet(REMOVEDEX_KEY, JSON.stringify(removedExercises)); }
  function markExerciseRemoved(name) { if (!name) return; removedExercises[String(name).toLowerCase()] = Date.now(); saveRemovedEx(); }
  // true when the exercise is older than its removal (an exercise created again afterwards is kept)
  function exRemovedAfter(ex) { const ts = removedExercises[String((ex && ex.name) || '').toLowerCase()]; return !!ts && (ex.createdAt || 0) < ts; }
  let activeBlock = null; // name of the block currently filtering the exercise grid, or null for "no block"
  let bulkQuiet = false; // true while several items are deleted at once (one confirmation for the lot)

  // ---- Equipment: a small user-editable tag list (bar/rings/parallettes/...) attachable to any logged entry ----
  const EQUIPMENT_KEY = "workout-log-equipment-v1";
  const DEFAULT_EQUIPMENT = ["Bar", "Rings", "Parallettes", "Floor", "Wall"];
  function loadEquipment() {
    try {
      const raw = localStorage.getItem(EQUIPMENT_KEY);
      if (raw) {
        const parsed = JSON.parse(raw);
        if (parsed && Array.isArray(parsed.equipment)) {
          return { equipmentList: parsed.equipment, equipmentColors: parsed.colors || {} };
        }
      }
    } catch (e) { /* ignore */ }
    return { equipmentList: DEFAULT_EQUIPMENT.slice(), equipmentColors: {} };
  }
  function saveEquipment() { lsSet(EQUIPMENT_KEY, JSON.stringify({ equipment: equipmentList, colors: equipmentColors })); }
  let { equipmentList, equipmentColors } = loadEquipment();
  function getEquipmentColor(name) {
    if (!equipmentColors[name]) {
      const used = Object.keys(equipmentColors).length;
      equipmentColors[name] = COLOR_PALETTE[used % COLOR_PALETTE.length];
      saveEquipment();
    }
    return equipmentColors[name];
  }

  // ---- Bodyweight log: dated weigh-ins, stored in kg. The graph page reads this
  // to work out strength relative to bodyweight and to plot it against strength. ----
  const BODYWEIGHT_KEY = "workout-log-bodyweight-v1";
  function loadBodyweight() {
    try {
      const raw = localStorage.getItem(BODYWEIGHT_KEY);
      if (raw) {
        const parsed = JSON.parse(raw);
        if (Array.isArray(parsed)) return parsed.filter(e => e && /^\d{4}-\d{2}-\d{2}$/.test(e.date) && Number(e.kg) > 0);
      }
    } catch (e) { /* ignore */ }
    return [];
  }
  function saveBodyweight() { lsSet(BODYWEIGHT_KEY, JSON.stringify(bodyweightLog)); }
  let bodyweightLog = loadBodyweight();

  // ---- Skill progressions: ordered checklists per skill. Stored as
  // [{ id, name, steps: [{ id, name, exercise|null, metric: 'hold'|'reps', target, sets, doneDate|null }] }] ----
  const SKILLS_KEY = "workout-log-skills-v1";
  function newSkillId() { return 's' + Date.now().toString(36) + Math.random().toString(36).slice(2, 7); }
  function cleanSkillStep(st) {
    if (!st || typeof st.name !== 'string' || !st.name.trim()) return null;
    const metric = st.metric === 'reps' ? 'reps' : 'hold';
    const target = Number(st.target);
    const sets = Math.round(Number(st.sets));
    return {
      id: (typeof st.id === 'string' && st.id) ? st.id : newSkillId(),
      name: st.name.trim(),
      exercise: (typeof st.exercise === 'string' && st.exercise) ? st.exercise : null,
      variation: (typeof st.variation === 'string' && st.variation) ? st.variation : null,
      metric,
      target: target > 0 ? target : (metric === 'hold' ? 20 : 5),
      sets: sets >= 1 ? Math.min(sets, 20) : 3,
      doneDate: (typeof st.doneDate === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(st.doneDate)) ? st.doneDate : null
    };
  }
  function cleanSkillLine(l) {
    if (!l || typeof l.name !== 'string' || !l.name.trim()) return null;
    return {
      id: (typeof l.id === 'string' && l.id) ? l.id : newSkillId(),
      name: l.name.trim(),
      steps: (Array.isArray(l.steps) ? l.steps : []).map(cleanSkillStep).filter(Boolean)
    };
  }
  function loadSkills() {
    try {
      const raw = localStorage.getItem(SKILLS_KEY);
      if (raw) { const arr = JSON.parse(raw); if (Array.isArray(arr)) return arr.map(cleanSkillLine).filter(Boolean); }
    } catch (e) { /* ignore */ }
    return [];
  }
  function saveSkills() { lsSet(SKILLS_KEY, JSON.stringify(skillLines)); }
  let skillLines = loadSkills();

  let selectedExercise = "";
  let sortMode = "ascending";
  let calViewDate = new Date();
  let selectedCalDate = null;
  let expandedWeeks = new Set();
  let lastEntriesMonthKey = null;
  let weeksNeedDefaultExpand = true;
  let data = {};
  categories.forEach(c => data[c] = []);
  let layout = JSON.parse(JSON.stringify(DEFAULT_LAYOUT));

  function findExerciseOwner(name) {
    for (const cat of categories) {
      const found = (exerciseLists[cat] || []).find(e => e.name === name);
      if (found) return { category: cat, exObj: found };
    }
    return null;
  }
  function resolveRefs(refs) {
    const resolved = [];
    (refs || []).forEach(ref => {
      let cat = ref.refCategory;
      let exObj = (exerciseLists[cat] || []).find(e => e.name === ref.name);
      if (!exObj) {
        // the exercise was moved to another category since the block was made: find it by name instead of dropping it
        cat = Object.keys(exerciseLists).find(c => (exerciseLists[c] || []).some(e => e.name === ref.name)) || null;
        if (cat) exObj = exerciseLists[cat].find(e => e.name === ref.name);
      }
      if (exObj && !resolved.some(r => r.exObj === exObj)) resolved.push({ exObj, originCategory: cat });
    });
    return resolved;
  }
  // For the active tab, returns [{ exObj, originCategory }]. When a block is
  // active it owns no exercises itself — it holds lightweight references
  // ({ name, refCategory }) resolved against their real home category.
  // Otherwise the active category tab just lists its own exercises.
  function getDisplayExerciseList() {
    if (activeBlock) return resolveRefs(blockRefs[activeBlock]);
    return (exerciseLists[active] || []).map(exObj => ({ exObj, originCategory: active }));
  }

  const catEditList = document.getElementById('catEditList');
  const newCatInput = document.getElementById('newCatInput');

  const exerciseGrid = document.getElementById('exerciseGrid');
  const exerciseText = document.getElementById('exerciseText');
  let lastExerciseTextValue = '';
  exerciseText.addEventListener('focus', () => { lastExerciseTextValue = exerciseText.value; });
  exerciseText.addEventListener('change', () => {
    const newVal = exerciseText.value;
    if (newVal !== lastExerciseTextValue) switchExerciseInputs(lastExerciseTextValue, newVal);
    lastExerciseTextValue = newVal;
  });
  const exEditBtn = document.getElementById('editExBtn');
  const exEditPanel = document.getElementById('exEditPanel');
  const exEditList = document.getElementById('exEditList');
  const newExInput = document.getElementById('newExInput');
  const newExColor = document.getElementById('newExColor');
  const newExIsoBtn = document.getElementById('newExIsoBtn');
  const newExUniBtn = document.getElementById('newExUniBtn');
  const sortToggleBtn = document.getElementById('sortToggleBtn');

  const modifiersRow = document.getElementById('modifiersRow');
  const setsGrid = document.getElementById('setsGrid');
  const attemptsGrid = document.getElementById('attemptsGrid');
  const distanceRow = document.getElementById('distanceRow');
  const distanceInput = document.getElementById('distanceInput');
  const metricsLabel = document.getElementById('metricsLabel');
  const entriesEl = document.getElementById('entries');
  const dateInput = document.getElementById('dateInput');
  const headerDateBtn = document.getElementById('headerDateBtn');
  const notesInput = document.getElementById('notesInput');
  const errEl = document.getElementById('err');
  const toastEl = document.getElementById('toast');
  const calTitle = document.getElementById('calTitle');
  const calGrid = document.getElementById('calGrid');

  dateInput.valueAsDate = new Date();

  function updateHeaderDateDisplay() {
    if (!dateInput.value) { headerDateBtn.textContent = ''; return; }
    const d = new Date(dateInput.value + 'T00:00:00');
    if (isNaN(d.getTime())) { headerDateBtn.textContent = ''; return; }
    const month = d.toLocaleDateString(undefined, { month: 'short' });
    const day = String(d.getDate()).padStart(2, '0');
    headerDateBtn.innerHTML = `<i class="fa-solid fa-calendar-day" aria-hidden="true"></i> ${month} ${day}`;
    dateInput.style.width = headerDateBtn.offsetWidth + 'px';
  }
  headerDateBtn.onclick = () => {
    if (dateInput.showPicker) {
      try { dateInput.showPicker(); } catch (e) { dateInput.focus(); }
    } else {
      dateInput.focus();
    }
  };
  dateInput.addEventListener('change', updateHeaderDateDisplay);
  dateInput.addEventListener('change', () => { if (activeBlock) updateExercisePicker(); });

  // ---- Superset (group several exercises logged back-to-back) ----
  let activeSuperset = null; // { id, date, count } or null when not actively grouping
  // Exercises picked for the running superset (shown accented). Adding more than one records all of them at once.
  let supersetMembers = new Set();
  function supersetMemberNames() {
    return activeSuperset ? sortedExerciseList().map(p => p.exObj.name).filter(n => supersetMembers.has(n)) : [];
  }
  function updateSupersetUI() {
    if (!activeSuperset) supersetMembers.clear();
    const btn = document.getElementById('supersetToggleBtn');
    if (activeSuperset) {
      btn.classList.add('on');
      const picked = supersetMembers.size;
      btn.innerHTML = `<i class="fa-solid fa-link-slash" aria-hidden="true"></i> <span class="pill-full">${picked ? picked + ' selected · ' : ''}${activeSuperset.count} logged · End</span><span class="pill-short">End${picked ? ' (' + picked + ')' : ''}</span>`;
      btn.title = 'Tap to end superset. Tap exercises to add or remove them; Add logs every selected exercise that has values.';
    } else {
      btn.classList.remove('on');
      btn.innerHTML = '<i class="fa-solid fa-link" aria-hidden="true"></i> Superset';
      btn.title = 'Superset: group exercises logged together';
    }
    btn.setAttribute('aria-label', btn.title);
  }
  document.getElementById('supersetToggleBtn').onclick = () => {
    activeSuperset = activeSuperset
      ? null
      : { id: 'ss' + Date.now().toString(36) + Math.random().toString(36).slice(2, 6), date: dateInput.value, count: 0 };
    supersetMembers.clear();
    if (activeSuperset && selectedExercise) supersetMembers.add(selectedExercise); // the exercise you're on joins first
    updateSupersetUI();
    updateExercisePicker();
  };
  // switching the day mid-superset almost always means you meant to stop grouping
  dateInput.addEventListener('change', () => {
    if (activeSuperset && dateInput.value !== activeSuperset.date) {
      activeSuperset = null;
      updateSupersetUI();
      updateExercisePicker();
    }
  });
  updateHeaderDateDisplay();

  let exEditMode = false;
  let newExIsometric = false;
  let newExUnilateral = false;

  const DISTANCE_CATEGORY_PATTERN = Shared.DISTANCE_CATEGORY_PATTERN;
  function isDistanceCategoryName(cat) { return Shared.isDistanceCategoryName(cat); }
  // Resolves which real category an exercise lives in, regardless of what's
  // currently active (search results and blocks can point at any category).
  function exerciseCategoryFor(name) {
    for (const cat of categories) {
      if ((exerciseLists[cat] || []).some(e => e.name === name)) return cat;
    }
    return active;
  }
  function isDistanceExercise(name) {
    // Recognize by the exercise's own name too (e.g. "Running" or "Walking" filed
    // under a non-distance category like "Legs"), not just by category name.
    return isDistanceCategoryName(exerciseCategoryFor(name)) || DISTANCE_CATEGORY_PATTERN.test(name || '');
  }
  function findActiveExerciseObj(name) {
    if (activeBlock) {
      const owner = findExerciseOwner(name);
      return owner ? owner.exObj : null;
    }
    return (exerciseLists[active] || []).find(e => e.name === name) || null;
  }
  function isIsometricExercise(name) {
    const obj = findActiveExerciseObj(name);
    if (obj) return !!obj.isometric;
    return false;
  }
  // Weighted can go negative to represent band/machine assistance (e.g. -15kg),
  // on the same continuum as added weight (e.g. +10kg), for the same exercise.
  function formatLoadKg(kg) {
    if (kg === null || kg === undefined || kg === '' || Number(kg) === 0) return '';
    const n = round2(kgToDisplay(Number(kg)));
    return (n > 0 ? '+' : 'banded ') + n + weightUnitLabel();
  }
  // Load metrics for one set that has added weight: volume = kg x reps, and an estimated 1RM
  // (shared formula, see workout-shared.js: Epley on bodyweight + added load, trusted for 1-12 reps).
  // Added weight only; assistance (negative) loads and plain bodyweight sets return null.
  // bwKg is your bodyweight on the day of the set (0 when no weigh-in is logged yet).
  function setLoadMetrics(s, bwKg) {
    if (!s || typeof s !== 'object' || s.formBroke || s.kg == null || s.kg === '') return null;
    const kg = Number(s.kg), reps = Shared.setReps(s);
    if (isNaN(kg) || kg <= 0 || !(reps > 0)) return null;
    return { volume: kg * reps, e1rm: Shared.est1rmAdded(bwKg || 0, kg, reps) };
  }
  function sortedBodyweightLog() { return bodyweightLog.slice().sort((a, b) => String(a.date).localeCompare(String(b.date))); }
  function bodyweightKgOnDate(sorted, date) { const b = Shared.bodyweightKgOn(sorted, date); return b ? b.kg : 0; }
  // Scans every logged entry for this exercise and returns the best-ever value along
  // each dimension that applies to it: isometric hold, reps, added weight (heaviest,
  // negative/assistance loads never count as a PR here), and — for distance exercises —
  // longest distance, longest time, most elevation, and fastest pace (lower is better).
  // varKey: undefined = count every set; otherwise only sets with that variation ('' = no variation).
  function entryKey(e) { return String(e.date || '') + '|' + String(e.id || '').padStart(20, '0'); }
  function computeExerciseBests(name, varKey, cutoffKey) {
    const bwSorted = sortedBodyweightLog();
    let bestHold = null, bestReps = null, bestWeight = null, bestE1RM = null, bestSetVolume = null;
    let bestDistance = null, bestTime = null, bestElevation = null, bestPaceMinPerKm = null;
    categories.forEach(cat => {
      (data[cat] || []).forEach(e => {
        if (e.exercise !== name) return;
        if (cutoffKey && entryKey(e) >= cutoffKey) return; // only what came before this entry
        if (e.distance != null && varKey !== undefined && (e.variation || '') !== varKey) return; // runs: bests per variation
        if (e.distance != null && e.distance > 0 && (bestDistance === null || e.distance > bestDistance)) bestDistance = e.distance;
        if (e.timeMinutes != null && e.timeMinutes > 0 && (bestTime === null || e.timeMinutes > bestTime)) bestTime = e.timeMinutes;
        if (e.elevation != null && e.elevation > 0 && (bestElevation === null || e.elevation > bestElevation)) bestElevation = e.elevation;
        if (e.distance != null && e.distance > 0 && e.timeMinutes != null && e.timeMinutes > 0) {
          const pace = e.timeMinutes / e.distance; // minutes per km, unaffected by display-unit setting
          if (bestPaceMinPerKm === null || pace < bestPaceMinPerKm) bestPaceMinPerKm = pace;
        }
        (e.sets || []).filter(s => varKey === undefined || setVar(s) === varKey).forEach(s => {
          if (e.isometric) {
            const hold = Shared.cleanReps(s);
            if (hold > 0 && (bestHold === null || hold > bestHold)) bestHold = hold;
          } else {
            const reps = Shared.cleanReps(s);
            if (reps > 0 && (bestReps === null || reps > bestReps)) bestReps = reps;
          }
          if (s && typeof s === 'object' && s.kg != null && s.kg !== '') {
            const kg = Number(s.kg);
            if (!isNaN(kg) && kg > 0 && (bestWeight === null || kg > bestWeight)) bestWeight = kg;
          }
          if (!e.isometric) {
            const load = setLoadMetrics(s, bodyweightKgOnDate(bwSorted, e.date));
            if (load) {
              if (bestSetVolume === null || load.volume > bestSetVolume) bestSetVolume = load.volume;
              if (load.e1rm !== null && (bestE1RM === null || load.e1rm > bestE1RM)) bestE1RM = load.e1rm;
            }
          }
        });
        if (e.isometric && (varKey === undefined || varKey === '')) {
          (e.attempts || []).forEach(a => {
            const v = Number(a);
            if (!isNaN(v) && v > 0 && (bestHold === null || v > bestHold)) bestHold = v;
          });
        }
      });
    });
    return { bestHold, bestReps, bestWeight, bestE1RM, bestSetVolume, bestDistance, bestTime, bestElevation, bestPaceMinPerKm };
  }
  function isUnilateralExercise(name) {
    const obj = findActiveExerciseObj(name);
    if (obj) return !!obj.unilateral;
    // legacy fallback for free-text categories with no stored exercise object
    return PER_LEG_EXERCISES.includes((name || '').trim().toLowerCase());
  }
  function hasLeverageTag(name) {
    const obj = findActiveExerciseObj(name);
    return !!(obj && obj.hasLeverage);
  }
  let lastToastMs = 2000, toastTimer = null;
  function showToast(msg) {
    lastToastMs = Math.min(5000, Math.max(2000, String(msg).length * 40));
    toastEl.textContent = msg;
    toastEl.classList.add('show');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => toastEl.classList.remove('show'), lastToastMs);
  }
  function getCategoryColor(cat) {
    if (!categoryColors[cat]) {
      const used = Object.keys(categoryColors).length;
      categoryColors[cat] = COLOR_PALETTE[used % COLOR_PALETTE.length];
      saveLists();
    }
    return categoryColors[cat];
  }
  function ensureExerciseColor(cat, exObj) {
    if (exObj.color) return exObj.color;
    const list = exerciseLists[cat] || [];
    const colored = list.filter(e => e.color).length;
    exObj.color = EX_COLOR_PALETTE[colored % EX_COLOR_PALETTE.length];
    return exObj.color;
  }

  // ---- build the set inputs (reps/hold seconds + eccentric seconds + kg add-on, cascading fill) ----
  // Every set stays visible, each prefixed with its (numeric) set number.
  // "Add set" grows numSets (up to MAX_SETS) and appends the new one below the rest.
  let eccEdited = [];
  let equipEdited = [];
  let varEdited = [];
  let kgEdited = [];
  let setsScrollOffset = 0;
  const SETS_WINDOW = 4;
  // Unilateral sets (reps or holds): a value typed for one side is copied to the other side until that
  // other side is changed by hand. Works whichever side you fill first.
  function wireSideMirror(a, b) {
    [[a, b], [b, a]].forEach(([src, dst]) => {
      src.addEventListener('focus', () => { src.dataset.last = src.value; });
      src.addEventListener('input', () => {
        const before = src.dataset.last === undefined ? '' : src.dataset.last;
        if (dst.value === '' || (dst.dataset.mirrored === '1' && dst.value === before)) {
          dst.value = src.value;
          dst.dataset.mirrored = '1';
        }
        src.dataset.mirrored = ''; // typed by hand, so it no longer follows the other side
        src.dataset.last = src.value;
      });
    });
  }
  function buildSetsGrid() {
    // Preserve anything already typed before rebuilding.
    const prev = {};
    setsGrid.querySelectorAll('input, select').forEach(inp => { prev[inp.id] = inp.value; });
    setsGrid.innerHTML = '';
    eccEdited = new Array(numSets + 1).fill(false);
    kgEdited = new Array(numSets + 1).fill(false);
    equipEdited = new Array(numSets + 1).fill(false);
    varEdited = new Array(numSets + 1).fill(false);
    for (let i = 1; i <= numSets; i++) {
      const col = document.createElement('div');
      col.className = 'set-col';
      col.innerHTML = `
        <div class="set-num" aria-hidden="true">${i}</div>
        <div class="set-body">${i > 1 ? `<div class="chain-between"><button type="button" class="chain-pill" id="chainBtn${i}" aria-pressed="false" title="Count this set as one continuous rep with the previous set"><i class="fa-solid fa-link" aria-hidden="true"></i> Chained to previous</button><input type="hidden" id="chain${i}" /></div>` : ''}<div class="set-row"><div class="set-field set-field-reps">
          <label for="set${i}">Reps</label>
          <input type="number" min="1" id="set${i}" placeholder="reps" />
          <div class="lr-row hidden" id="lr${i}">
            <input type="number" min="1" id="left${i}" placeholder="L" />
            <input type="number" min="1" id="right${i}" placeholder="R" />
          </div>
        </div>
        <div class="set-field ecc-field">
          <label for="ecc${i}">Eccentric</label>
          <input type="number" min="0" id="ecc${i}" placeholder="sec" class="ecc-input" />
        </div>
        <div class="set-field">
          <label for="kg${i}">Weight ±</label>
          <input type="number" step="0.5" id="kg${i}" placeholder="±${weightUnitLabel()}" class="kg-input" />
        </div>
        <div class="set-field angle-field hidden">
          <label for="angle${i}">Angle/leverage</label>
          <input type="text" id="angle${i}" placeholder="e.g. 15° or tuck" class="angle-input" />
        </div>
        </div><div class="set-row set-row-sub">
        <div class="set-field variation-field hidden">
          <select id="var${i}" class="equip-select var-select" required aria-label="Variation for set ${i}"></select>
        </div>
        <div class="set-field equip-field">
          <select id="equip${i}" class="equip-select" required aria-label="Equipment for set ${i}"></select>
        </div></div><div class="set-row set-row-flags">
          <div class="set-field"><select id="rpe${i}" class="equip-select" required aria-label="RPE for set ${i}"><option value="">RPE</option><option value="5">5</option><option value="6">6</option><option value="7">7</option><option value="8">8</option><option value="9">9</option><option value="10">10</option></select></div>
          <div class="set-field"><select id="flag${i}" class="equip-select" required aria-label="Flag for set ${i}"><option value="">Flag</option><option value="broke">Form broke</option><option value="pain">Pain</option><option value="both">Pain + form broke</option></select></div>
        </div></div>`;
      setsGrid.appendChild(col);
      // a set that didn't exist before (Add set) starts with the previous set's equipment
      const equipStart = prev['equip' + i] !== undefined ? prev['equip' + i] : (i > 1 ? document.getElementById('equip' + (i - 1)).value : '');
      fillEquipSelect(document.getElementById('equip' + i), equipStart);
      // same for the variation: a new set starts with the previous set's variation
      const varStart = prev['var' + i] !== undefined ? prev['var' + i] : (i > 1 ? document.getElementById('var' + (i - 1)).value : '');
      fillVarSelect(document.getElementById('var' + i), varStart);
      document.getElementById('set' + i).value = prev['set' + i] || '';
      document.getElementById('left' + i).value = prev['left' + i] || '';
      document.getElementById('right' + i).value = prev['right' + i] || '';
      document.getElementById('ecc' + i).value = prev['ecc' + i] || '';
      document.getElementById('kg' + i).value = prev['kg' + i] || '';
      document.getElementById('angle' + i).value = prev['angle' + i] || '';
      document.getElementById('rpe' + i).value = prev['rpe' + i] || '';
      document.getElementById('flag' + i).value = prev['flag' + i] || '';
      { const ch = document.getElementById('chain' + i); if (ch) ch.value = prev['chain' + i] || ''; }
    }
    for (let i = 1; i <= numSets; i++) {
      document.getElementById('ecc' + i).addEventListener('input', () => onEccInput(i));
      document.getElementById('kg' + i).addEventListener('input', () => onKgInput(i));
      document.getElementById('equip' + i).addEventListener('change', () => onEquipInput(i));
      document.getElementById('var' + i).addEventListener('change', () => onVarInput(i));
      wireSideMirror(document.getElementById('left' + i), document.getElementById('right' + i));
    }
    syncChainPills();
    updateMetricsSection(currentExerciseName());
    renderAddSetBtn();
    applySetsScrollWindow();
  }
  // the "Chained to previous" pill above sets 2 and up; its state lives in a hidden field so drafts, clearing and removing sets keep working
  function syncChainPills() {
    for (let i = 2; i <= numSets; i++) {
      const v = document.getElementById('chain' + i), b = document.getElementById('chainBtn' + i);
      if (!v || !b) continue;
      const on = v.value === '1';
      b.classList.toggle('on', on); b.setAttribute('aria-pressed', String(on));
    }
  }
  setsGrid.addEventListener('click', (e) => {
    const b = e.target.closest('.chain-pill'); if (!b) return;
    const v = document.getElementById('chain' + b.id.replace('chainBtn', ''));
    if (v) { v.value = v.value === '1' ? '' : '1'; syncChainPills(); }
  });
  function applySetsScrollWindow() {
    const maxOffset = Math.max(0, numSets - SETS_WINDOW);
    if (setsScrollOffset > maxOffset) setsScrollOffset = maxOffset;
    if (setsScrollOffset < 0) setsScrollOffset = 0;
    Array.from(setsGrid.children).forEach((col, idx) => {
      col.classList.toggle('hidden', idx < setsScrollOffset || idx >= setsScrollOffset + SETS_WINDOW);
    });
    const firstShown = Array.from(setsGrid.children).find(c => !c.classList.contains('hidden'));
    Array.from(setsGrid.children).forEach(c => c.classList.toggle('first-visible', c === firstShown)); // field labels only above the first visible set
    const upBtn = document.getElementById('setsScrollUpBtn');
    const downBtn = document.getElementById('setsScrollDownBtn');
    const scrollable = numSets > SETS_WINDOW;
    upBtn.classList.toggle('hidden', !scrollable);
    downBtn.classList.toggle('hidden', !scrollable);
    upBtn.disabled = setsScrollOffset <= 0;
    downBtn.disabled = setsScrollOffset >= maxOffset;
  }
  document.getElementById('setsScrollUpBtn').onclick = () => {
    setsScrollOffset = Math.max(0, setsScrollOffset - 1);
    applySetsScrollWindow();
  };
  document.getElementById('setsScrollDownBtn').onclick = () => {
    setsScrollOffset = Math.min(Math.max(0, numSets - SETS_WINDOW), setsScrollOffset + 1);
    applySetsScrollWindow();
  };
  function renderAddSetBtn() {
    const addSetBtn = document.getElementById('addSetBtn');
    const removeSetBtn = document.getElementById('removeSetBtn');
    const atMax = numSets >= MAX_SETS;
    const atMin = numSets <= MIN_SETS;
    addSetBtn.disabled = atMax;
    addSetBtn.classList.toggle('hidden', atMax);
    removeSetBtn.disabled = atMin;
  }
  function removeSet(idx) {
    if (numSets <= MIN_SETS) return;
    // Shift every later set's values up into this one, then drop the last slot.
    for (let j = idx; j < numSets; j++) {
      ['set', 'left', 'right', 'ecc', 'kg', 'angle', 'equip', 'var', 'rpe', 'flag', 'chain'].forEach(prefix => {
        const from = document.getElementById(prefix + (j + 1));
        const to = document.getElementById(prefix + j);
        if (from && to) to.value = from.value;
      });
    }
    numSets--;
    resetEccCascade();
    resetKgCascade();
    resetEquipCascade();
    buildSetsGrid();
  }

  // ---- Attempts (quick hold tries for isometric skills — a separate, lighter log than a working set) ----
  let holdMode = 'sets'; // 'sets' | 'attempts' — only meaningful for isometric exercises
  const DEFAULT_NUM_ATTEMPTS = 3;
  let numAttempts = DEFAULT_NUM_ATTEMPTS;
  let attemptsScrollOffset = 0;
  function buildAttemptsGrid() {
    const prev = {};
    attemptsGrid.querySelectorAll('input[type="number"]').forEach(inp => { prev[inp.id] = inp.value; });
    attemptsGrid.innerHTML = '';
    for (let i = 1; i <= numAttempts; i++) {
      const col = document.createElement('div');
      col.className = 'set-col';
      col.innerHTML = `
        <div class="set-num" aria-hidden="true">${i}</div>
        <div class="set-field">
          <label for="attempt${i}">Attempt</label>
          <input type="number" min="0" id="attempt${i}" placeholder="sec" />
        </div>`;
      attemptsGrid.appendChild(col);
      document.getElementById('attempt' + i).value = prev['attempt' + i] || '';
    }
    renderAttemptBtns();
    applyAttemptsScrollWindow();
  }
  function applyAttemptsScrollWindow() {
    const maxOffset = Math.max(0, numAttempts - SETS_WINDOW);
    if (attemptsScrollOffset > maxOffset) attemptsScrollOffset = maxOffset;
    if (attemptsScrollOffset < 0) attemptsScrollOffset = 0;
    Array.from(attemptsGrid.children).forEach((col, idx) => {
      col.classList.toggle('hidden', idx < attemptsScrollOffset || idx >= attemptsScrollOffset + SETS_WINDOW);
    });
    const firstShownA = Array.from(attemptsGrid.children).find(c => !c.classList.contains('hidden'));
    Array.from(attemptsGrid.children).forEach(c => c.classList.toggle('first-visible', c === firstShownA));
    const upBtn = document.getElementById('attemptsScrollUpBtn');
    const downBtn = document.getElementById('attemptsScrollDownBtn');
    const scrollable = numAttempts > SETS_WINDOW;
    upBtn.classList.toggle('hidden', !scrollable);
    downBtn.classList.toggle('hidden', !scrollable);
    upBtn.disabled = attemptsScrollOffset <= 0;
    downBtn.disabled = attemptsScrollOffset >= maxOffset;
  }
  document.getElementById('attemptsScrollUpBtn').onclick = () => {
    attemptsScrollOffset = Math.max(0, attemptsScrollOffset - 1);
    applyAttemptsScrollWindow();
  };
  document.getElementById('attemptsScrollDownBtn').onclick = () => {
    attemptsScrollOffset = Math.min(Math.max(0, numAttempts - SETS_WINDOW), attemptsScrollOffset + 1);
    applyAttemptsScrollWindow();
  };
  function renderAttemptBtns() {
    const addBtn = document.getElementById('addAttemptBtn');
    const removeBtn = document.getElementById('removeAttemptBtn');
    const atMax = numAttempts >= MAX_SETS;
    const atMin = numAttempts <= MIN_SETS;
    addBtn.disabled = atMax;
    addBtn.classList.toggle('hidden', atMax);
    removeBtn.disabled = atMin;
  }
  function clearAttemptInputs() {
    for (let i = 1; i <= numAttempts; i++) {
      const el = document.getElementById('attempt' + i);
      if (el) el.value = '';
    }
  }
  // Shared hard reset — blank slate, used after logging an entry (that exercise's
  // in-progress draft, if any, is now submitted and no longer needed).
  function resetLogInputs(opts) {
    opts = opts || {};
    clearSetInputs();
    numSets = 1;
    setsScrollOffset = 0;
    buildSetsGrid();
    clearAttemptInputs();
    numAttempts = DEFAULT_NUM_ATTEMPTS;
    attemptsScrollOffset = 0;
    buildAttemptsGrid();
    holdMode = 'sets';
    distanceInput.value = '';
    document.getElementById('ruckKgInput').value = '';
    document.getElementById('elevationInput').value = '';
    document.getElementById('timeInput').value = '';
    { const dv = document.getElementById('distVarSelect'); if (dv) dv.value = ''; }
    notesInput.value = '';
  }
  // Per-exercise scratch pad for not-yet-logged values, so switching between
  // exercises (as when alternating through a superset) never bleeds one
  // exercise's typed values into another's, and switching back restores
  // exactly what you'd typed before you left.
  let exerciseDrafts = {};
  function snapshotDraft(name) {
    if (!name) return;
    const setsValues = {};
    setsGrid.querySelectorAll('input, select').forEach(inp => { setsValues[inp.id] = inp.value; });
    const attemptsValues = {};
    attemptsGrid.querySelectorAll('input[type="number"]').forEach(inp => { attemptsValues[inp.id] = inp.value; });
    exerciseDrafts[name] = {
      numSets, numAttempts, holdMode, setsScrollOffset, attemptsScrollOffset,
      setsValues, attemptsValues,
      notes: notesInput.value,
      distance: distanceInput.value,
      ruckKg: document.getElementById('ruckKgInput').value,
      elevation: document.getElementById('elevationInput').value,
      time: document.getElementById('timeInput').value,
      distVar: (document.getElementById('distVarSelect') || {}).value || ''
    };
  }
  // Equipment from the most recent entry of this exercise (its last set that has one), if you still have that equipment.
  function lastEquipmentFor(name) {
    let best = null;
    categories.forEach(cat => (data[cat] || []).forEach(e => {
      if (e.exercise !== name || !Array.isArray(e.sets)) return;
      const key = String(e.date || '') + '|' + String(e.id || '').padStart(20, '0');
      if (best === null || key > best.key) best = { key, e };
    }));
    if (!best) return null;
    const sets = best.e.sets.slice().reverse();
    const hit = sets.find(s => s && typeof s === 'object' && s.equipment);
    return hit && equipmentList.includes(hit.equipment) ? hit.equipment : null;
  }
  // Copies it into every set; the later sets keep following set 1 until one is changed by hand.
  function prefillEquipment(name) {
    const eq = lastEquipmentFor(name);
    if (!eq) return;
    for (let i = 1; i <= numSets; i++) {
      const sel = document.getElementById('equip' + i);
      if (sel) sel.value = eq;
    }
  }
  function restoreDraft(name) {
    const d = name ? exerciseDrafts[name] : null;
    if (!d) { resetLogInputs({ clearEquipment: true }); if (name) { prefillEquipment(name); prefillVariation(name); } return; }
    numSets = d.numSets;
    setsScrollOffset = d.setsScrollOffset || 0;
    buildSetsGrid();
    Object.keys(d.setsValues).forEach(id => { const el = document.getElementById(id); if (el) el.value = d.setsValues[id]; });
    numAttempts = d.numAttempts;
    attemptsScrollOffset = d.attemptsScrollOffset || 0;
    buildAttemptsGrid();
    Object.keys(d.attemptsValues).forEach(id => { const el = document.getElementById(id); if (el) el.value = d.attemptsValues[id]; });
    holdMode = d.holdMode || 'sets';
    notesInput.value = d.notes || '';
    distanceInput.value = d.distance || '';
    document.getElementById('ruckKgInput').value = d.ruckKg || '';
    document.getElementById('elevationInput').value = d.elevation || '';
    document.getElementById('timeInput').value = d.time || '';
    updateMetricsSection(name);
    { const dv = document.getElementById('distVarSelect'); if (dv && d.distVar) dv.value = d.distVar; }
  }
  // Call when the exercise selection changes: saves what was typed for the
  // exercise you're leaving, then brings back whatever you'd typed for the
  // one you're switching to (or a blank slate if you've never touched it).
  function switchExerciseInputs(prevName, newName) {
    snapshotDraft(prevName);
    restoreDraft(newName);
  }
  function readAttempts() {
    const vals = [];
    for (let i = 1; i <= numAttempts; i++) {
      const el = document.getElementById('attempt' + i);
      if (el && el.value !== '') vals.push(Number(el.value));
    }
    return vals;
  }
  document.getElementById('addAttemptBtn').onclick = () => {
    if (numAttempts >= MAX_SETS) return;
    numAttempts++;
    attemptsScrollOffset = Math.max(0, numAttempts - SETS_WINDOW); // scroll to reveal the new attempt
    buildAttemptsGrid();
    const el = document.getElementById('attempt' + numAttempts);
    if (el) el.focus();
  };
  document.getElementById('removeAttemptBtn').onclick = () => {
    if (numAttempts <= MIN_SETS) return;
    numAttempts--;
    buildAttemptsGrid();
  };
  // one pill toggle: off = working sets, on = attempts (isometric exercises only)
  document.getElementById('holdModeToggleBtn').onclick = () => {
    holdMode = (holdMode === 'attempts') ? 'sets' : 'attempts';
    updateMetricsSection(currentExerciseName());
  };

  function onEccInput(idx) {
    eccEdited[idx] = true;
    const val = document.getElementById('ecc' + idx).value;
    for (let j = idx + 1; j <= numSets; j++) {
      if (eccEdited[j]) break;
      document.getElementById('ecc' + j).value = val;
    }
  }
  function resetEccCascade() { eccEdited = new Array(numSets + 1).fill(false); }
  function onKgInput(idx) {
    kgEdited[idx] = true;
    const val = document.getElementById('kg' + idx).value;
    for (let j = idx + 1; j <= numSets; j++) {
      if (kgEdited[j]) break;
      document.getElementById('kg' + j).value = val;
    }
  }
  function resetKgCascade() { kgEdited = new Array(numSets + 1).fill(false); }
  function onEquipInput(idx) {
    equipEdited[idx] = true;
    const val = document.getElementById('equip' + idx).value;
    for (let j = idx + 1; j <= numSets; j++) {
      if (equipEdited[j]) break;
      document.getElementById('equip' + j).value = val;
    }
  }
  function resetEquipCascade() { equipEdited = new Array(numSets + 1).fill(false); }

  // ---- Variations (lever position, grip, tempo...): one exercise, many variations, chosen per set ----
  function setVar(s) { return (s && typeof s === 'object' && s.variation) ? String(s.variation) : ''; }
  // Your own list for the exercise wins; otherwise the list from workout-library.json (matched by name).
  function exerciseVariations(name) {
    const owner = findExerciseOwner(name);
    if (owner && Array.isArray(owner.exObj.variations) && owner.exObj.variations.length) return owner.exObj.variations;
    const lib = window.WorkoutLibrary && window.WorkoutLibrary.get();
    if (!lib || !Array.isArray(lib.variations)) return [];
    const key = exKey(name);
    const hit = lib.variations.find(v => exKey(v.exercise) === key);
    return hit ? hit.variations : [];
  }
  // Some variations are one-sided even when the exercise is not (Archer, Typewriter, one-arm): their sets take left/right values.
  function isOneSidedVariation(name, variation) {
    if (!variation) return false;
    const lib = window.WorkoutLibrary && window.WorkoutLibrary.get();
    const hit = lib && Array.isArray(lib.variations) ? lib.variations.find(v => exKey(v.exercise) === exKey(name)) : null;
    return !!(hit && Array.isArray(hit.oneSided) && hit.oneSided.includes(variation));
  }
  function setIsUni(name, i) {
    if (isUnilateralExercise(name)) return true;
    const v = document.getElementById('var' + i);
    return !!(v && isOneSidedVariation(name, v.value));
  }
  function fillVarSelect(sel, current) {
    if (!sel) return;
    const keep = current !== undefined ? current : sel.value;
    const list = exerciseVariations(currentExerciseName());
    sel.innerHTML = '';
    const none = document.createElement('option');
    none.value = ''; none.textContent = 'Variation';
    sel.appendChild(none);
    const all = keep && !list.includes(keep) ? list.concat(keep) : list; // never drop a value that is already chosen
    all.forEach(v => { const o = document.createElement('option'); o.value = v; o.textContent = v; sel.appendChild(o); });
    sel.value = all.includes(keep) ? keep : '';
  }
  function onVarInput(idx) {
    varEdited[idx] = true;
    const val = document.getElementById('var' + idx).value;
    for (let j = idx + 1; j <= numSets; j++) {
      if (varEdited[j]) break;
      document.getElementById('var' + j).value = val;
    }
    if (idx === 1) renderModifiers(); else updateMetricsSection(currentExerciseName()); // best-so-far tags and left/right fields follow the variation
  }
  function resetVarCascade() { varEdited = new Array(numSets + 1).fill(false); }
  // Variation from the most recent entry of this exercise (its last set that has one).
  function lastVariationFor(name) {
    let best = null;
    categories.forEach(cat => (data[cat] || []).forEach(e => {
      if (e.exercise !== name || !Array.isArray(e.sets)) return;
      const key = String(e.date || '') + '|' + String(e.id || '').padStart(20, '0');
      if (best === null || key > best.key) best = { key, e };
    }));
    if (!best) return null;
    const hit = best.e.sets.slice().reverse().find(s => setVar(s));
    return hit ? setVar(hit) : null;
  }
  // A started plan can name the variation for an exercise; otherwise use what you did last time.
  function prefillVariation(name) {
    const list = exerciseVariations(name);
    if (!list.length) return;
    let v = null;
    const refs = activeBlock ? (blockRefs[activeBlock] || []) : [];
    const ref = refs.find(r => r && r.name === name && r.variation);
    if (ref && list.includes(ref.variation)) v = ref.variation;
    if (!v) { const last = lastVariationFor(name); if (last && list.includes(last)) v = last; }
    if (!v) return;
    for (let i = 1; i <= numSets; i++) { const sel = document.getElementById('var' + i); if (sel) sel.value = v; }
  }
  // Which variation's bests to show: the one chosen on set 1 (undefined = this exercise has no variations).
  function bestVarKey(name) {
    if (!exerciseVariations(name).length) return undefined;
    const el = document.getElementById('var1');
    return el ? el.value : '';
  }
  function bestVarLabel(name, key) { return key === undefined ? '' : ` (${key || 'standard'})`; }
  document.getElementById('clearMetricsBtn').onclick = () => {
    clearSetInputs();
    distanceInput.value = '';
    document.getElementById('ruckKgInput').value = '';
    document.getElementById('elevationInput').value = '';
    document.getElementById('timeInput').value = '';
  };
  document.getElementById('addSetBtn').onclick = () => {
    if (numSets >= MAX_SETS) return;
    numSets++;
    setsScrollOffset = Math.max(0, numSets - SETS_WINDOW); // scroll to reveal the new set
    buildSetsGrid();
    focusRepsInput(numSets);
  };
  document.getElementById('removeSetBtn').onclick = () => {
    removeSet(numSets);
  };
  function focusRepsInput(idx) {
    const primary = document.getElementById('set' + idx);
    const left = document.getElementById('left' + idx);
    if (primary && !primary.classList.contains('hidden')) primary.focus();
    else if (left) left.focus();
  }

