  // ---- Exercise picker + sorting + edit (add / delete / recolor / reps-vs-isometric) ----
  function activeHasExerciseList() {
    return getDisplayExerciseList().length > 0;
  }
  function currentExerciseName() {
    return activeHasExerciseList() ? selectedExercise : exerciseText.value.trim();
  }

  function sortedExerciseList() {
    let list = getDisplayExerciseList();
    if (sortMode === 'alphabetical') list.sort((a, b) => a.exObj.name.localeCompare(b.exObj.name));
    return list;
  }

  // ---- Last time: what you did last on this exercise (and variation), shown as placeholder text and a line above the sets ----
  function shortDate(iso) { const d = new Date(iso + 'T00:00:00'); return isNaN(d) ? iso : d.toLocaleDateString(undefined, { month: 'short', day: 'numeric' }); }
  function lastSessionFor(name, variation) {
    let best = null;
    categories.forEach(cat => (data[cat] || []).forEach(e => {
      if (e.exercise !== name || !Array.isArray(e.sets)) return;
      const key = entryKey(e);
      if (best && key <= best.key) return;
      const sets = e.sets.filter(st => st && typeof st === 'object' && (variation === undefined || setVar(st) === variation));
      if (sets.length) best = { key, e, sets };
    }));
    return best;
  }
  function lastAttemptsFor(name) {
    let best = null;
    categories.forEach(cat => (data[cat] || []).forEach(e => {
      if (e.exercise !== name || !Array.isArray(e.attempts) || !e.attempts.length) return;
      const key = entryKey(e);
      if (!best || key > best.key) best = { key, e };
    }));
    return best ? best.e.attempts : null;
  }
  function lastDistanceFor(name, variation) {
    let best = null;
    categories.forEach(cat => (data[cat] || []).forEach(e => {
      if (e.exercise !== name || e.distance == null || (variation !== undefined && (e.variation || '') !== variation)) return;
      const key = entryKey(e);
      if (!best || key > best.key) best = { key, e };
    }));
    return best ? best.e : null;
  }
  function setBrief(st, iso) {
    const u = iso ? 's' : '';
    const val = st.left !== undefined ? `${st.left}/${st.right}${u}` : `${st.reps}${u}`;
    const kg = st.kg != null && st.kg !== '' && Number(st.kg) !== 0 ? ' ' + formatLoadKg(st.kg) : '';
    return val + kg;
  }
  function lastTimeText(name) {
    if (!name || !showLast) return '';
    if (isDistanceExercise(name)) {
      const dv = (document.getElementById('distVarSelect') || {}).value;
      const d = lastDistanceFor(name, dv || undefined);
      if (!d) return '';
      return `Last time (${shortDate(d.date)}): ${round2(kmToDisplay(d.distance))}${distanceUnitLabel()}` + (d.timeMinutes != null ? ' · ' + formatDuration(d.timeMinutes) : '');
    }
    if (isIsometricExercise(name) && holdMode === 'attempts') {
      const a = lastAttemptsFor(name);
      return a ? `Last attempts: ${a.join('s, ')}s` : '';
    }
    const hasVars = exerciseVariations(name).length > 0;
    const v = hasVars ? ((document.getElementById('var1') || {}).value || '') : undefined;
    const ses = lastSessionFor(name, v);
    if (!ses) return '';
    return `Last time (${shortDate(ses.e.date)})${v ? ' · ' + v : ''}: ` + ses.sets.map(st => setBrief(st, !!ses.e.isometric)).join(' · ');
  }
  function applyLastTimePlaceholders(name) {
    if (!name) return;
    if (!showLast) { resetEccPlaceholders(); return; }
    const hasVars = exerciseVariations(name).length > 0;
    const cache = {}, used = {};
    for (let i = 1; i <= numSets; i++) {
      const v = hasVars ? ((document.getElementById('var' + i) || {}).value || '') : undefined;
      const k = v === undefined ? '*' : v;
      if (!(k in cache)) cache[k] = lastSessionFor(name, v);
      const ses = cache[k];
      const ord = used[k] || 0; used[k] = ord + 1;
      if (!ses || !ses.sets.length) continue;
      const st = ses.sets[ord] || ses.sets[ses.sets.length - 1];
      const el = id => document.getElementById(id + i);
      const lr = el('lr');
      if (lr && !lr.classList.contains('hidden')) {
        el('left').placeholder = String(st.left !== undefined ? st.left : st.reps);
        el('right').placeholder = String(st.right !== undefined ? st.right : st.reps);
      } else if (el('set')) {
        el('set').placeholder = String(st.left !== undefined ? Math.min(Number(st.left) || 0, Number(st.right) || 0) : st.reps);
      }
      if (st.eccentric != null && el('ecc')) el('ecc').placeholder = String(st.eccentric);
      if (st.kg != null && st.kg !== '' && el('kg')) el('kg').placeholder = String(round2(kgToDisplay(Number(st.kg))));
    }
  }
  function fillDistVarSelect(name) {
    const sel = document.getElementById('distVarSelect'), row = document.getElementById('distVarRow');
    if (!sel || !row) return;
    const list = name ? exerciseVariations(name) : [];
    row.classList.toggle('hidden', !list.length);
    const keep = sel.value;
    sel.innerHTML = '<option value="">Variation</option>';
    list.forEach(v => { const o = document.createElement('option'); o.value = v; o.textContent = v; sel.appendChild(o); });
    sel.value = list.includes(keep) ? keep : '';
  }
  (function () { const sel = document.getElementById('distVarSelect'); if (sel) sel.addEventListener('change', () => renderModifiers()); })();
  function isSAName(name) { const o = findExerciseOwner(name); return Shared.isStraightArm(o && o.exObj, name); }
  function allEntriesFlat() { const out = []; categories.forEach(c => (data[c] || []).forEach(e => out.push(e))); return out; }
  function renderModifiers() {
    const name = currentExerciseName();
    modifiersRow.innerHTML = '';

    if (isUnilateralExercise(name)) {
      const tag = document.createElement('span');
      tag.className = 'modifier';
      tag.innerHTML = `<i class="fa-solid fa-arrows-up-down" aria-hidden="true"></i> Left/right values per set`;
      modifiersRow.appendChild(tag);
    }

    if (name && isDistanceExercise(name)) {
      const b = computeExerciseBests(name, exerciseVariations(name).length ? ((document.getElementById('distVarSelect') || {}).value || '') : undefined);
      const addTag = html => { const tag = document.createElement('span'); tag.className = 'modifier'; tag.innerHTML = html; modifiersRow.appendChild(tag); };
      if (b.bestDistance !== null) addTag(`<i class="fa-solid fa-trophy" aria-hidden="true"></i> Longest: ${round2(kmToDisplay(b.bestDistance))}${distanceUnitLabel()}`);
      if (b.bestTime !== null) addTag(`<i class="fa-solid fa-trophy" aria-hidden="true"></i> Longest time: ${formatDuration(b.bestTime)}`);
      if (b.bestElevation !== null) addTag(`<i class="fa-solid fa-trophy" aria-hidden="true"></i> Max elevation: ${round2(mToDisplay(b.bestElevation))}${elevationUnitLabel()}`);
      if (b.bestPaceMinPerKm !== null) addTag(`<i class="fa-solid fa-trophy" aria-hidden="true"></i> Best pace: ${formatPace(b.bestPaceMinPerKm)}/km`);
    } else if (name && isIsometricExercise(name)) {
      const vk = bestVarKey(name);
      const b = computeExerciseBests(name, vk);
      if (b.bestHold !== null) {
        const tag = document.createElement('span');
        tag.className = 'modifier';
        tag.innerHTML = `<i class="fa-solid fa-trophy" aria-hidden="true"></i> Best hold${bestVarLabel(name, vk)}: ${b.bestHold}s`;
        modifiersRow.appendChild(tag);
      }
    } else if (name) {
      const vk = bestVarKey(name);
      const b = computeExerciseBests(name, vk);
      const vl = bestVarLabel(name, vk);
      const addTag = html => { const tag = document.createElement('span'); tag.className = 'modifier'; tag.innerHTML = html; modifiersRow.appendChild(tag); };
      if (b.bestReps !== null) addTag(`<i class="fa-solid fa-trophy" aria-hidden="true"></i> Best reps${vl}: ${b.bestReps}`);
      if (b.bestWeight !== null) addTag(`<i class="fa-solid fa-trophy" aria-hidden="true"></i> Best weight${vl}: ${formatLoadKg(b.bestWeight)}`);
      if (b.bestE1RM !== null) addTag(`<i class="fa-solid fa-trophy" aria-hidden="true"></i> Est. 1RM${vl}: ${round2(kgToDisplay(b.bestE1RM))}${weightUnitLabel()}`);
    }

    const lastText = lastTimeText(name);
    if (lastText) {
      const tag = document.createElement('span');
      tag.className = 'modifier';
      tag.innerHTML = '<i class="fa-solid fa-clock-rotate-left" aria-hidden="true"></i> ';
      tag.appendChild(document.createTextNode(lastText));
      modifiersRow.appendChild(tag);
    }

    if (name && isSAName(name)) {
      const rep = Shared.straightArmReport(allEntriesFlat(), isSAName, weekStart, skillToday());
      const warn = rep.flags.find(f => f[0] === 'warn');
      if (warn) {
        const tag = document.createElement('span');
        tag.className = 'modifier';
        tag.innerHTML = '<i class="fa-solid fa-triangle-exclamation" aria-hidden="true"></i> ';
        tag.appendChild(document.createTextNode(warn[1].split('. ')[0] + '.'));
        modifiersRow.appendChild(tag);
      }
    }

    const skillHint = skillHintFor(name);
    if (skillHint) {
      const tag = document.createElement('span');
      tag.className = 'modifier';
      tag.innerHTML = '<i class="fa-solid fa-medal" aria-hidden="true"></i> ';
      tag.appendChild(document.createTextNode(skillHint));
      modifiersRow.appendChild(tag);
    }

    updateMetricsSection(name);
  }

  function updateMetricsSection(name) {
    syncChainPills();
    const holdModeToggleBtn = document.getElementById('holdModeToggleBtn');
    if (window.WorkoutApp && window.WorkoutApp.onMetricsUpdate) window.WorkoutApp.onMetricsUpdate({ isometric: !!name && isIsometricExercise(name) && !isDistanceExercise(name), distance: isDistanceExercise(name) });
    if (isDistanceExercise(name)) {
      metricsLabel.textContent = 'Distance, elevation & time';
      document.getElementById('setsWrap').classList.add('hidden');
      document.getElementById('attemptsWrap').classList.add('hidden');
      holdModeToggleBtn.classList.add('hidden');
      distanceRow.classList.remove('hidden');
      document.getElementById('distanceInputLabel').textContent = 'Distance (' + distanceUnitLabel().toUpperCase() + ')';
      document.getElementById('ruckKgInputLabel').textContent = 'Rucking (' + weightUnitLabel() + ')';
      document.getElementById('elevationInputLabel').textContent = 'Elevation (' + elevationUnitLabel() + ')';
      fillDistVarSelect(name);
      const dvSel = (document.getElementById('distVarSelect') || {}).value;
      const ld = name && showLast ? lastDistanceFor(name, dvSel || undefined) : null;
      if (name && !dvSel && ld && ld.variation && exerciseVariations(name).includes(ld.variation)) document.getElementById('distVarSelect').value = ld.variation;
      distanceInput.placeholder = ld && ld.distance != null ? String(round2(kmToDisplay(ld.distance))) : '0.0';
      document.getElementById('timeInput').placeholder = ld && ld.timeMinutes != null ? timeMinutesToInputString(ld.timeMinutes) : '0:00';
      document.getElementById('ruckKgInput').placeholder = ld && ld.ruckKg != null ? String(round2(kgToDisplay(ld.ruckKg))) : '0';
      document.getElementById('elevationInput').placeholder = ld && ld.elevation != null ? String(round2(mToDisplay(ld.elevation))) : '0';
      return;
    }
    distanceRow.classList.add('hidden');
    const isometric = isIsometricExercise(name);
    const unilateral = isUnilateralExercise(name);
    if (!isometric) holdMode = 'sets'; // attempts mode only makes sense for isometric holds
    holdModeToggleBtn.classList.toggle('hidden', !isometric);
    holdModeToggleBtn.classList.toggle('on', holdMode === 'attempts');
    holdModeToggleBtn.setAttribute('aria-pressed', String(holdMode === 'attempts'));

    const showAttempts = isometric && holdMode === 'attempts';
    document.getElementById('setsWrap').classList.toggle('hidden', showAttempts);
    document.getElementById('attemptsWrap').classList.toggle('hidden', !showAttempts);

    if (showAttempts) {
      metricsLabel.textContent = 'Attempts (sec)';
      const la = name && showLast ? lastAttemptsFor(name) : null;
      for (let i = 1; i <= numAttempts; i++) { const el = document.getElementById('attempt' + i); if (el) el.placeholder = la && la[i - 1] != null ? String(la[i - 1]) : 'sec'; }
      return;
    }

    const unit = isometric ? 'hold s' : 'reps';
    const leverage = hasLeverageTag(name);
    const labelParts = [(isometric ? 'Hold (sec)' : 'Reps') + (unilateral ? ' (L/R)' : '')];
    if (!isometric) labelParts.push('eccentric (sec)');
    labelParts.push('kg per set');
    if (leverage) labelParts.push('angle/leverage');
    metricsLabel.textContent = labelParts.join(' & ');
    setsGrid.querySelectorAll('.ecc-field').forEach(f => f.classList.toggle('hidden', isometric));
    setsGrid.querySelectorAll('.angle-field').forEach(f => f.classList.toggle('hidden', !leverage));
    const varList = exerciseVariations(name);
    setsGrid.querySelectorAll('.variation-field').forEach(f => f.classList.toggle('hidden', !varList.length));
    setsGrid.querySelectorAll('.var-select').forEach(sel => fillVarSelect(sel));
    for (let i = 1; i <= numSets; i++) {
      const primary = document.getElementById('set' + i);
      const lr = document.getElementById('lr' + i);
      const left = document.getElementById('left' + i);
      const right = document.getElementById('right' + i);
      const kgInput = document.getElementById('kg' + i);
      if (kgInput) kgInput.placeholder = '±' + weightUnitLabel();
      const primaryLabel = document.querySelector('label[for="set' + i + '"]');
      if (primaryLabel) primaryLabel.textContent = isometric ? 'Isometric' : 'Reps';
      if (!primary || !lr) continue;
      if (unilateral || setIsUni(name, i)) {
        primary.classList.add('hidden');
        lr.classList.remove('hidden');
        left.placeholder = 'L ' + unit;
        right.placeholder = 'R ' + unit;
      } else {
        primary.classList.remove('hidden');
        lr.classList.add('hidden');
        primary.placeholder = unit;
      }
    }
  applyLastTimePlaceholders(name);
  }

  let draggedExerciseName = null;
  function reorderExercise(draggedName, targetName) {
    // A block reorders its own reference list; every other tab reorders its real list.
    const arr = activeBlock ? blockRefs[activeBlock] : exerciseLists[active];
    if (!arr) return;
    const fromIdx = arr.findIndex(e => e.name === draggedName);
    const toIdx = arr.findIndex(e => e.name === targetName);
    if (fromIdx === -1 || toIdx === -1 || fromIdx === toIdx) return;
    const [moved] = arr.splice(fromIdx, 1);
    arr.splice(toIdx, 0, moved);
    if (sortMode !== 'ascending') {
      sortMode = 'ascending';
      renderSortToggle();
    }
    if (activeBlock) saveBlocks(); else saveLists();
    updateExercisePicker();
    showToast('Exercise order updated');
  }

  function targetText(ref) {
    if (!ref || !ref.target) return '';
    const t = String(ref.target).replace(/\s*reps?\b/i, '').trim();
    return ref.sets > 1 ? ref.sets + ' × ' + t : t;
  }
  function namesLoggedOn(date) {
    const set = new Set();
    categories.forEach(cat => (data[cat] || []).forEach(e => { if (e.date === date) set.add(e.exercise); }));
    return set;
  }
  function recordPlanSession(pm, date) {
    if (!pm.uid || !pm.weeks) return;
    const p = planProgress[pm.uid] || (planProgress[pm.uid] = { started: date, sessions: [] });
    const day = pm.dayIdx == null ? 0 : pm.dayIdx;
    if (p.sessions.some(x => x.date === date && x.day === day)) return;
    p.sessions.push({ date, day });
    p.sessions.sort((a, b) => a.date.localeCompare(b.date));
    p.started = p.sessions[0].date;
    savePlanProgress();
  }
  function renderPlanStrip() {
    const el = document.getElementById('planStrip');
    if (!el) return;
    const pm = activeBlock ? planMeta[activeBlock] : null;
    if (!pm || !planBlocks.includes(activeBlock)) { el.classList.add('hidden'); return; }
    const refs = blockRefs[activeBlock] || [];
    const date = dateInput.value;
    const done = namesLoggedOn(date);
    const doneCount = refs.filter(r => done.has(r.name)).length;
    const names = pm.dayNames || [];
    const dayName = pm.dayIdx != null && names[pm.dayIdx] ? names[pm.dayIdx] : '';
    let html = `<div class="plan-title">${escapeHtml(pm.name)}${dayName ? ' · ' + escapeHtml(dayName) : ''}</div>`;
    if (pm.weeks) {
      const p = planProgress[pm.uid] || { sessions: [] };
      const dpw = pm.dpw || names.length || 1, total = pm.weeks * dpw;
      const dayIdx = pm.dayIdx == null ? 0 : pm.dayIdx;
      const at = p.sessions.findIndex(x => x.date === date && x.day === dayIdx);
      const idx = at >= 0 ? at : p.sessions.length;
      if (idx >= total) {
        html += `<div class="plan-line">Programme complete (${p.sessions.length} sessions). Next: take a deload week, then move up a level.</div>`;
      } else {
        const week = Math.floor(idx / dpw) + 1;
        html += `<div class="plan-line">Week ${week} of ${pm.weeks} · session ${idx + 1} of ${total}</div>`;
        if (idx + 1 >= total) html += '<div class="plan-line">Next: this is the last session of the programme.</div>';
        else {
          const nextDay = names.length ? names[(dayIdx + 1) % names.length] : 'next session';
          const nextWeek = Math.floor((idx + 1) / dpw) + 1;
          html += `<div class="plan-line">Next: ${escapeHtml(nextDay)}${nextWeek > week ? ` · starts week ${nextWeek}, so apply the progression` : ''}</div>`;
        }
      }
    }
    if (refs.length) html += `<div class="plan-line">${doneCount} of ${refs.length} exercises done${doneCount === refs.length ? ' · session complete 🎉' : ''}</div>`;
    if (pm.progression) html += `<details class="plan-note"><summary>Progression</summary><p>${escapeHtml(pm.progression)}</p></details>`;
    el.innerHTML = html;
    el.classList.remove('hidden');
  }
  function updateExercisePicker() {
    const inBlock = !!activeBlock;
    const list = sortedExerciseList();
    if (!list.some(pair => pair.exObj.name === selectedExercise)) selectedExercise = "";
    exerciseGrid.innerHTML = '';
    if (list.length) {
      exerciseGrid.classList.remove('hidden');
      exerciseText.classList.add('hidden');
      let colorsAssigned = false;
      const pending = [];
      const doneNames = activeBlock ? namesLoggedOn(dateInput.value) : new Set();
      const planRefs = activeBlock ? (blockRefs[activeBlock] || []) : [];
      list.forEach(({ exObj, originCategory }) => {
        if (!exObj.color) colorsAssigned = true;
        ensureExerciseColor(originCategory, exObj);
        const ref = planRefs.find(r => r.name === exObj.name);
        const tgt = targetText(ref);
        const done = !!activeBlock && doneNames.has(exObj.name);
        const wrap = document.createElement('div');
        wrap.className = 'ex-btn-wrap';
        const b = document.createElement('button');
        b.className = 'ex-btn' + (exObj.name === selectedExercise ? ' selected' : '') + (activeSuperset && supersetMembers.has(exObj.name) ? ' ss-member' : '') + (done ? ' ex-done' : '');
        b.type = 'button';
        b.innerHTML = `${done ? '<i class="fa-solid fa-circle-check ex-done-ic" aria-hidden="true"></i>' : `<span class="dot" style="background:${exObj.color}"></span>`}<span>${escapeHtml(exObj.name)}</span>${tgt ? `<span class="iso-tag target-tag">${escapeHtml(tgt)}</span>` : ''}` +
          (isDistanceExercise(exObj.name)
            ? '<span class="iso-tag attr-tag">KM</span>'
            : (exObj.isometric ? '<span class="iso-tag attr-tag">ISO</span>' : '') +
              `<span class="iso-tag attr-tag${exObj.unilateral ? '' : ' attr-tag-muted'}">${exObj.unilateral ? 'UNI' : 'BI'}</span>` +
              (exObj.hasLeverage ? '<span class="iso-tag attr-tag">LEV</span>' : '')) +
          ((inBlock) ? `<span class="iso-tag origin-tag" style="background:${getCategoryColor(originCategory)}">${escapeHtml(originCategory)}</span>` : '');
        b.onclick = () => {
          if (exEditMode) return; // dragging takes over the click while editing
          const prevExercise = selectedExercise;
          if (activeSuperset) {
            // superset: tap to add an exercise (and edit it); tap the one you're on to drop it
            if (supersetMembers.has(exObj.name) && selectedExercise === exObj.name) { supersetMembers.delete(exObj.name); selectedExercise = ""; }
            else { supersetMembers.add(exObj.name); selectedExercise = exObj.name; }
          } else {
            selectedExercise = (selectedExercise === exObj.name) ? "" : exObj.name;
          }
          if (selectedExercise !== prevExercise) switchExerciseInputs(prevExercise, selectedExercise);
          updateExercisePicker();
          renderModifiers();
          if (activeSuperset) updateSupersetUI();
        };
        wrap.appendChild(b);
        if (exEditMode) {
          wrap.draggable = true;
          wrap.classList.add('draggable');
          wrap.ondragstart = (e) => {
            draggedExerciseName = exObj.name;
            wrap.classList.add('dragging');
            e.dataTransfer.effectAllowed = 'move';
          };
          wrap.ondragend = () => {
            wrap.classList.remove('dragging');
            draggedExerciseName = null;
          };
          wrap.ondragover = (e) => {
            e.preventDefault();
            wrap.classList.add('drag-over');
          };
          wrap.ondragleave = () => wrap.classList.remove('drag-over');
          wrap.ondrop = (e) => {
            e.preventDefault();
            wrap.classList.remove('drag-over');
            if (draggedExerciseName && draggedExerciseName !== exObj.name) {
              reorderExercise(draggedExerciseName, exObj.name);
            }
          };
          const del = document.createElement('button');
          del.className = 'ex-del';
          del.innerHTML = '&times;';
          del.setAttribute('aria-label', activeBlock ? 'Remove from block' : 'Delete exercise');
          del.onclick = (e) => {
            e.stopPropagation();
            if (activeBlock) removeFromBlock(activeBlock, exObj.name);
            else deleteExercise(exObj.name, originCategory);
          };
          wrap.appendChild(del);
        }
        pending.push({ wrap, w: exObj.name.length * 8.5 + 70 + (inBlock ? originCategory.length * 6.5 + 16 : 0) + (tgt ? tgt.length * 6.5 + 14 : 0) });
      });
      // side by side, in 3 rows: each button goes to the row that is shortest so far; the block scrolls sideways
      const rows = [0, 1, 2].map(() => { const r = document.createElement('div'); r.className = 'ex-row'; r._w = 0; return r; });
      pending.forEach(p => { const r = rows.reduce((a, b) => (b._w < a._w ? b : a)); r.appendChild(p.wrap); r._w += p.w + 8; });
      rows.forEach(r => { if (r.children.length) exerciseGrid.appendChild(r); });
      if (colorsAssigned) saveLists();
    } else {
      exerciseGrid.classList.add('hidden');
      exerciseText.classList.remove('hidden');
    }
    if (exEditMode) renderExEditList();
    renderPlanStrip();
    renderModifiers();
  }

  function renderExEditList() {
    exEditList.innerHTML = '';
    const inBlock = !!activeBlock;
    document.getElementById('addExInline').classList.toggle('hidden', inBlock);
    const list = getDisplayExerciseList();
    if (inBlock) {
      const note = document.createElement('div');
      note.className = 'empty';
      note.style.padding = '0 0 8px';
      note.textContent = list.length
        ? 'Drag to reorder. Removing one only unlists it from this block — it stays in its real category.'
        : `Nothing assigned to "${activeBlock}" yet — use the Block panel above (pencil icon) to assign exercises.`;
      exEditList.appendChild(note);
    }
    if (list.length === 0) {
      if (!inBlock) exEditList.innerHTML = '<div class="empty" style="padding:4px 0;">No exercises in this category yet.</div>';
    } else {
      list.forEach(({ exObj, originCategory }) => {
        ensureExerciseColor(originCategory, exObj);
        const row = document.createElement('div');
        row.className = 'edit-row';

        const colorInput = document.createElement('input');
        colorInput.type = 'color';
        colorInput.value = exObj.color;
        colorInput.oninput = () => { exObj.color = colorInput.value; saveLists(); updateExercisePicker(); };

        const nameSpan = document.createElement('span');
        nameSpan.className = 'name';
        nameSpan.textContent = exObj.name + (inBlock ? ` (${originCategory})` : '');

        const isoBtn = document.createElement('button');
        isoBtn.className = 'iso-toggle' + (exObj.isometric ? ' on' : '');
        isoBtn.type = 'button';
        isoBtn.textContent = exObj.isometric ? 'ISO' : 'REPS';
        isoBtn.title = exObj.isometric ? 'Isometric (timed in seconds)' : 'Rep-based';
        isoBtn.onclick = () => {
          exObj.isometric = !exObj.isometric;
          saveLists();
          renderExEditList();
          updateExercisePicker();
        };

        const uniBtn = document.createElement('button');
        uniBtn.className = 'iso-toggle' + (exObj.unilateral ? ' on' : '');
        uniBtn.type = 'button';
        uniBtn.textContent = exObj.unilateral ? 'UNI' : 'BI';
        uniBtn.title = exObj.unilateral ? 'Unilateral (logged per side, L/R)' : 'Bilateral';
        uniBtn.onclick = () => {
          exObj.unilateral = !exObj.unilateral;
          saveLists();
          renderExEditList();
          updateExercisePicker();
        };

        const actions = document.createElement('div');
        actions.className = 'actions';
        actions.appendChild(isoBtn);
        actions.appendChild(uniBtn);

        const delBtn = document.createElement('button');
        delBtn.className = 'danger';
        delBtn.innerHTML = '<i class="fa-regular fa-trash-can" aria-hidden="true"></i>';
        delBtn.onclick = (e) => {
          e.stopPropagation();
          if (activeBlock) removeFromBlock(activeBlock, exObj.name);
          else deleteExercise(exObj.name, originCategory);
        };
        actions.appendChild(delBtn);

        row.appendChild(colorInput);
        row.appendChild(nameSpan);
        row.appendChild(actions);
        exEditList.appendChild(row);
      });
    }
  }

  function deleteExercise(name, category) {
    const cat = category || active;
    if (!bulkQuiet && !confirm(`Remove "${name}" from ${cat}?`)) return;
    exerciseLists[cat] = (exerciseLists[cat] || []).filter(e => e.name !== name);
    markExerciseRemoved(name);
    if (selectedExercise === name) selectedExercise = "";
    saveLists();
    updateExercisePicker();
  }

  // Unlists an exercise from a block's curated view only — the exercise
  // itself keeps existing in its real category.
  function removeFromBlock(blockName, name) {
    if (!confirm(`Remove "${name}" from "${blockName}"?`)) return;
    blockRefs[blockName] = (blockRefs[blockName] || []).filter(r => r.name !== name);
    if (selectedExercise === name) selectedExercise = "";
    saveBlocks();
    renderBlockEditList();
    updateExercisePicker();
  }

  exerciseText.addEventListener('input', renderModifiers);

  function renderSortToggle() {
    if (sortMode === 'alphabetical') {
      sortToggleBtn.innerHTML = '<i class="fa-solid fa-arrow-down-a-z" aria-hidden="true"></i>';
      sortToggleBtn.title = 'Sort: alphabetical — tap to change';
      sortToggleBtn.setAttribute('aria-label', 'Sort: alphabetical (tap to change)');
    } else {
      sortToggleBtn.innerHTML = '<i class="fa-solid fa-arrow-down-wide-short" aria-hidden="true"></i>';
      sortToggleBtn.title = 'Sort: order added — tap to change';
      sortToggleBtn.setAttribute('aria-label', 'Sort: order added (tap to change)');
    }
  }
  sortToggleBtn.onclick = () => {
    sortMode = (sortMode === 'ascending') ? 'alphabetical' : 'ascending';
    renderSortToggle();
    updateExercisePicker();
  };
  renderSortToggle();

  // ---- Exercise search (home page) — a popup like the add/edit exercise modal,
  // searching across every category rather than filtering the visible grid ----
  function allExercisesFlat() {
    const flat = [];
    categories.forEach(cat => (exerciseLists[cat] || []).forEach(exObj => flat.push({ exObj, originCategory: cat })));
    return flat;
  }
  const exerciseSearchBtn = document.getElementById('exerciseSearchBtn');
  const exSearchOverlay = document.getElementById('exSearchOverlay');
  const exerciseSearchInput = document.getElementById('exerciseSearchInput');
  const exerciseSearchResults = document.getElementById('exerciseSearchResults');
  function renderExerciseSearchResults() {
    const q = exerciseSearchInput.value.trim().toLowerCase();
    exerciseSearchResults.innerHTML = '';
    if (!q) { exerciseSearchResults.innerHTML = '<div class="empty" style="padding:6px 0;">Start typing to search every exercise.</div>'; return; }
    const matches = allExercisesFlat().filter(p => p.exObj.name.toLowerCase().includes(q));
    if (!matches.length) { exerciseSearchResults.innerHTML = '<div class="empty" style="padding:6px 0;">No matches.</div>'; return; }
    matches.forEach(({ exObj, originCategory }) => {
      const row = document.createElement('div');
      row.className = 'edit-row';
      row.style.cursor = 'pointer';
      const nameSpan = document.createElement('span');
      nameSpan.className = 'name';
      const dot = document.createElement('span');
      dot.className = 'dot';
      dot.style.background = exObj.color;
      nameSpan.appendChild(dot);
      nameSpan.appendChild(document.createTextNode(exObj.name));
      const catTag = document.createElement('span');
      catTag.className = 'iso-tag origin-tag';
      catTag.style.marginLeft = '8px';
      catTag.style.background = getCategoryColor(originCategory);
      catTag.style.color = '#fff';
      catTag.textContent = originCategory;
      nameSpan.appendChild(catTag);
      row.appendChild(nameSpan);
      row.onclick = () => {
        active = originCategory;
        activeBlock = null;
        const prevExercise = selectedExercise;
        selectedExercise = exObj.name;
        if (selectedExercise !== prevExercise) switchExerciseInputs(prevExercise, selectedExercise);
        renderTabs();
        renderBlockSelect();
        updateExercisePicker();
        renderModifiers();
        closeExerciseSearch();
      };
      exerciseSearchResults.appendChild(row);
    });
  }
  function openExerciseSearch() {
    exSearchOverlay.classList.remove('hidden');
    exerciseSearchInput.value = '';
    renderExerciseSearchResults();
    exerciseSearchInput.focus();
  }
  function closeExerciseSearch() { exSearchOverlay.classList.add('hidden'); }
  exerciseSearchBtn.onclick = openExerciseSearch;
  exerciseSearchInput.addEventListener('input', renderExerciseSearchResults);
  document.getElementById('exSearchCloseBtn').onclick = closeExerciseSearch;
  exSearchOverlay.addEventListener('click', (e) => { if (e.target === exSearchOverlay) closeExerciseSearch(); });

  // Blocks/Categories section headers get a shortcut into the same global
  // search modal, so you don't have to leave the config page to look something up.

  // ---- Collapsible Blocks / Categories sections ----
  function wireCollapse(btnId, bodyId) {
    const btn = document.getElementById(btnId);
    const body = document.getElementById(bodyId);
    btn.onclick = () => {
      const collapsing = !body.classList.contains('hidden');
      body.classList.toggle('hidden', collapsing);
      btn.innerHTML = collapsing
        ? '<i class="fa-solid fa-chevron-right" aria-hidden="true"></i>'
        : '<i class="fa-solid fa-chevron-down" aria-hidden="true"></i>';
      btn.title = collapsing ? 'Expand' : 'Collapse';
      btn.setAttribute('aria-label', (collapsing ? 'Expand' : 'Collapse') + ' section');
    };
  }
  wireCollapse('blocksCollapseBtn', 'blocksSectionBody');
  wireCollapse('categoriesCollapseBtn', 'categoriesSectionBody');
  wireCollapse('equipmentCollapseBtn', 'equipmentSectionBody');

  // ---- Search within the Exercises list itself (config page) ----
  let allExSearchQuery = "";
  const exListSearchBtn = document.getElementById('exListSearchBtn');
  const allExSearchRow = document.getElementById('allExSearchRow');
  const allExSearchInput = document.getElementById('allExSearchInput');
  exListSearchBtn.onclick = () => {
    const opening = allExSearchRow.classList.contains('hidden');
    allExSearchRow.classList.toggle('hidden', !opening);
    exListSearchBtn.classList.toggle('on', opening);
    if (opening) allExSearchInput.focus();
    else { allExSearchInput.value = ''; allExSearchQuery = ''; renderAllExercisesList(); }
  };
  allExSearchInput.addEventListener('input', () => {
    allExSearchQuery = allExSearchInput.value.trim();
    renderAllExercisesList();
  });

  exEditBtn.onclick = () => {
    exEditMode = !exEditMode;
    exEditBtn.classList.toggle('on', exEditMode);
    exEditPanel.classList.toggle('hidden', !exEditMode);
    updateExercisePicker();
  };
  newExIsoBtn.onclick = () => {
    newExIsometric = !newExIsometric;
    newExIsoBtn.textContent = newExIsometric ? 'ISO' : 'REPS';
    newExIsoBtn.classList.toggle('on', newExIsometric);
  };
  newExUniBtn.onclick = () => {
    newExUnilateral = !newExUnilateral;
    newExUniBtn.textContent = newExUnilateral ? 'UNI' : 'BI';
    newExUniBtn.classList.toggle('on', newExUnilateral);
  };
  document.getElementById('addExBtn').onclick = () => {
    if (activeBlock) return; // exercises are added to a category, not to a block
    const name = newExInput.value.trim();
    if (!name) return;
    if (!exerciseLists[active]) exerciseLists[active] = [];
    if (exerciseLists[active].some(e => e.name.toLowerCase() === name.toLowerCase())) {
      alert('That exercise is already in the list.');
      return;
    }
    exerciseLists[active].push({ name, color: newExColor.value, isometric: newExIsometric, unilateral: newExUnilateral, createdAt: Date.now() });
    newExInput.value = '';
    newExIsometric = false;
    newExIsoBtn.textContent = 'REPS';
    newExIsoBtn.classList.remove('on');
    newExUnilateral = false;
    newExUniBtn.textContent = 'BI';
    newExUniBtn.classList.remove('on');
    newExColor.value = EX_COLOR_PALETTE[(exerciseLists[active].filter(e => e.color).length) % EX_COLOR_PALETTE.length];
    saveLists();
    updateExercisePicker();
    renderAllExercisesList();
    showToast('Exercise added');
  };
  newExInput.addEventListener('keydown', (e) => { if (e.key === 'Enter') document.getElementById('addExBtn').click(); });

  function clearSetInputs() {
    for (let i = 1; i <= numSets; i++) {
      document.getElementById('set' + i).value = '';
      document.getElementById('left' + i).value = '';
      document.getElementById('right' + i).value = '';
      document.getElementById('ecc' + i).value = '';
      document.getElementById('kg' + i).value = '';
      const angleEl = document.getElementById('angle' + i);
      if (angleEl) angleEl.value = '';
      const equipEl = document.getElementById('equip' + i);
      if (equipEl) equipEl.value = '';
      const varEl = document.getElementById('var' + i);
      if (varEl) varEl.value = '';
      ['rpe', 'flag', 'chain'].forEach(p => { const x = document.getElementById(p + i); if (x) x.value = ''; });
    }
    resetEccCascade();
    resetKgCascade();
    resetEquipCascade();
    resetVarCascade();
    syncChainPills();
  }
  // optional per-set effort (RPE), pain and form flags
  function flagProps(i) {
    const r = document.getElementById('rpe' + i), f = document.getElementById('flag' + i), o = {};
    if (r && r.value) o.rpe = Number(r.value);
    if (f && (f.value === 'pain' || f.value === 'both')) o.pain = true;
    if (f && (f.value === 'broke' || f.value === 'both')) o.formBroke = true;
    const c = document.getElementById('chain' + i);
    if (c && c.value === '1') o.chain = true; // continuous with the previous set
    return o;
  }
  function readSets(name) {
    const unilateral = isUnilateralExercise(name);
    const leverage = hasLeverageTag(name);
    const sets = [];
    for (let i = 1; i <= numSets; i++) {
      const ecc = document.getElementById('ecc' + i).value;
      const kg = (() => { const raw = document.getElementById('kg' + i).value; return raw !== '' && !isNaN(Number(raw)) ? String(kgFromInput(raw)) : raw; })();
      const angleEl = document.getElementById('angle' + i);
      const angle = leverage && angleEl && angleEl.value.trim() !== '' ? angleEl.value.trim() : null;
      const equipEl = document.getElementById('equip' + i);
      const equipment = equipEl && equipEl.value ? equipEl.value : null;
      const varEl = document.getElementById('var' + i);
      const variation = varEl && varEl.value ? varEl.value : null;
      if (setIsUni(name, i)) {
        const l = document.getElementById('left' + i).value;
        const r = document.getElementById('right' + i).value;
        if (l !== '' || r !== '') {
          sets.push({
            left: l !== '' ? Number(l) : 0,
            right: r !== '' ? Number(r) : 0,
            eccentric: ecc !== '' ? Number(ecc) : null,
            kg: kg !== '' ? Number(kg) : null,
            angle,
            equipment,
            variation,
            ...flagProps(i)
          });
        }
      } else {
        const val = document.getElementById('set' + i).value;
        if (val !== '') sets.push({ reps: Number(val), eccentric: ecc !== '' ? Number(ecc) : null, kg: kg !== '' ? Number(kg) : null, angle, equipment, variation, ...flagProps(i) });
      }
    }
    return sets;
  }

